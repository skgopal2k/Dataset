import numpy as np
import matplotlib.pyplot as plt

def Prediction_Accuracy():
    plt.subplots(figsize=(8, 5))
    Iteration = ['Proposed\nE-Mamba-IKAN', 'Transformer', 'GRU', 'LSTM']
    values = [98.7546, 96.2154, 93.2547, 90.2586]
    plt.plot(Iteration, values, 's-g')
    plt.xlabel("Techniques", fontweight='bold', fontname="Times New Roman", fontsize=14)
    plt.ylabel("Prediction Accuracy (%)", fontweight='bold', fontname="Times New Roman", fontsize=14)
    plt.yticks(fontweight='bold', fontname="Times New Roman", fontsize=14)
    plt.xticks(fontweight='bold', fontname="Times New Roman", fontsize=14)
    plt.rcParams['font.sans-serif'] = "Times New Roman"
    plt.rcParams['font.size'] = 14
    plt.rcParams['font.weight'] = 'bold'
    plt.tight_layout()
    plt.savefig("..\\Graphs\\Prediction_Accuracy.png")
    plt.close()
Prediction_Accuracy()

def MAE_RMSE_MAPE():
    PR = [27.1245,	33.4512,	37.5012]
    E1 = [33.6051,	37.4512,	42.3214]
    E2 = [38.4512,	42.5104,	47.5102]
    E3 = [43.3026,	48.6521,	53.6207]
    barWidth = 0.17
    br1 = np.arange(len(PR))
    br2 = [x + barWidth for x in br1]
    br3 = [x + barWidth for x in br2]
    br4 = [x + barWidth for x in br3]
    br5 = [x + barWidth for x in br4]
    plt.figure(figsize=(8, 5))
    plt.bar(br1, PR, color='darkcyan',  width=barWidth, edgecolor='pink', label='Proposed\nE-Mamba-IKAN')
    plt.bar(br2, E1, color='salmon', width=barWidth, edgecolor='pink', label='Transformer')
    plt.bar(br3, E2, color='turquoise',  width=barWidth, edgecolor='pink', label='GRU')
    plt.bar(br4, E3, color='plum',  width=barWidth, edgecolor='pink', label='LSTM')
    plt.xlabel('\nMetrics', fontweight='bold', fontname="Times New Roman", fontsize=14)
    plt.ylabel('Values', fontweight='bold', fontname="Times New Roman", fontsize=14)
    plt.xticks([0.25, 1.25, 2.25], ['MAE', 'RMSE', 'MAPE'])
    plt.yticks(fontweight='bold', fontsize=14, fontname="Times New Roman")
    plt.xticks(fontweight='bold', fontsize=14, fontname="Times New Roman")
    plt.rcParams['font.sans-serif'] = "Times New Roman"
    plt.rcParams['font.size'] = 14
    plt.rcParams['font.weight'] = 'bold'
    plt.legend(loc=2, ncol=3)
    plt.tight_layout()
    plt.savefig("..\\Graphs\\MAE_RMSE_MAPE.png")
    plt.close()
MAE_RMSE_MAPE()