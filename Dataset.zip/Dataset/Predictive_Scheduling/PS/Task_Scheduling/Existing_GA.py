"""
Task Scheduling using Genetic Algorithm (GA)

Features
--------
1. Task-to-VM scheduling
2. Makespan minimization
3. Roulette wheel selection
4. Single-point crossover
5. Mutation operation
6. Elitism support

Requirements
------------
pip install numpy
"""

import numpy as np
import random


# ============================================================
# Task Scheduling Problem
# ============================================================

class TaskSchedulingProblem:

    def __init__(self, tasks, vms):
        """
        tasks : list of task lengths
        vms   : list of VM processing powers
        """

        self.tasks = tasks
        self.vms = vms

        self.num_tasks = len(tasks)
        self.num_vms = len(vms)

    # --------------------------------------------------------

    def fitness(self, chromosome):
        """
        Fitness based on makespan minimization
        Lower makespan => better fitness
        """

        vm_execution_time = np.zeros(self.num_vms)

        for task_id, vm_id in enumerate(chromosome):

            task_length = self.tasks[task_id]
            vm_power = self.vms[vm_id]

            execution_time = task_length / vm_power

            vm_execution_time[vm_id] += execution_time

        makespan = np.max(vm_execution_time)

        # Convert minimization to maximization fitness
        return 1 / (makespan + 1e-6)

    # --------------------------------------------------------

    def calculate_makespan(self, chromosome):

        vm_execution_time = np.zeros(self.num_vms)

        for task_id, vm_id in enumerate(chromosome):

            task_length = self.tasks[task_id]
            vm_power = self.vms[vm_id]

            execution_time = task_length / vm_power

            vm_execution_time[vm_id] += execution_time

        return np.max(vm_execution_time)


# ============================================================
# Genetic Algorithm
# ============================================================

class GeneticAlgorithm:

    def __init__(
        self,
        problem,
        population_size=50,
        generations=100,
        crossover_rate=0.8,
        mutation_rate=0.1,
        elitism=True,
        random_seed=42
    ):

        random.seed(random_seed)
        np.random.seed(random_seed)

        self.problem = problem

        self.population_size = population_size
        self.generations = generations

        self.crossover_rate = crossover_rate
        self.mutation_rate = mutation_rate

        self.elitism = elitism

        # Initialize population
        self.population = self.initialize_population()

    # --------------------------------------------------------

    def initialize_population(self):

        population = []

        for _ in range(self.population_size):

            chromosome = np.random.randint(
                0,
                self.problem.num_vms,
                self.problem.num_tasks
            )

            population.append(chromosome)

        return population

    # --------------------------------------------------------

    def evaluate_population(self):

        fitness_scores = []

        for chromosome in self.population:

            fitness = self.problem.fitness(chromosome)

            fitness_scores.append(fitness)

        return np.array(fitness_scores)

    # --------------------------------------------------------

    def roulette_wheel_selection(self, fitness_scores):

        total_fitness = np.sum(fitness_scores)

        probabilities = fitness_scores / total_fitness

        selected_index = np.random.choice(
            len(self.population),
            p=probabilities
        )

        return self.population[selected_index].copy()

    # --------------------------------------------------------

    def crossover(self, parent1, parent2):

        if random.random() > self.crossover_rate:
            return parent1.copy(), parent2.copy()

        crossover_point = random.randint(
            1,
            self.problem.num_tasks - 1
        )

        child1 = np.concatenate([
            parent1[:crossover_point],
            parent2[crossover_point:]
        ])

        child2 = np.concatenate([
            parent2[:crossover_point],
            parent1[crossover_point:]
        ])

        return child1, child2

    # --------------------------------------------------------

    def mutate(self, chromosome):

        for gene_index in range(len(chromosome)):

            if random.random() < self.mutation_rate:

                chromosome[gene_index] = random.randint(
                    0,
                    self.problem.num_vms - 1
                )

        return chromosome

    # --------------------------------------------------------

    def optimize(self):

        best_history = []

        best_solution = None
        best_fitness = -np.inf

        for generation in range(self.generations):

            fitness_scores = self.evaluate_population()

            generation_best_index = np.argmax(fitness_scores)

            generation_best_solution = (
                self.population[generation_best_index]
            )

            generation_best_fitness = (
                fitness_scores[generation_best_index]
            )

            # Update global best
            if generation_best_fitness > best_fitness:

                best_fitness = generation_best_fitness
                best_solution = generation_best_solution.copy()

            best_makespan = (
                self.problem.calculate_makespan(best_solution)
            )

            best_history.append(best_makespan)

            print(
                f"Generation {generation+1}/{self.generations} "
                f"| Best Makespan = {best_makespan:.4f}"
            )

            # Create next generation
            new_population = []

            # Elitism
            if self.elitism:
                elite_index = np.argmax(fitness_scores)
                elite = self.population[elite_index].copy()
                new_population.append(elite)

            while len(new_population) < self.population_size:

                # Selection
                parent1 = self.roulette_wheel_selection(
                    fitness_scores
                )

                parent2 = self.roulette_wheel_selection(
                    fitness_scores
                )

                # Crossover
                child1, child2 = self.crossover(
                    parent1,
                    parent2
                )

                # Mutation
                child1 = self.mutate(child1)
                child2 = self.mutate(child2)

                new_population.append(child1)

                if len(new_population) < self.population_size:
                    new_population.append(child2)

            self.population = new_population

        return (
            best_solution,
            self.problem.calculate_makespan(best_solution),
            best_history
        )

