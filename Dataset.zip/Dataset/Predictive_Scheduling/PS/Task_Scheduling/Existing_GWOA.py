"""
Task Scheduling using Grey Wolf Optimization Algorithm (GWO)

Features
--------
1. Task-to-VM scheduling
2. Makespan minimization
3. Alpha, Beta, Delta wolf hierarchy
4. Exploration and exploitation balance
5. Continuous GWO adapted for discrete scheduling

Requirements
------------
pip install numpy
"""

import numpy as np
import random


# ============================================================
# Task Scheduling Problem
# ============================================================

class TaskSchedulingProblem:

    def __init__(self, tasks, vms):
        """
        tasks : list of task lengths
        vms   : list of VM processing powers
        """

        self.tasks = tasks
        self.vms = vms

        self.num_tasks = len(tasks)
        self.num_vms = len(vms)

    # --------------------------------------------------------

    def decode_wolf(self, wolf):
        """
        Convert continuous wolf position
        into discrete VM assignments
        """

        assignment = np.round(wolf).astype(int)

        assignment = np.clip(
            assignment,
            0,
            self.num_vms - 1
        )

        return assignment

    # --------------------------------------------------------

    def calculate_makespan(self, wolf):

        assignment = self.decode_wolf(wolf)

        vm_execution_time = np.zeros(self.num_vms)

        for task_id, vm_id in enumerate(assignment):

            task_length = self.tasks[task_id]
            vm_power = self.vms[vm_id]

            execution_time = task_length / vm_power

            vm_execution_time[vm_id] += execution_time

        makespan = np.max(vm_execution_time)

        return makespan

    # --------------------------------------------------------

    def fitness(self, wolf):
        """
        Lower makespan is better
        """

        return self.calculate_makespan(wolf)


# ============================================================
# Grey Wolf Optimization Algorithm
# ============================================================

class GreyWolfOptimizer:

    def __init__(
        self,
        problem,
        population_size=30,
        max_iterations=100,
        random_seed=42
    ):

        random.seed(random_seed)
        np.random.seed(random_seed)

        self.problem = problem

        self.population_size = population_size
        self.max_iterations = max_iterations

        self.dimensions = problem.num_tasks

        # Initialize wolves
        self.population = np.random.uniform(
            0,
            problem.num_vms - 1,
            (population_size, self.dimensions)
        )

        # Alpha, Beta, Delta
        self.alpha_position = np.zeros(self.dimensions)
        self.beta_position = np.zeros(self.dimensions)
        self.delta_position = np.zeros(self.dimensions)

        self.alpha_score = np.inf
        self.beta_score = np.inf
        self.delta_score = np.inf

    # --------------------------------------------------------

    def optimize(self):

        convergence_curve = []

        for iteration in range(self.max_iterations):

            # Evaluate wolves
            for i in range(self.population_size):

                fitness = self.problem.fitness(
                    self.population[i]
                )

                # Update Alpha
                if fitness < self.alpha_score:

                    self.delta_score = self.beta_score
                    self.delta_position = (
                        self.beta_position.copy()
                    )

                    self.beta_score = self.alpha_score
                    self.beta_position = (
                        self.alpha_position.copy()
                    )

                    self.alpha_score = fitness
                    self.alpha_position = (
                        self.population[i].copy()
                    )

                # Update Beta
                elif fitness < self.beta_score:

                    self.delta_score = self.beta_score
                    self.delta_position = (
                        self.beta_position.copy()
                    )

                    self.beta_score = fitness
                    self.beta_position = (
                        self.population[i].copy()
                    )

                # Update Delta
                elif fitness < self.delta_score:

                    self.delta_score = fitness
                    self.delta_position = (
                        self.population[i].copy()
                    )

            # Parameter decreases linearly
            a = 2 - (
                iteration * (2 / self.max_iterations)
            )

            # Update wolf positions
            for i in range(self.population_size):

                for j in range(self.dimensions):

                    # Alpha influence
                    r1 = random.random()
                    r2 = random.random()

                    A1 = 2 * a * r1 - a
                    C1 = 2 * r2

                    D_alpha = abs(
                        C1 * self.alpha_position[j]
                        - self.population[i][j]
                    )

                    X1 = (
                        self.alpha_position[j]
                        - A1 * D_alpha
                    )

                    # Beta influence
                    r1 = random.random()
                    r2 = random.random()

                    A2 = 2 * a * r1 - a
                    C2 = 2 * r2

                    D_beta = abs(
                        C2 * self.beta_position[j]
                        - self.population[i][j]
                    )

                    X2 = (
                        self.beta_position[j]
                        - A2 * D_beta
                    )

                    # Delta influence
                    r1 = random.random()
                    r2 = random.random()

                    A3 = 2 * a * r1 - a
                    C3 = 2 * r2

                    D_delta = abs(
                        C3 * self.delta_position[j]
                        - self.population[i][j]
                    )

                    X3 = (
                        self.delta_position[j]
                        - A3 * D_delta
                    )

                    # Update position
                    self.population[i][j] = (
                        X1 + X2 + X3
                    ) / 3

                # Boundary handling
                self.population[i] = np.clip(
                    self.population[i],
                    0,
                    self.problem.num_vms - 1
                )

            convergence_curve.append(self.alpha_score)

            print(
                f"Iteration {iteration+1}/{self.max_iterations} "
                f"| Best Makespan = {self.alpha_score:.4f}"
            )

        return (
            self.alpha_position,
            self.alpha_score,
            convergence_curve
        )

