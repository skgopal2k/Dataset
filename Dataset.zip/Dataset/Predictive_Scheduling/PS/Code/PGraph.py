import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from PS import config as cfg

class PGraph:

    def Prediction_Accuracy(self):
        plt.subplots(figsize=(8, 5))
        Iteration = ['Proposed\nE-Mamba-IKAN', 'Transformer', 'GRU', 'GRU']
        values = [cfg.proposed_pa, cfg.etransformer_pa, cfg.egru_pa, cfg.elstm_pa]
        plt.plot(Iteration, values, 's-g')
        plt.xlabel("Techniques", fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.ylabel("Prediction Accuracy (%)", fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.yticks(fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.xticks(fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.rcParams['font.sans-serif'] = "Times New Roman"
        plt.rcParams['font.size'] = 14
        plt.rcParams['font.weight'] = 'bold'
        plt.tight_layout()
        plt.savefig("..\\Graphs\\Prediction_Accuracy.png")
        plt.close()

    def MAE_RMSE_MAPE(self):
        PR = [cfg.proposed_mae, cfg.proposed_rmse, cfg.proposed_mape]
        E1 = [cfg.etransformer_mae, cfg.etransformer_rmse, cfg.etransformer_mape]
        E2 = [cfg.egru_mae, cfg.egru_rmse, cfg.egru_mape]
        E3 = [cfg.elstm_mae, cfg.elstm_rmse, cfg.elstm_mape]
        barWidth = 0.17
        br1 = np.arange(len(PR))
        br2 = [x + barWidth for x in br1]
        br3 = [x + barWidth for x in br2]
        br4 = [x + barWidth for x in br3]
        br5 = [x + barWidth for x in br4]
        plt.figure(figsize=(8, 5))
        plt.bar(br1, PR, color='darkcyan',  width=barWidth, edgecolor='pink', label='Proposed E-Mamba-IKAN')
        plt.bar(br2, E1, color='salmon', width=barWidth, edgecolor='pink', label='Transformer')
        plt.bar(br3, E2, color='turquoise',  width=barWidth, edgecolor='pink', label='GRU')
        plt.bar(br4, E3, color='plum',  width=barWidth, edgecolor='pink', label='LSTM')
        plt.xlabel('\nMetrics', fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.ylabel('Values', fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.xticks([0.25, 1.25, 2.25], ['MAE', 'RMSE', 'MAPE'])
        plt.yticks(fontweight='bold', fontsize=14, fontname="Times New Roman")
        plt.xticks(fontweight='bold', fontsize=14, fontname="Times New Roman")
        plt.rcParams['font.sans-serif'] = "Times New Roman"
        plt.rcParams['font.size'] = 14
        plt.rcParams['font.weight'] = 'bold'
        plt.legend(loc=2, ncol=3)
        plt.ylim(0, 8.5)
        plt.tight_layout()
        plt.savefig("..\\Graphs\\MAE_RMSE_MAPE.png")
        plt.close()

    def R2(self):
        courses = ['Proposed\nE-Mamba-IKAN', 'Transformer', 'GRU', 'LSTM']
        values = [cfg.proposed_r2, cfg.etransformer_r2, cfg.egru_r2, cfg.elstm_r2]
        plt.subplots(figsize=(8, 5))
        plt.bar(courses, values, color='#548B54', width=0.35, hatch='||', edgecolor='antiquewhite')
        plt.xlabel("Techniques", fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.ylabel("R$^2$ score", fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.yticks(fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.xticks(fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.rcParams['font.sans-serif'] = "Times New Roman"
        plt.rcParams['font.size'] = 14
        plt.rcParams['font.weight'] = 'bold'
        plt.tight_layout()
        plt.savefig("..\\Graphs\\R2.png")
        plt.close()

    def prediction(self):
        data = {
            "Algorithms": ['Proposed E-Mamba-IKAN', 'Transformer', 'GRU', 'LSTM'],
            "Prediction Accuracy (%)": [cfg.proposed_pa, cfg.etransformer_pa, cfg.egru_pa, cfg.elstm_pa ],
            "MAE": [cfg.proposed_mae, cfg.etransformer_mae, cfg.egru_mae,  cfg.elstm_mae],
            "RMSE": [cfg.proposed_rmse, cfg.etransformer_rmse, cfg.egru_rmse, cfg.elstm_rmse],
            "MAPE": [cfg.proposed_mape, cfg.etransformer_mape, cfg.egru_mape, cfg.elstm_mape],
            "R2 score":[cfg.proposed_r2, cfg.etransformer_r2, cfg.egru_r2, cfg.elstm_r2]

        }
        df = pd.DataFrame(data)
        df.to_csv("..\\Graphs\\prediction.csv", index=False)

    def task_scheduling(self):
        data = {
            "Algorithms": ['Proposed ERD-PFOA', 'GWOA', 'PSOA', 'GA'],
            "Energy Consumption (mJ)": [cfg.perdpfoa_ec, cfg.egwoa_ec, cfg.epsoa_ec, cfg.ega_ec ],
            "Makespan (ms)": [cfg.perdpfoa_mk, cfg.egwoa_mk, cfg.epsoa_mk,  cfg.ega_mk],
            "Resource Utilization (%)": [cfg.perdpfoa_ru, cfg.egwoa_ru, cfg.epsoa_ru, cfg.ega_ru],
            "Task Completion Rate (%)": [cfg.perdpfoa_tcr, cfg.egwoa_tcr, cfg.epsoa_tcr, cfg.ega_tcr],
            "SLA Compliance (%)":[cfg.perdpfoa_slac, cfg.egwoa_slac, cfg.epsoa_slac, cfg.ega_slac]

        }
        df = pd.DataFrame(data)
        df.to_csv("..\\Graphs\\prediction.csv", index=False)

gr = PGraph()
gr.MAE_RMSE_MAPE()
gr.R2()
gr.prediction()