import os
import numpy as np
import rasterio
import os
import rasterio
from rasterio.enums import Resampling

import shutil
class Preprocessing:

    def band_selection(self):
        # Input and output directories
        input_root = r"..\\New Dataset\\Source\\"
        output_root = r"..\\New Output\\Training\\Band Selection\\"

        # Bands to keep
        selected_bands = [
            "B02",  # Blue
            "B03",  # Green
            "B04",  # Red
            "B08",  # Near Infrared
            "B11",  # SWIR1
            "B12"  # SWIR2
        ]
        os.makedirs(output_root, exist_ok=True)

        # Process each scene
        for scene in os.listdir(input_root):

            input_scene = os.path.join(input_root, scene)

            if not os.path.isdir(input_scene):
                continue

            output_scene = os.path.join(output_root, scene)
            os.makedirs(output_scene, exist_ok=True)

            for band in selected_bands:

                input_file = os.path.join(input_scene, band + ".tif")

                if os.path.exists(input_file):
                    output_file = os.path.join(output_scene, band + ".tif")

                    shutil.copy2(input_file, output_file)

    def resampling(self):
        # Input folder (selected bands)
        INPUT_ROOT = r"..\\New Output\\Training\\Band Selection\\"

        # Output folder
        OUTPUT_ROOT = r"..\\New Output\\Training\\Resampling\\"

        os.makedirs(OUTPUT_ROOT, exist_ok=True)

        for scene in os.listdir(INPUT_ROOT):

            scene_path = os.path.join(INPUT_ROOT, scene)

            if not os.path.isdir(scene_path):
                continue

            out_scene = os.path.join(OUTPUT_ROOT, scene)
            os.makedirs(out_scene, exist_ok=True)

            for file in os.listdir(scene_path):

                if not file.endswith(".tif"):
                    continue

                input_file = os.path.join(scene_path, file)
                output_file = os.path.join(out_scene, file)

                with rasterio.open(input_file) as src:

                    # Resample only B11 and B12
                    if file in ["B11.tif", "B12.tif"]:

                        scale = 2  # 20 m → 10 m

                        data = src.read(
                            out_shape=(
                                src.count,
                                int(src.height * scale),
                                int(src.width * scale)
                            ),
                            resampling=Resampling.bilinear
                        )

                        transform = src.transform * src.transform.scale(
                            src.width / data.shape[-1],
                            src.height / data.shape[-2]
                        )

                        profile = src.profile
                        profile.update(
                            height=data.shape[1],
                            width=data.shape[2],
                            transform=transform
                        )

                    else:
                        data = src.read()
                        profile = src.profile

                with rasterio.open(output_file, "w", **profile) as dst:
                    dst.write(data)

    def band_stacking(self):

        # Input folder (contains resampled bands)
        INPUT_ROOT = r"..\\New Output\\Training\\Resampling\\"

        # Output folder
        OUTPUT_ROOT = r"..\\New Output\\Training\\Band Stacking\\"
        os.makedirs(OUTPUT_ROOT, exist_ok=True)

        bands = ["B02", "B03", "B04", "B08", "B11", "B12"]

        for scene in os.listdir(INPUT_ROOT):

            scene_path = os.path.join(INPUT_ROOT, scene)

            if not os.path.isdir(scene_path):
                continue

            stack = []
            profile = None
            missing_band = False

            for band in bands:

                band_path = os.path.join(scene_path, f"{band}.tif")

                if not os.path.exists(band_path):
                    print(f"Missing {band} in {scene}")
                    missing_band = True
                    break

                with rasterio.open(band_path) as src:

                    data = src.read(1)

                    if profile is None:
                        profile = src.profile.copy()

                    stack.append(data)

            if missing_band:
                continue

            # Stack bands -> (6, H, W)
            stack = np.stack(stack, axis=0)

            profile.update(
                count=len(bands),
                dtype=stack.dtype,
                compress="lzw"
            )

            # Create corresponding output subfolder
            output_scene = os.path.join(OUTPUT_ROOT, scene)
            os.makedirs(output_scene, exist_ok=True)

            # Save stacked image inside the subfolder
            output_file = os.path.join(output_scene, "stacked.tif")

            with rasterio.open(output_file, "w", **profile) as dst:
                dst.write(stack)

        #     print(f"Stacked image saved: {output_file}")
        #
        # print("\nBand stacking completed successfully.")

pr = Preprocessing()
# pr.band_selection()
# pr.resampling()
pr.band_stacking()
