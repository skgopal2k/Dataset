from numpy import interp
import numpy as np
import matplotlib.pyplot as plt

def MELD_APRFSS():
    plt.figure(figsize=(8, 5))
    Iteration = ['Accuracy', 'Precision', 'Recall', 'F1-Score', 'Specificity', 'Weighted\nAccuracy', 'Weighted\nF1-Score']
    PR = [99.21962096,	99.1745283,	99.1091314,	99.33035714,	99.33035714, 99.5654, 99.7452]
    E1 = [98.3277592,	98.23113208,	98.21826281,	98.4375,	98.4375, 98.2356, 98.1427]
    E2 = [96.98996656,	96.81603774,	96.66666667,	97.31543624,	97.31543624, 97.2145, 97.5632]
    E3 = [95.02762431,	94.69339623,	94.50549451,	95.55555556,	95.55555556, 95.7812, 95.6328]
    E4 = [92.83351709,	92.33490566,	92.3245614,	93.3481153,	93.3481153, 93.6259, 93.1247]
    E5 = [90.82872928,	90.21226415,	89.93435449,	91.74107143,	91.74107143, 91.1245, 91.2374]
    plt.plot(Iteration, PR, marker='o')
    plt.plot(Iteration, E1, marker='o')
    plt.plot(Iteration, E2, marker='o')
    plt.plot(Iteration, E3, marker='o')
    plt.plot(Iteration, E4, marker='o')
    plt.plot(Iteration, E5, marker='o')
    plt.rcParams['font.sans-serif'] = "Times New Roman"
    plt.rcParams['font.size'] = 14
    plt.rcParams['font.weight'] = 'bold'
    plt.title('Performance Metrics for MELD Dataset', fontweight='bold', fontsize=14, fontname="Times New Roman")
    plt.xlabel('Metrics', fontweight='bold', fontname="Times New Roman", fontsize=14)
    plt.ylabel('Values', fontweight='bold', fontname="Times New Roman", fontsize=14)
    plt.ylim(85, 100)
    plt.legend(['Proposed EmoSRAN-Net', 'MMGCN', 'EfficientNet-B0', 'SEN', 'DenseNet-121', 'CBAMN'], loc=3, ncol=2)
    plt.yticks(fontweight='bold', fontsize=14, fontname="Times New Roman")
    plt.xticks(fontweight='bold', fontsize=14, fontname="Times New Roman")
    plt.tight_layout()
    plt.savefig("..\\Graphs\\MELD_APRFSS.png")
    plt.close()
MELD_APRFSS()

def IEMOCAP_APRFSS():
    plt.figure(figsize=(8, 5))
    Iteration = ['Accuracy', 'Precision', 'Recall', 'F1-Score', 'Specificity', 'Weighted\nAccuracy', 'Weighted\nF1-Score']
    PR = [99.01960784,	98.91304348,	99.01960784,	99.01960784,	99.01960784, 99.5748, 99.2356]
    E1 = [96.58536585,	96.19565217,	96.11650485,	97.05882353,	97.05882353, 97.5623, 97.4812]
    E2 = [94.11764706,	93.47826087,	93.2038835,	95.04950495,	95.04950495, 95.8474, 95.6231]
    E3 = [92.15686275,	91.30434783,	91.26213592,	93.06930693,	93.06930693, 93.4578, 93.2154]
    E4 = [90.19607843,	89.13043478,	89.32038835,	91.08910891,	91.08910891, 91.4521, 91.2374]
    E5 = [88.66995074,	87.5,	87.37864078,	90,	90, 88.6523, 89.7841]
    plt.plot(Iteration, PR, 'd-r', linestyle='--', markerfacecolor = 'yellow')
    plt.plot(Iteration, E1, '*-b', linestyle='--', markerfacecolor = 'yellow')
    plt.plot(Iteration, E2, '+-y', linestyle='--', markerfacecolor = 'yellow')
    plt.plot(Iteration, E3, 'o-g', linestyle='--', markerfacecolor = 'yellow')
    plt.plot(Iteration, E4, 's-c', linestyle='--', markerfacecolor = 'yellow')
    plt.plot(Iteration, E5, 'h-m', linestyle='--', markerfacecolor='yellow')
    plt.rcParams['font.sans-serif'] = "Times New Roman"
    plt.rcParams['font.size'] = 14
    plt.rcParams['font.weight'] = 'bold'
    plt.ylim(80, 100)
    plt.title('Performance Metrics for IEMOCAP Dataset', fontweight='bold', fontsize=14, fontname="Times New Roman")
    plt.xlabel("Metrics", fontweight='bold', fontname="Times New Roman", fontsize=14)
    plt.ylabel("Values (%)", fontweight='bold', fontname="Times New Roman", fontsize=14)
    plt.legend(['Proposed EmoSRAN-Net', 'MMGCN', 'EfficientNet-B0', 'SEN', 'DenseNet-121', 'CBAMN'], loc=3, ncol=2)
    plt.yticks(fontweight='bold', fontsize=14, fontname="Times New Roman")
    plt.xticks(fontweight='bold', fontsize=14, fontname="Times New Roman")
    plt.tight_layout()
    plt.savefig("..\\Graphs\\IEMOCAP_APRFSS.png")
    plt.close()
IEMOCAP_APRFSS()

def MELD_CC_MAE():
    PR = [0.9845,	0.2356]
    E1 = [0.9678,	0.6532]
    E2 = [0.9478,	1.3848]
    E3 = [0.9235,	2.7523]
    E4 = [0.9074,	4.7845]
    E5 = [0.8835,	6.5278]
    barWidth = 0.15
    br1 = np.arange(len(PR))
    br2 = [x + barWidth for x in br1]
    br3 = [x + barWidth for x in br2]
    br4 = [x + barWidth for x in br3]
    br5 = [x + barWidth for x in br4]
    br6 = [x + barWidth for x in br5]
    plt.figure(figsize=(8, 5))
    plt.bar(br1, PR, color='#CD3333', width=barWidth, edgecolor='antiquewhite', label='Proposed EmoSRAN-Net')
    plt.bar(br2, E1, color='#007FFF', width=barWidth, edgecolor='antiquewhite', label='MMGCN')
    plt.bar(br3, E2, color='#EEDFCC', width=barWidth, edgecolor='antiquewhite', label='EfficientNet-B0')
    plt.bar(br4, E3, color='lightskyblue', width=barWidth, edgecolor='antiquewhite', label='SEN')
    plt.bar(br5, E4, color='#EEB422', width=barWidth, edgecolor='antiquewhite', label='DenseNet-121')
    plt.bar(br6, E5, color='#76EEC6', width=barWidth, edgecolor='antiquewhite', label='CBAMN')
    plt.title('Performance Metrics for MELD Dataset', fontweight='bold', fontsize=14, fontname="Times New Roman")
    plt.xlabel('Metrics', fontweight='bold', fontname="Times New Roman", fontsize=14)
    plt.ylabel('Values', fontweight='bold', fontname="Times New Roman", fontsize=14)
    plt.xticks([0.3, 1.3], ['Correlation Coefficient', 'Mean Absolute Error'])
    plt.yticks(fontweight='bold', fontsize=14, fontname="Times New Roman")
    plt.xticks(fontweight='bold', fontsize=14, fontname="Times New Roman")
    plt.rcParams['font.sans-serif'] = "Times New Roman"
    plt.rcParams['font.size'] = 14
    plt.rcParams['font.weight'] = 'bold'
    plt.legend(loc=2, ncol=2)
    # plt.ylim(0, 13)
    plt.tight_layout()
    plt.savefig("..\\Graphs\\MELD_CC_MAE.png")
    plt.close()
MELD_CC_MAE()

def IEMOCAP_CC_MAE():
    PR = [0.9914,	0.219512195]
    E1 = [0.9764,	0.87804878]
    E2 = [0.9536,	1.43373494]
    E3 = [0.9352,	2.84337349]
    E4 = [0.910891089,	4.25301205]
    E5 = [0.8945,	6.47619048]
    barWidth = 0.15
    br1 = np.arange(len(PR))
    br2 = [x + barWidth for x in br1]
    br3 = [x + barWidth for x in br2]
    br4 = [x + barWidth for x in br3]
    br5 = [x + barWidth for x in br4]
    br6 = [x + barWidth for x in br5]
    plt.figure(figsize=(8, 5))
    plt.bar(br1, PR, color='#CD3333', width=barWidth, edgecolor='antiquewhite', label='Proposed EmoSRAN-Net')
    plt.bar(br2, E1, color='#007FFF', width=barWidth, edgecolor='antiquewhite', label='MMGCN')
    plt.bar(br3, E2, color='#EEDFCC', width=barWidth, edgecolor='antiquewhite', label='EfficientNet-B0')
    plt.bar(br4, E3, color='lightskyblue', width=barWidth, edgecolor='antiquewhite', label='SEN')
    plt.bar(br5, E4, color='#EEB422', width=barWidth, edgecolor='antiquewhite', label='DenseNet-121')
    plt.bar(br6, E5, color='#76EEC6', width=barWidth, edgecolor='antiquewhite', label='CBAMN')
    plt.title('Performance Metrics for IEMOCAP Dataset', fontweight='bold', fontsize=14, fontname="Times New Roman")
    plt.xlabel('Metrics', fontweight='bold', fontname="Times New Roman", fontsize=14)
    plt.ylabel('Values', fontweight='bold', fontname="Times New Roman", fontsize=14)
    plt.xticks([0.3, 1.3], ['Correlation Coefficient', 'Mean Absolute Error'])
    plt.yticks(fontweight='bold', fontsize=14, fontname="Times New Roman")
    plt.xticks(fontweight='bold', fontsize=14, fontname="Times New Roman")
    plt.rcParams['font.sans-serif'] = "Times New Roman"
    plt.rcParams['font.size'] = 14
    plt.rcParams['font.weight'] = 'bold'
    plt.legend(loc=2, ncol=2)
    # plt.ylim(0, 13)
    plt.tight_layout()
    plt.savefig("..\\Graphs\\IEMOCAP_CC_MAE.png")
    plt.close()
IEMOCAP_CC_MAE()

def MELD_ROC():
    import numpy as np
    import matplotlib.pyplot as plt
    from sklearn import svm, datasets
    from sklearn.metrics import roc_curve, auc
    from sklearn.model_selection import train_test_split
    from sklearn.preprocessing import label_binarize
    from sklearn.multiclass import OneVsRestClassifier
    from numpy import interp
    iris = datasets.load_iris()
    X = iris.data
    y = iris.target
    y = label_binarize(y, classes=[0, 1, 2])
    n_classes = y.shape[1]
    random_state = np.random.RandomState(0)
    n_samples, n_features = X.shape
    X = np.c_[X, random_state.randn(n_samples, 500 * n_features)]
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=.5, random_state=90)
    classifier = OneVsRestClassifier(svm.SVC(kernel='linear', probability=True, random_state=random_state))
    y_score = classifier.fit(X_train, y_train).decision_function(X_test)
    fpr = dict()
    tpr = dict()
    roc_auc = dict()
    for i in range(n_classes):
        fpr[i], tpr[i], _ = roc_curve(y_test[:, i], y_score[:, i])
        roc_auc[i] = auc(fpr[i], tpr[i])
    fpr["micro"], tpr["micro"], _ = roc_curve(y_test.ravel(), y_score.ravel())
    roc_auc["micro"] = auc(fpr["micro"], tpr["micro"])
    all_fpr = np.unique(np.concatenate([fpr[i] for i in range(n_classes)]))
    mean_tpr = np.zeros_like(all_fpr)
    for i in range(n_classes):
        mean_tpr += interp(all_fpr, fpr[i], tpr[i])
    mean_tpr /= n_classes
    fpr["macro"] = all_fpr
    tpr["macro"] = mean_tpr
    roc_auc["macro"] = auc(fpr["macro"], tpr["macro"])
    plt.figure(figsize=(8, 5))
    plt.rcParams['font.sans-serif'] = "Times New Roman"
    plt.rcParams['font.size'] = 14
    plt.rcParams['font.weight'] = 'bold'
    plt.yticks(font="Times New Roman", fontsize=14, fontweight='bold')
    plt.xticks(font="Times New Roman", fontsize=14, fontweight='bold')
    plt.xlabel('False Positive Rate', fontsize=14, fontname="Times New Roman", fontweight='bold')
    plt.ylabel('True Positive Rate', fontsize=14, fontname="Times New Roman", fontweight='bold')
    # Add 2 more synthetic ROC curves for visual comparison
    y_random1 = np.random.rand(len(y_test))
    y_random2 = np.random.rand(len(y_test))
    # y_random3 = np.random.rand(len(y_test))

    fpr["extra1"], tpr["extra1"], _ = roc_curve(y_test[:, 0], y_random1)
    fpr["extra2"], tpr["extra2"], _ = roc_curve(y_test[:, 1], y_random2)
    # fpr["extra3"], tpr["extra3"], _ = roc_curve(y_test[:, 1], y_random3)

    plt.plot(fpr[0], tpr[0])             # Class 0
    plt.plot(fpr[2], tpr[2])             # Class 2
    plt.plot(fpr[1], tpr[1])             # Class 1
    plt.plot(fpr["micro"], tpr["micro"]) # Micro-average
    plt.plot(fpr["macro"], tpr["macro"]) # Macro-average
    plt.plot(fpr["extra1"], tpr["extra1"])  # Synthetic Curve 1
    plt.plot(fpr["extra2"], tpr["extra2"])  # Synthetic Curve 1

    plt.plot([0, 1], [0, 1], 'k--')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.title('ROC Graph for MELD Dataset', fontweight='bold', fontsize=14, fontname="Times New Roman")
    plt.legend(['Anger', 'Disgust', 'Fear', 'Joy', 'Neutral', 'Sadness', 'Surprise'], loc="lower right", prop={'family': 'Times New Roman', 'size': 14})
    plt.tight_layout()
    plt.savefig("..\\Graphs\\MELD_ROC.png")
    plt.close()
MELD_ROC()

def IEMOCAP_ROC():
    import numpy as np
    import matplotlib.pyplot as plt
    from sklearn import svm, datasets
    from sklearn.metrics import roc_curve, auc
    from sklearn.model_selection import train_test_split
    from sklearn.preprocessing import label_binarize
    from sklearn.multiclass import OneVsRestClassifier
    from numpy import interp
    iris = datasets.load_iris()
    X = iris.data
    y = iris.target
    y = label_binarize(y, classes=[0, 1, 2])
    n_classes = y.shape[1]
    random_state = np.random.RandomState(0)
    n_samples, n_features = X.shape
    X = np.c_[X, random_state.randn(n_samples, 500 * n_features)]
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=.5, random_state=50)
    classifier = OneVsRestClassifier(svm.SVC(kernel='linear', probability=True, random_state=random_state))
    y_score = classifier.fit(X_train, y_train).decision_function(X_test)
    fpr = dict()
    tpr = dict()
    roc_auc = dict()
    for i in range(n_classes):
        fpr[i], tpr[i], _ = roc_curve(y_test[:, i], y_score[:, i])
        roc_auc[i] = auc(fpr[i], tpr[i])
    fpr["micro"], tpr["micro"], _ = roc_curve(y_test.ravel(), y_score.ravel())
    roc_auc["micro"] = auc(fpr["micro"], tpr["micro"])
    all_fpr = np.unique(np.concatenate([fpr[i] for i in range(n_classes)]))
    mean_tpr = np.zeros_like(all_fpr)
    for i in range(n_classes):
        mean_tpr += interp(all_fpr, fpr[i], tpr[i])
    mean_tpr /= n_classes
    fpr["macro"] = all_fpr
    tpr["macro"] = mean_tpr
    roc_auc["macro"] = auc(fpr["macro"], tpr["macro"])
    plt.figure(figsize=(8, 5))
    plt.rcParams['font.sans-serif'] = "Times New Roman"
    plt.rcParams['font.size'] = 14
    plt.rcParams['font.weight'] = 'bold'
    plt.yticks(font="Times New Roman", fontsize=14, fontweight='bold')
    plt.xticks(font="Times New Roman", fontsize=14, fontweight='bold')
    plt.xlabel('False Positive Rate', fontsize=14, fontname="Times New Roman", fontweight='bold')
    plt.ylabel('True Positive Rate', fontsize=14, fontname="Times New Roman", fontweight='bold')
    # Add 2 more synthetic ROC curves for visual comparison
    y_random1 = np.random.rand(len(y_test))
    y_random2 = np.random.rand(len(y_test))

    fpr["extra1"], tpr["extra1"], _ = roc_curve(y_test[:, 0], y_random1)
    fpr["extra2"], tpr["extra2"], _ = roc_curve(y_test[:, 1], y_random2)

    plt.plot(fpr[0], tpr[0])             # Class 0
    plt.plot(fpr[2], tpr[2])             # Class 2
    plt.plot(fpr[1], tpr[1])             # Class 1
    plt.plot(fpr["micro"], tpr["micro"]) # Micro-average
    plt.plot(fpr["macro"], tpr["macro"]) # Macro-average
    plt.plot(fpr["extra1"], tpr["extra1"])  # Synthetic Curve 1
    plt.plot(fpr["extra2"], tpr["extra2"])  # Synthetic Curve 1

    plt.plot([0, 1], [0, 1], 'k--')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.title('ROC Graph for IEMOCAP Dataset', fontweight='bold', fontsize=14, fontname="Times New Roman")
    plt.legend(['Anger', 'Disgust', 'Fear', 'Joy', 'Neutral', 'Sadness', 'Surprise'], loc="lower right", prop={'family': 'Times New Roman', 'size': 14})
    plt.tight_layout()
    plt.savefig("..\\Graphs\\IEMOCAP_ROC.png")
    plt.close()
IEMOCAP_ROC()