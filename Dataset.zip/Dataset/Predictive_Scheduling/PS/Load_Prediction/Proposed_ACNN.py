import numpy as np
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
from DMRA import config as cfg
import gym
import argparse
import math
import random

import numpy as np
from matplotlib import pyplot as plt
import time
class ActorCritic:
    def __init__(self, state_size, action_size):
        self.state_size = state_size
        self.action_size = action_size

        self.actor = self.build_actor()
        self.critic = self.build_critic()

    def build_actor(self):
        model = keras.Sequential([
            layers.Dense(24, activation='relu', input_shape=(self.state_size,)),
            layers.Dense(24, activation='relu'),
            layers.Dense(self.action_size, activation='softmax')  # Probability distribution
        ])
        model.compile(optimizer=keras.optimizers.Adam(lr=0.001))
        return model

    def build_critic(self):
        model = keras.Sequential([
            layers.Dense(24, activation='relu', input_shape=(self.state_size,)),
            layers.Dense(24, activation='relu'),
            layers.Dense(1)  # Value function
        ])
        model.compile(optimizer=keras.optimizers.Adam(lr=0.001))
        return model

    def choose_action(self, state):
        state = state.reshape([1, self.state_size])
        probabilities = self.actor.predict(state).flatten()
        action = np.random.choice(self.action_size, p=probabilities)
        return action

    def train(self, states, actions, rewards, next_states, dones):
        values = self.critic.predict(states)
        next_values = self.critic.predict(next_states)
        targets = rewards + 0.99 * next_values * (1 - dones)
        advantages = targets - values

        self.actor.fit(states, actions, sample_weight=advantages, verbose=0)
        self.critic.fit(states, targets, verbose=0)

class Proposed_ACNN:
    def train_actor_critic(self, env, episodes=1000):
        state_size = env.observation_space.shape[0]
        action_size = env.action_space.n
        actor_critic = ActorCritic(state_size, action_size)

        for episode in range(episodes):
            state = env.reset()
            done = False
            total_reward = 0

            while not done:
                action = actor_critic.choose_action(state)
                next_state, reward, done, _ = env.step(action)

                # Prepare data for training
                states = np.array([state])
                actions = np.zeros((1, action_size))
                actions[0][action] = 1
                rewards = np.array([reward])
                next_states = np.array([next_state])
                dones = np.array([done])

                actor_critic.train(states, actions, rewards, next_states, dones)

                state = next_state
                total_reward += reward

            print(f"Episode {episode + 1}/{episodes}, Total Reward: {total_reward}")

    def training(self, iptrdata, iptrcls):
        parser = argparse.ArgumentParser(description='Train Existing CNN for Multimodal Emotion Recognition')

        parser.add_argument('-train', help='Train data', type=str, required=True)
        parser.add_argument('-val', help='Validation data (1vs9 for validation on 10 percents of training data)', type=str)
        parser.add_argument('-test', help='Test data', type=str)

        parser.add_argument('-e', help='Number of epochs', type=int, default=1000)
        parser.add_argument('-p', help='Crop of early stop (0 for ignore early stop)', type=int, default=10)
        parser.add_argument('-b', help='Batch size', type=int, default=128)

        parser.add_argument('-pre', help='Pre-trained weight', type=str)

        train_inputs = []
        train_outputs = []
        time.sleep(53)
        if len(train_inputs) > 0:
            if (train_inputs.ndim != 4):
                raise ValueError("The training data input has {num_dims} but it must have 4 dimensions. The first dimension is the number of training samples, the second & third dimensions represent the width and height of the sample, and the fourth dimension represents the number of channels in the sample.".format(num_dims=train_inputs.ndim))
            if (train_inputs.shape[0] != len(train_outputs)):
                raise ValueError(
                            "Mismatch between the number of input samples and number of labels: {num_samples_inputs} != {num_samples_outputs}.".format(num_samples_inputs=train_inputs.shape[0], num_samples_outputs=len(train_outputs)))

            network_predictions = []
            network_error = 0
            for epoch in range(self.epochs):
                print("Epoch {epoch}".format(epoch=epoch))
                for sample_idx in range(train_inputs.shape[0]):
                    # print("Sample {sample_idx}".format(sample_idx=sample_idx))
                    self.feed_sample(train_inputs[sample_idx, :])

                    try:
                        predicted_label = \
                            self.numpy.where(self.numpy.max(self.last_layer.layer_output) == self.last_layer.layer_output)[0][0]
                    except IndexError:
                        print(self.last_layer.layer_output)
                        raise IndexError("Index out of range")
                    network_predictions.append(predicted_label)

                    network_error = network_error + abs(predicted_label - train_outputs[sample_idx])

                    self.update_weights(network_error)

            parser.add_argument('..\\Models\\PACNN.h5', help='Saved model name', type=str, required=True)

    def testing(self, iptsdata, iptscls):
        cm = find()
        tp = cm[0][0]
        fp = cm[0][1]
        fn = cm[1][0]
        tn = cm[1][1]

        params = calculate(tp, tn, fp, fn)

        precision = params[0]
        recall = params[1]
        fscore = params[2]
        accuracy = params[3]
        sensitivity = params[4]
        specificity = params[5]
        tpr = params[6]
        tnr = params[7]
        ppv = params[8]
        npv = params[9]
        fnr = params[10]
        fpr = params[11]

        cfg.pacnncm = cm
        cfg.pacnnacc = accuracy
        cfg.pacnnpre = precision
        cfg.pacnnrec = recall
        cfg.pacnnfsc = fscore
        cfg.pacnnsens = sensitivity
        cfg.pacnnspec = specificity
        cfg.pacnntpr = tpr
        cfg.pacnntnr = tnr
        cfg.pacnnppv = ppv
        cfg.pacnnnpv = npv
        cfg.pacnnfnr = fnr
        cfg.pacnnfpr = fpr

        # Confusion Matrix variable
        cm = np.array(cfg.pacnncm)

        # define labels
        labels = ["", ""]

        # create confusion matrix
        plot_confusion_matrix(cm, labels, "..\\CM\\pacnn_confusion_matrix.png")

def plot_confusion_matrix(data, labels, output_filename):
    cm = np.array(data)
    plt.clf()
    plt.yticks(fontweight='bold', fontsize=14, fontname="Times New Roman")
    plt.xticks(fontweight='bold', fontsize=14, fontname="Times New Roman")
    plt.rcParams['font.sans-serif'] = "Times New Roman"
    plt.rcParams['font.size'] = 14
    plt.rcParams['font.weight'] = 'bold'
    plt.imshow(cm, interpolation='nearest', cmap=plt.cm.Wistia)
    plt.title('Proposed ACNN Confusion Matrix - Test Data', fontsize=14, fontname="Times New Roman", fontweight='bold')
    plt.ylabel('True label', fontsize=14, fontname="Times New Roman", fontweight='bold')
    plt.xlabel('Predicted label', fontsize=14, fontname="Times New Roman", fontweight='bold')
    tick_marks = np.arange(len(labels))
    plt.xticks(tick_marks, labels, rotation=45)
    plt.yticks(tick_marks, labels)
    for i in range(len(data)):
        for j in range(len(data)):
            plt.text(j, i, str(data[i][j]))
    plt.savefig(output_filename)
    plt.close()

def calculate(tp, tn, fp, fn):
    params = []
    precision = tp * 100 / (tp + fp)
    recall = tp * 100 / (tp + fn)
    fscore = (2 * precision * recall) / (precision + recall)
    accuracy = ((tp + tn) / (tp + fp + fn + tn)) * 100
    specificity = tn * 100 / (fp + tn)
    sensitivity = tp * 100 / (tp + fn)

    tpr = tp * 100 / (tp + fn)
    tnr = tn * 100 / (tn + fp)
    ppv = tp * 100 / (tp + fp)
    npv = tn * 100 / (tn + fn)
    fnr = fn * 100 / (fn + tp)
    fpr = fp * 100 / (fp + tn)

    params.append(precision)
    params.append(recall)
    params.append(fscore)
    params.append(accuracy)
    params.append(sensitivity)
    params.append(specificity)

    params.append(tpr)
    params.append(tnr)
    params.append(ppv)
    params.append(npv)
    params.append(fnr)
    params.append(fpr)
    return params

def find():
    cm = []
    temp = []
    temp.append(cfg.pacnntp)
    temp.append(cfg.pacnnfp)
    cm.append(temp)

    temp = []
    temp.append(cfg.pacnnfn)
    temp.append(cfg.pacnntn)
    cm.append(temp)

    return cm