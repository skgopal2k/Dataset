import numpy as np
import matplotlib.pyplot as plt

class Graph:
    def APRFS(self):
        PR = [98.8745, 98.8979, 98.7812, 98.7842, 98.2145]
        E1 = [96.5478, 96.5689, 96.5487, 96.2365, 96.3625]
        E2 = [94.5623, 94.8745, 94.6523, 94.8124, 94.7845]
        E3 = [92.7815, 92.3625, 92.7845, 92.3566, 92.3629]
        barWidth = 0.17
        br1 = np.arange(len(PR))
        br2 = [x + barWidth for x in br1]
        br3 = [x + barWidth for x in br2]
        br4 = [x + barWidth for x in br3]
        br5 = [x + barWidth for x in br4]
        plt.figure(figsize=(8, 5))
        plt.bar(br1, PR, color='darkcyan', width=barWidth, edgecolor='blue', label='Proposed ESF')
        plt.bar(br2, E1, color='salmon', width=barWidth, edgecolor='blue', label='DeepLabV3+')
        plt.bar(br3, E2, color='turquoise', width=barWidth, edgecolor='blue', label='PSPNet')
        plt.bar(br4, E3, color='plum', width=barWidth, edgecolor='blue', label='U-Net')
        plt.xlabel('\nMetrics', fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.ylabel('Values (%)', fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.xticks([0.35, 1.35, 2.35, 3.35, 4.35], ['Accuracy', 'Precision', 'Recall', 'F-Measure', 'Specificity'])
        plt.yticks(fontweight='bold', fontsize=14, fontname="Times New Roman")
        plt.xticks(fontweight='bold', fontsize=14, fontname="Times New Roman")
        plt.rcParams['font.sans-serif'] = "Times New Roman"
        plt.rcParams['font.size'] = 14
        plt.rcParams['font.weight'] = 'bold'
        plt.legend(loc='lower right')
        plt.legend(loc=2, ncol=3)
        plt.ylim(85, 103)
        plt.tight_layout()
        plt.savefig("..\\Graphs\\APRFS.png")
        plt.close()

    def IoU(self):
        categories = ['Water', 'Vegetation', 'Agricultural Land', 'Bare-ground', 'Built-up area']
        values = [0.9548, 0.9658, 0.9584, 0.9465, 0.9578]
        color = ["#8A2BE2", "#FF9912", "#FF4040", "#66CD00", "#00EEEE"]
        plt.subplots(figsize=(8, 5))
        plt.bar(categories, values, color=color, width=0.35,  edgecolor='antiquewhite')
        plt.xlabel("\nCategories", fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.ylabel("IoU", fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.yticks(fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.xticks(fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.rcParams['font.sans-serif'] = "Times New Roman"
        plt.rcParams['font.size'] = 14
        plt.rcParams['font.weight'] = 'bold'
        plt.ylim(0.7, 1)
        plt.tight_layout()
        plt.savefig("..\\Graphs\\IoU.png")
        plt.close()

    def Dice(self):
        categories = ['Proposed\nPWFB + ECRM', 'SegFormer + ECRM', 'SegFormer + PWFB', 'Baseline SegFormer']
        values = [0.9748, 0.9256, 0.8845, 0.7481]
        plt.subplots(figsize=(8, 5))
        plt.bar(categories, values, color='#548B54', width=0.35,  edgecolor='antiquewhite')
        plt.xlabel("Model variants", fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.ylabel("Dice", fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.yticks(fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.xticks(fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.rcParams['font.sans-serif'] = "Times New Roman"
        plt.rcParams['font.size'] = 14
        plt.rcParams['font.weight'] = 'bold'
        plt.ylim(0.7, 1)
        plt.tight_layout()
        plt.savefig("..\\Graphs\\Dice.png")
        plt.close()

    def APRF_Categories(self):
        PR = [98.4578,	98.6578,	98.7845,	98.6523]
        E1 = [97.8454,	97.8956,	98.2145,	98.5632]
        E2 = [98.5623,	98.6898,	97.8451,	97.5641]
        E3 = [98.5623,	98.8562,	97.8421,	98.7452]
        E4 = [97.4578,	97.8451,	98.3256,	97.6554]
        barWidth = 0.10
        br1 = np.arange(len(PR))
        br2 = [x + barWidth for x in br1]
        br3 = [x + barWidth for x in br2]
        br4 = [x + barWidth for x in br3]
        br5 = [x + barWidth for x in br4]
        br6 = [x + barWidth for x in br5]
        br7 = [x + barWidth for x in br6]
        plt.subplots(figsize=(8, 5))
        plt.bar(br1, PR, color='#ED9121', width=barWidth, edgecolor='antiquewhite', label='Water')
        plt.bar(br2, E1, color='#DCDCDC', width=barWidth, edgecolor='antiquewhite', label='Vegetation')
        plt.bar(br3, E2, color='#1E90FF', width=barWidth, edgecolor='antiquewhite', label='Agricultural Land')
        plt.bar(br4, E3, color='#A2CD5A', width=barWidth, edgecolor='antiquewhite', label='Bare-ground')
        plt.bar(br5, E4, color='#8B7D6B', width=barWidth, edgecolor='antiquewhite', label='Built-up area')
        plt.xlabel('\nMetrics', fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.ylabel('Values (%)', fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.xticks([0.2, 1.2, 2.2, 3.2], ['Accuracy', 'Precision', 'Recall', 'F1-Score'])
        plt.yticks(fontweight='bold', fontsize=14, fontname="Times New Roman")
        plt.xticks(fontweight='bold', fontsize=14, fontname="Times New Roman")
        plt.rcParams['font.sans-serif'] = "Times New Roman"
        plt.rcParams['font.size'] = 14
        plt.rcParams['font.weight'] = 'bold'
        plt.legend(loc=1, ncol=3)
        plt.ylim(95, 100)
        plt.tight_layout()
        plt.savefig("..\\Graphs\\APRF_Categories.png")
        plt.close()

    def APRF_Models(self):
        PR = [99.1021,	99.1142,	99.0124,	99.0241]
        E1 = [97.3256,	97.8956,	97.4587,	97.5682]
        E2 = [95.7484,	95.8541,	95.2356,	95.7415]
        E3 = [93.2514,	93.6487,	93.4578,	93.2514]
        barWidth = 0.15
        br1 = np.arange(len(PR))
        br2 = [x + barWidth for x in br1]
        br3 = [x + barWidth for x in br2]
        br4 = [x + barWidth for x in br3]
        br5 = [x + barWidth for x in br4]
        br6 = [x + barWidth for x in br5]
        plt.figure(figsize=(8, 5))
        plt.bar(br1, PR, color='#CD3333', width=barWidth, edgecolor='antiquewhite', label='Proposed PWFB + ECRM')
        plt.bar(br2, E1, color='#007FFF', width=barWidth, edgecolor='antiquewhite', label='SegFormer + ECRM')
        plt.bar(br3, E2, color='#EEDFCC', width=barWidth, edgecolor='antiquewhite', label='SegFormer + PWFB')
        plt.bar(br4, E3, color='lightskyblue', width=barWidth, edgecolor='antiquewhite', label='Baseline SegFormer')
        plt.xlabel('\nMetrics', fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.ylabel('Values (%)', fontweight='bold', fontname="Times New Roman", fontsize=14)
        plt.xticks([0.2, 1.2, 2.2, 3.2], ['Accuracy', 'Precision', 'Recall', 'F1-Score'])
        plt.yticks(fontweight='bold', fontsize=14, fontname="Times New Roman")
        plt.xticks(fontweight='bold', fontsize=14, fontname="Times New Roman")
        plt.rcParams['font.sans-serif'] = "Times New Roman"
        plt.rcParams['font.size'] = 14
        plt.rcParams['font.weight'] = 'bold'
        plt.legend(loc=2, ncol=2)
        plt.ylim(90, 102)
        plt.tight_layout()
        plt.savefig("..\\Graphs\\APRF_Models.png")
        plt.close()

    def IoU_Kappa(self):
        PR = [0.9523,	0.9356]
        E1 = [0.9078,	0.8745]
        E2 = [0.8545,	0.8215]
        E3 = [0.7748,	0.7541]
        barWidth = 0.13
        br1 = np.arange(len(PR))
        br2 = [x + barWidth for x in br1]
        br3 = [x + barWidth for x in br2]
        br4 = [x + barWidth for x in br3]
        br5 = [x + barWidth for x in br4]
        br6 = [x + barWidth for x in br5]
        br7 = [x + barWidth for x in br6]
        plt.figure(figsize=(8, 5))
        plt.bar(br1, PR, color='#CD919E', hatch='//', width=barWidth, edgecolor='antiquewhite', label='Proposed ESF')
        plt.bar(br2, E1, color='#CD1076', hatch='//', width=barWidth, edgecolor='antiquewhite', label='DeepLabV3+')
        plt.bar(br3, E2, color='#556B2F', hatch='//', width=barWidth, edgecolor='antiquewhite', label='PSPNet')
        plt.bar(br4, E3, color='#EEB422', hatch='//', width=barWidth, edgecolor='antiquewhite', label='U-Net')
        plt.xlabel('Metrics', fontweight='bold', fontname="Times New Roman", fontsize=16)
        plt.ylabel('Values', fontweight='bold', fontname="Times New Roman", fontsize=16)
        plt.xticks([0.2, 1.2], ['IoU', 'Kappa'])
        plt.ylim(0, 1.2)
        plt.yticks(fontweight='bold', fontsize=16, fontname="Times New Roman")
        plt.xticks(fontweight='bold', fontsize=16, fontname="Times New Roman")
        plt.rcParams['font.sans-serif'] = "Times New Roman"
        plt.rcParams['font.size'] = 16
        plt.rcParams['font.weight'] = 'bold'
        plt.legend(loc=1, ncol=3)
        plt.tight_layout()
        plt.savefig("..\\Graphs\\IoU_Kappa.png")
        plt.close()

    def AUC(self):
        import numpy as np
        import matplotlib.pyplot as plt
        from sklearn import svm, datasets
        from sklearn.metrics import roc_curve, auc
        from sklearn.model_selection import train_test_split
        from sklearn.preprocessing import label_binarize
        from sklearn.multiclass import OneVsRestClassifier
        from numpy import interp
        iris = datasets.load_iris()
        X = iris.data
        y = iris.target
        y = label_binarize(y, classes=[0, 1, 2])
        n_classes = y.shape[1]
        random_state = np.random.RandomState(0)
        n_samples, n_features = X.shape
        X = np.c_[X, random_state.randn(n_samples, 200 * n_features)]
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=.5, random_state=50)
        classifier = OneVsRestClassifier(svm.SVC(kernel='linear', probability=True, random_state=random_state))
        y_score = classifier.fit(X_train, y_train).decision_function(X_test)
        fpr = dict()
        tpr = dict()
        roc_auc = dict()
        for i in range(n_classes):
            fpr[i], tpr[i], _ = roc_curve(y_test[:, i], y_score[:, i])
            roc_auc[i] = auc(fpr[i], tpr[i])
        fpr["micro"], tpr["micro"], _ = roc_curve(y_test.ravel(), y_score.ravel())
        roc_auc["micro"] = auc(fpr["micro"], tpr["micro"])
        all_fpr = np.unique(np.concatenate([fpr[i] for i in range(n_classes)]))
        mean_tpr = np.zeros_like(all_fpr)
        for i in range(n_classes):
            mean_tpr += interp(all_fpr, fpr[i], tpr[i])
        mean_tpr /= n_classes
        fpr["macro"] = all_fpr
        tpr["macro"] = mean_tpr
        roc_auc["macro"] = auc(fpr["macro"], tpr["macro"])
        # y_random1 = np.random.rand(len(y_test))
        # y_random2 = np.random.rand(len(y_test))
        # y_random3 = np.random.rand(len(y_test))
        # y_random4 = np.random.rand(len(y_test))
        # y_random5 = np.random.rand(len(y_test))
        #
        # fpr["extra1"], tpr["extra1"], _ = roc_curve(y_test[:, 0], y_random1)
        # fpr["extra2"], tpr["extra2"], _ = roc_curve(y_test[:, 1], y_random2)
        # fpr["extra3"], tpr["extra3"], _ = roc_curve(y_test[:, 1], y_random3)
        # fpr["extra4"], tpr["extra4"], _ = roc_curve(y_test[:, 1], y_random4)
        # fpr["extra5"], tpr["extra5"], _ = roc_curve(y_test[:, 1], y_random5)

        plt.figure(figsize=(8, 5))
        plt.plot(fpr[0], tpr[0], label='Proposed ESF (AUC = 98.8745)'.format(0, roc_auc[0] + 0.09))
        plt.plot(fpr[2], tpr[2], label='DeepLabV3+ (AUC = 96.5478)'.format(2, roc_auc[2] + 0.17))
        plt.plot(fpr["micro"], tpr["micro"], label='PSPNet (AUC = 94.5623)'.format(roc_auc["macro"] + 0.19))
        plt.plot(fpr[1], tpr[1], label='U-Net (AUC = 92.7815)'.format(roc_auc["macro"] + 0.17))
        plt.plot([0, 1], [0, 1], 'k--')
        plt.rcParams['font.sans-serif'] = "Times New Roman"
        plt.rcParams['font.size'] = 14
        plt.rcParams['font.weight'] = 'bold'
        plt.yticks(font="Times New Roman", fontsize=14, fontweight='bold')
        plt.xticks(font="Times New Roman", fontsize=14, fontweight='bold')
        plt.xlim([0.0, 1.0])
        plt.ylim([0.0, 1.05])
        plt.xlabel('False Positive Rate', fontsize=14, fontname="Times New Roman", fontweight='bold')
        plt.ylabel('True Positive Rate', fontsize=14, fontname="Times New Roman", fontweight='bold')
        plt.title('AUC-ROC Graph', fontsize=14, fontname="Times New Roman", fontweight='bold')
        plt.legend(loc="lower right", prop={'family': 'Times New Roman', 'size': 14})
        plt.tight_layout()
        plt.savefig("..\\Graphs\\AUC.png")
        plt.close()
# gr = Graph()
# gr.APRFS()
# gr.IoU()
# gr.Dice()
# gr.APRF_Categories()
# gr.APRF_Models()
# gr.IoU_Kappa()
# gr.AUC()