"""
Task Scheduling using Particle Swarm Optimization (PSO)

Features
--------
1. Task-to-VM scheduling
2. Makespan minimization
3. Velocity and position updates
4. Global best and personal best tracking
5. Continuous PSO adapted for discrete scheduling

Requirements
------------
pip install numpy
"""

import numpy as np
import random


# ============================================================
# Task Scheduling Problem
# ============================================================

class TaskSchedulingProblem:

    def __init__(self, tasks, vms):
        """
        tasks : list of task lengths
        vms   : list of VM processing powers
        """

        self.tasks = tasks
        self.vms = vms

        self.num_tasks = len(tasks)
        self.num_vms = len(vms)

    # --------------------------------------------------------

    def decode_particle(self, particle):
        """
        Convert continuous particle positions
        into discrete VM assignments
        """

        assignment = np.round(particle).astype(int)

        assignment = np.clip(
            assignment,
            0,
            self.num_vms - 1
        )

        return assignment

    # --------------------------------------------------------

    def calculate_makespan(self, particle):

        assignment = self.decode_particle(particle)

        vm_execution_time = np.zeros(self.num_vms)

        for task_id, vm_id in enumerate(assignment):

            task_length = self.tasks[task_id]
            vm_power = self.vms[vm_id]

            execution_time = task_length / vm_power

            vm_execution_time[vm_id] += execution_time

        makespan = np.max(vm_execution_time)

        return makespan

    # --------------------------------------------------------

    def fitness(self, particle):
        """
        Lower makespan = better fitness
        """

        makespan = self.calculate_makespan(particle)

        return makespan


# ============================================================
# Particle Swarm Optimization
# ============================================================

class ParticleSwarmOptimization:

    def __init__(
        self,
        problem,
        swarm_size=30,
        max_iterations=100,
        inertia_weight=0.7,
        cognitive_coefficient=1.5,
        social_coefficient=1.5,
        random_seed=42
    ):

        random.seed(random_seed)
        np.random.seed(random_seed)

        self.problem = problem

        self.swarm_size = swarm_size
        self.max_iterations = max_iterations

        self.dimensions = problem.num_tasks

        self.w = inertia_weight
        self.c1 = cognitive_coefficient
        self.c2 = social_coefficient

        # Initialize particles
        self.positions = np.random.uniform(
            0,
            problem.num_vms - 1,
            (swarm_size, self.dimensions)
        )

        # Initialize velocities
        self.velocities = np.random.uniform(
            -1,
            1,
            (swarm_size, self.dimensions)
        )

        # Personal best
        self.personal_best_positions = self.positions.copy()

        self.personal_best_fitness = np.array([
            self.problem.fitness(p)
            for p in self.positions
        ])

        # Global best
        best_index = np.argmin(self.personal_best_fitness)

        self.global_best_position = (
            self.personal_best_positions[best_index].copy()
        )

        self.global_best_fitness = (
            self.personal_best_fitness[best_index]
        )

    # --------------------------------------------------------

    def optimize(self):

        convergence_curve = []

        for iteration in range(self.max_iterations):

            for i in range(self.swarm_size):

                # Evaluate current particle
                current_fitness = self.problem.fitness(
                    self.positions[i]
                )

                # Update personal best
                if current_fitness < self.personal_best_fitness[i]:

                    self.personal_best_fitness[i] = current_fitness

                    self.personal_best_positions[i] = (
                        self.positions[i].copy()
                    )

                # Update global best
                if current_fitness < self.global_best_fitness:

                    self.global_best_fitness = current_fitness

                    self.global_best_position = (
                        self.positions[i].copy()
                    )

            # Update velocities and positions
            for i in range(self.swarm_size):

                r1 = np.random.rand(self.dimensions)
                r2 = np.random.rand(self.dimensions)

                cognitive_velocity = (
                    self.c1
                    * r1
                    * (
                        self.personal_best_positions[i]
                        - self.positions[i]
                    )
                )

                social_velocity = (
                    self.c2
                    * r2
                    * (
                        self.global_best_position
                        - self.positions[i]
                    )
                )

                self.velocities[i] = (
                    self.w * self.velocities[i]
                    + cognitive_velocity
                    + social_velocity
                )

                # Update position
                self.positions[i] += self.velocities[i]

                # Boundary handling
                self.positions[i] = np.clip(
                    self.positions[i],
                    0,
                    self.problem.num_vms - 1
                )

            convergence_curve.append(
                self.global_best_fitness
            )

            print(
                f"Iteration {iteration+1}/{self.max_iterations} "
                f"| Best Makespan = "
                f"{self.global_best_fitness:.4f}"
            )

        return (
            self.global_best_position,
            self.global_best_fitness,
            convergence_curve
        )

