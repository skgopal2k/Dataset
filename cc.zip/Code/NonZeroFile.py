import os
import shutil
import rasterio
import numpy as np

# -----------------------------
# Paths
# -----------------------------
source_root = r"..\\Dataset\\sen12floods_s2_source"
label_root = r"..\\Dataset\\sen12floods_s2_labels"

new_source_root = r"..\\New Dataset\\Source"
new_label_root = r"..\\New Dataset\\Labels"

os.makedirs(new_source_root, exist_ok=True)
os.makedirs(new_label_root, exist_ok=True)

bands = [
    "B01","B02","B03","B04",
    "B05","B06","B07","B08",
    "B8A","B09","B11","B12"
]

# ---------------------------------
# Function to check whether a folder
# contains useful data
# ---------------------------------
def is_nonzero_folder(folder):

    for band in bands:

        file = os.path.join(folder, band + ".tif")

        if not os.path.exists(file):
            return False

        with rasterio.open(file) as src:
            img = src.read(1)

        # If at least one pixel is non-zero
        if np.max(img) > 0:
            return True

    return False


# ---------------------------------
# Iterate through source folders
# ---------------------------------

for folder_name in os.listdir(source_root):

    source_folder = os.path.join(source_root, folder_name)

    if not os.path.isdir(source_folder):
        continue

    if is_nonzero_folder(source_folder):

        print("Copying:", folder_name)

        # Copy source folder
        shutil.copytree(
            source_folder,
            os.path.join(new_source_root, folder_name),
            dirs_exist_ok=True
        )

        # ---------------------------------
        # Corresponding GeoJSON
        # ---------------------------------

        # Corresponding label folder
        label_folder_name = folder_name.replace(
            "sen12floods_s2_source",
            "sen12floods_s2_labels"
        )

        label_folder = os.path.join(label_root, label_folder_name)

        if os.path.exists(label_folder):
            shutil.copytree(
                label_folder,
                os.path.join(new_label_root, label_folder_name),
                dirs_exist_ok=True
            )

            print("Copied label:", label_folder_name)

print("Finished.")