import os
import geopandas as gpd
import rasterio
from rasterio.features import rasterize
import numpy as np

class Mask_Creation:
    def mc(self):
        # -----------------------------
        # CHANGE THESE PATHS
        # -----------------------------

        IMAGE_ROOT = r"..\\Dataset\\sen12floods_s1_source"
        LABEL_ROOT = r"..\\Dataset\\sen12floods_s1_labels"
        MASK_ROOT = r"..\\Dataset\\Masks"

        os.makedirs(MASK_ROOT, exist_ok=True)


        # -----------------------------
        # Process every image folder
        # -----------------------------

        for image_folder in sorted(os.listdir(IMAGE_ROOT)):

            image_path = os.path.join(IMAGE_ROOT, image_folder)

            if not os.path.isdir(image_path):
                continue

            # Convert:
            # sen12floods_s1_source_0_2019_02_06
            # ->
            # sen12floods_s1_labels_0_2019_02_06

            label_folder = image_folder.replace(
                "sen12floods_s1_source",
                "sen12floods_s1_labels"
            )

            label_path = os.path.join(LABEL_ROOT, label_folder)

            if not os.path.exists(label_path):
                print("Label folder not found:", label_folder)
                continue

            vh = os.path.join(image_path, "VH.tif")

            geojson = os.path.join(label_path, "vector_labels.geojson")

            if not os.path.exists(vh):
                print("VH missing:", image_folder)
                continue

            if not os.path.exists(geojson):
                print("GeoJSON missing:", image_folder)
                continue

            with rasterio.open(vh) as src:

                profile = src.profile
                transform = src.transform
                crs = src.crs
                height = src.height
                width = src.width

            gdf = gpd.read_file(geojson)

            print(image_folder, "Features:", len(gdf))

            if gdf.crs != crs:
                gdf = gdf.to_crs(crs)

            # Rasterize every polygon
            mask = rasterize(
                [(geom, 1) for geom in gdf.geometry],
                out_shape=(height, width),
                transform=transform,
                fill=0,
                all_touched=True,
                dtype=np.uint8,
            )

            out_folder = os.path.join(MASK_ROOT, image_folder)

            os.makedirs(out_folder, exist_ok=True)

            out_file = os.path.join(out_folder, "mask.tif")

            profile.update(
                count=1,
                dtype=rasterio.uint8,
                compress="lzw"
            )

            with rasterio.open(out_file, "w", **profile) as dst:
                dst.write(mask, 1)
