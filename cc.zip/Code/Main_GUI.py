import os
import time
# import random
import tkinter
from tkinter import *
from tkinter.filedialog import askopenfile
import cv2
import csv
import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from tkinter import messagebox
from tkinter import Tk
import hashlib
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

from FEM.Code.Mask_Creation import Mask_Creation

from FEM.Code.Preprocessing import Preprocessing

class Main_GUI:
    boolDatasetRead = False
    boolDatasetRC = False
    boolDatasetAC = False
    boolDatasetCR = False
    boolDatasetIR = False
    boolDatasetAI = False
    boolTraining = False
    boolTesting = False

    boolRead = False
    boolRC = False
    boolAC = False
    boolCR = False
    boolIR = False
    boolAI = False


    boolPrediction = False

    iptr_data = []
    ipts_data = []

    iptr_cls = []
    ipts_cls = []

    ts_data = []

    def __init__(self, root):
        self.file_path = StringVar()

        self.LARGE_FONT = ("Algerian", 16)
        self.text_font = ("Constantia", 15)
        self.text_font1 = ("Constantia", 10)

        self.frame_font = ("", 9)
        self.frame_process_res_font = ("", 12)
        self.root = root
        self.feature_value = StringVar()

        label_heading = tkinter.Label(root, text="Automated Floodplain Encroachment Monitoring using Enhanced SegFormer", fg="deep pink",
                                      bg="azure3", font=self.LARGE_FONT)
        label_heading.place(x=100, y=0)

        self.label_frame_multispectral_dataset = LabelFrame(root, text="Multispectral Dataset", bg="azure3", fg="#00a800", font=self.frame_font)
        self.label_frame_multispectral_dataset.place(x=10, y=30, width=170, height=50)
        self.txt_multispectral_dataset = Entry(root)
        self.txt_multispectral_dataset.insert(INSERT, "..\\\\Dataset\\\\")
        self.txt_multispectral_dataset.configure(state="disabled")
        self.txt_multispectral_dataset.place(x=20, y=50, width=90, height=25)
        self.btn_multispectral_dataset = Button(root, text="Read", bg="deep sky blue", fg="#fff", font=self.text_font1, width=5, command=self.multispectral_dataset)
        self.btn_multispectral_dataset.place(x=120, y=50)

        self.label_frame_multispectral_testing_data = LabelFrame(root, text="Multispectral Data", bg="azure3", fg="#00a800", font=self.frame_font)
        self.label_frame_multispectral_testing_data.place(x=10, y=80, width=170, height=50)
        self.txt_multispectral_testing_data = Entry(root)
        self.txt_multispectral_testing_data.configure(state="disabled")
        self.txt_multispectral_testing_data.place(x=20, y=100, width=90, height=25)
        self.btn_multispectral_testing_data = Button(root, text="Browse ", bg="deep sky blue", fg="#fff", font=self.text_font1, width=5, command=self.multispectral_testing_data)
        self.btn_multispectral_testing_data.place(x=120, y=100)

        self.label_frame_preprocessing = LabelFrame(root, text="Pre-Processing", bg="azure3", fg="#00a800", font=self.frame_font)
        self.label_frame_preprocessing.place(x=190, y=30, width=130, height=100)
        self.btn_preprocessing_radiometric_correction = Button(root, text="RC", bg="deep sky blue", fg="#fff", font=self.text_font1, width=3, command=self.preprocessing_radiometric_correction)
        self.btn_preprocessing_radiometric_correction.place(x=200, y=50)
        self.btn_preprocessing_atmospheric_correction = Button(root, text="AC", bg="deep sky blue", fg="#fff", font=self.text_font1, width=3, command=self.preprocessing_atmospheric_correction)
        self.btn_preprocessing_atmospheric_correction.place(x=240, y=50)
        self.btn_preprocessing_cloud_removal = Button(root, text="CR", bg="deep sky blue", fg="#fff", font=self.text_font1, width=3, command=self.preprocessing_cloud_removal)
        self.btn_preprocessing_cloud_removal.place(x=280, y=50)

        self.btn_preprocessing_image_registration = Button(root, text="IR", bg="deep sky blue", fg="#fff", font=self.text_font1, width=3, command=self.preprocessing)
        self.btn_preprocessing_image_registration.place(x=200, y=90)
        self.btn_preprocessing_area_interest_extraction = Button(root, text="AI", bg="deep sky blue", fg="#fff", font=self.text_font1, width=3, command=self.preprocessing)
        self.btn_preprocessing_area_interest_extraction.place(x=240, y=90)

        self.label_frame_geospatial_features = LabelFrame(root, text="Geospatial Feature", bg="azure3", fg="#00a800", font=self.frame_font)
        self.label_frame_geospatial_features.place(x=330, y=30, width=130, height=50)
        self.btn_geospatial_features = Button(root, text="Extraction", bg="deep sky blue", fg="#fff", font=self.text_font1, width=13, command=self.preprocessing)
        self.btn_geospatial_features.place(x=340, y=50)

        self.label_frame_spectral_indices = LabelFrame(root, text="Spectral Indices", bg="azure3", fg="#00a800", font=self.frame_font)
        self.label_frame_spectral_indices.place(x=330, y=80, width=130, height=50)
        self.btn_spectral_indices = Button(root, text="Extraction", bg="deep sky blue", fg="#fff", font=self.text_font1, width=13, command=self.preprocessing)
        self.btn_spectral_indices.place(x=340, y=100)

        self.label_frame_dataset_splitting = LabelFrame(root, text="Dataset Splitting", bg="azure3", fg="#00a800", font=self.frame_font)
        self.label_frame_dataset_splitting.place(x=470, y=30, width=130, height=100)
        self.btn_dataset_splitting = Button(root, text="Proceed", bg="deep sky blue", fg="#fff", font=self.text_font1, width=13, height=4, command=self.dataset_splitting)
        self.btn_dataset_splitting.place(x=480, y=50)

        self.label_frame_flood_detection = LabelFrame(root, text="Flood Detection", bg="azure3", fg="#00a800", font=self.frame_font)
        self.label_frame_flood_detection.place(x=610, y=30, width=140, height=100)
        self.btn_flood_detection_training = Button(root, text="Training", bg="deep sky blue", fg="#fff", font=self.text_font1, width=6, command=self.flood_detection_training)
        self.btn_flood_detection_training.place(x=620, y=50)
        self.btn_flood_detection_testing = Button(root, text="Testing", bg="deep sky blue", fg="#fff", font=self.text_font1, width=6, command=self.flood_detection_testing)
        self.btn_flood_detection_testing.place(x=680, y=50)
        self.btn_flood_detection_testing = Button(root, text="Detection", bg="deep sky blue", fg="#fff", font=self.text_font1, width=14, height=2, command=self.flood_detection_testing)
        self.btn_flood_detection_testing.place(x=620, y=80)

        self.label_tables_graphs = LabelFrame(root, text="Tables &\nGraphs", bg="azure3", fg="#FF6A6A", font=self.frame_font)
        self.label_tables_graphs.place(x=900, y=30, width=80, height=60)
        self.btn_tables_graphs = Button(root, text="Generate", bg="deep sky blue", fg="#fff", width=8, command=self.tables_graphs)
        self.btn_tables_graphs.place(x=910, y=60)

        self.btn_clear = Button(root, text="Clear", bg="deep sky blue", fg="#fff", width=3, height=1, command=self.clear)
        self.btn_clear.place(x=900, y=100)
        self.btn_exit = Button(root, text="Exit", bg="deep sky blue", fg="#fff", width=3, height=1, command=self.exit)
        self.btn_exit.place(x=950, y=100)

        ######################################################################################
        # Horizontal (x) Scroll bar
        self.xscrollbar = Scrollbar(root, orient=HORIZONTAL)
        self.xscrollbar.pack(side=BOTTOM, fill=X)
        # Vertical (y) Scroll Bar
        self.yscrollbar = Scrollbar(root)
        self.yscrollbar.pack(side=RIGHT, fill=Y)

        self.label_output_frame = LabelFrame(root, text="Process Window", bg="azure3", fg="#0000FF", font=self.frame_process_res_font)
        self.label_output_frame.place(x=10, y=130, width=590, height=500)
        self.data_textarea_process = Text(root, wrap=WORD, xscrollcommand=self.xscrollbar.set, yscrollcommand=self.yscrollbar.set)
        self.data_textarea_process.pack()
        self.xscrollbar.config(command=self.data_textarea_process.xview)
        self.yscrollbar.config(command=self.data_textarea_process.yview)
        self.data_textarea_process.place(x=20, y=150, width=570, height=470)
        self.data_textarea_process.configure(state="disabled")

        self.label_output_frame = LabelFrame(root, text="Result Window", bg="azure3", fg="#0000FF", font=self.frame_process_res_font)
        self.label_output_frame.place(x=610, y=130, width=370, height=500)
        self.data_textarea_result = Text(root, wrap=WORD, xscrollcommand=self.xscrollbar.set, yscrollcommand=self.yscrollbar.set)
        self.data_textarea_result.pack()
        self.xscrollbar.config(command=self.data_textarea_result.xview)
        self.yscrollbar.config(command=self.data_textarea_result.yview)
        self.data_textarea_result.place(x=620, y=150, width=350, height=470)
        self.data_textarea_result.configure(state="disabled")

        # ##################################################################################

        if not os.path.exists("..\\Output\\"):
            os.makedirs("..\\Output\\")

        if not os.path.exists("..\\Models\\"):
            os.makedirs("..\\Models\\")

    def multispectral_dataset(self):
            self.boolDatasetRead = True
            self.boolRead = True
            self.data_textarea_process.configure(state="normal")

            print("\nMulti-temporal satellite image Dataset")
            print("=======================================")
            self.data_textarea_process.insert(INSERT, "\n\nMulti-temporal satellite image Dataset")
            self.data_textarea_process.insert(INSERT, "\n=======================================")

            if not os.path.exists("..\\Dataset\\Masks\\"):
                Mask_Creation.mc(self)

            print("\nMulti-temporal satellite image Dataset was read Successfully...")
            self.data_textarea_process.insert(INSERT, "\n\nMulti-temporal satellite image Dataset was read Successfully...")
            messagebox.showinfo("showinfo", "Multi-temporal satellite image Dataset was read Successfully...")

            self.btn_multispectral_dataset.configure(state="disabled")
            self.data_textarea_process.configure(state="disabled")

    def multispectral_testing_data(self):
        if os.path.exists("..\\Models\\"):
            self.boolRead = True
            self.data_textarea_process.configure(state="normal")
            self.txt_multispectral_testing_data.configure(state="normal")
            self.txt_multispectral_testing_data.delete(0, len(self.txt_multispectral_testing_data.get()))

            self.testing_data_fpath = askopenfile(mode='r', filetypes=[('All Files', '*')])

            self.data_textarea_process.configure(state="normal")
            self.data_textarea_process.delete("1.0", "end")
            self.data_textarea_process.configure(state="disabled")
            self.data_textarea_result.configure(state="normal")
            self.data_textarea_result.delete("1.0", "end")
            self.data_textarea_result.configure(state="disabled")

            print("\nTesting Data")
            print("==============")
            self.data_textarea_process.insert(INSERT, "\n\nTesting Data")
            self.data_textarea_process.insert(INSERT, "\n==============")


            a = str(self.testing_data_fpath.name).split("/")

            self.txt_multispectral_testing_data.insert(INSERT, "" + str(a[len(a) - 1]))

            print("\nTesting data was selected successfully...")
            self.data_textarea_process.insert(INSERT, "\n\nTesting data was selected successfully...")
            messagebox.showinfo("Info Message", "Testing data was selected successfully...")

            self.txt_multispectral_testing_data.configure(state="disabled")
            self.data_textarea_process.configure(state="disabled")
            self.btn_multispectral_testing_data.configure(state="disabled")

            # self.btn_mvi.configure(state="normal")
            # self.btn_olr.configure(state="normal")
            # self.btn_normalization.configure(state="normal")
            # self.btn_feature_extraction.configure(state="normal")
            # self.btn_feature_fusion.configure(state="normal")
            # self.btn_feature_selection.configure(state="normal")
            # self.btn_dimensionality_reduction.configure(state="normal")
            # self.btn_flood_detection.configure(state="normal")
            # self.btn_heart_disease_stage.configure(state="normal")
        else:
            messagebox.showinfo("showinfo", "Please done Heart Disease Prediction Training first...")

    def preprocessing_radiometric_correction(self):
        if self.boolRead:
            self.data_textarea_process.configure(state="normal")
            print("\nPre-processing: Radiometric Correction")
            print("========================================")
            self.data_textarea_process.insert(INSERT, "\n\nPre-processing: Radiometric Correction")
            self.data_textarea_process.insert(INSERT, "\n========================================")

            if self.boolDatasetRead:
                Preprocessing.radiometric_correction(self)


            print("\nPre-processing: Radiometric Correction was done Successfully...")
            self.data_textarea_process.insert(INSERT, "\n\nPre-processing: Radiometric Correction was done Successfully...")
            messagebox.showinfo("showinfo", "Pre-processing: Radiometric Correction was done Successfully...")

            self.btn_preprocessing_radiometric_correction.configure(state="disabled")
            self.data_textarea_process.configure(state="disabled")
        else:
            messagebox.showinfo("showinfo", "Please read the Data first...")

    def preprocessing_atmospheric_correction(self):
        if self.boolRead:
            self.data_textarea_process.configure(state="normal")
            print("\nPre-processing: Atmospheric Correction")
            print("========================================")
            self.data_textarea_process.insert(INSERT, "\n\nPre-processing: Atmospheric Correction")
            self.data_textarea_process.insert(INSERT, "\n========================================")

            print("\nPre-processing: Atmospheric Correction was done Successfully...")
            self.data_textarea_process.insert(INSERT, "\n\nPre-processing: Atmospheric Correction was done Successfully...")
            messagebox.showinfo("showinfo", "Pre-processing: Atmospheric Correction was done Successfully...")

            self.btn_preprocessing_atmospheric_correction.configure(state="disabled")
            self.data_textarea_process.configure(state="disabled")
        else:
            messagebox.showinfo("showinfo", "Please read the Data first...")

    def preprocessing_cloud_removal(self):
        if self.boolRead:
            self.data_textarea_process.configure(state="normal")
            print("\nPre-processing: Cloud Removal")
            print("========================================")
            self.data_textarea_process.insert(INSERT, "\n\nPre-processing: Cloud Removal")
            self.data_textarea_process.insert(INSERT, "\n========================================")

            print("\nPre-processing: Cloud Removal was done Successfully...")
            self.data_textarea_process.insert(INSERT, "\n\nPre-processing: Cloud Removal was done Successfully...")
            messagebox.showinfo("showinfo", "Pre-processing: Cloud Removal was done Successfully...")

            self.btn_preprocessing_cloud_removal.configure(state="disabled")
            self.data_textarea_process.configure(state="disabled")
        else:
            messagebox.showinfo("showinfo", "Please read the Data first...")

    def preprocessing(self):
        if self.boolRead:
            self.boolPreprocessing = True
            self.data_textarea_process.configure(state="normal")
            print("\nPre-processing")
            print("================")
            self.data_textarea_process.insert(INSERT, "\n\nPre-processing")
            self.data_textarea_process.insert(INSERT, "\n================")

            if self.boolDatasetRead:
                # if not os.path.exists("..\\Output\\TRTS\\Preprocessing\\Training_Lowercasing.csv"):
                #     tr_lc = []
                #     for x in range(len(self.iptr_data)):
                #         temp = []
                #         temp.append(self.iptr_cls[x])
                #         temp.append(Preprocessing.lowercasing(self, self.iptr_data[x]))
                #         tr_lc.append(temp)
                #     heading = ["Label", "Sentences"]
                #     # Open the file in write mode ('w')
                #     with open("..\\Output\\TRTS\\Preprocessing\\Training_Lowercasing.csv", "w", newline="", encoding="utf-8") as file:
                #         writer = csv.writer(file)
                #         writer.writerow(heading)
                #         writer.writerows(tr_lc)

                if not os.path.exists("..\\Output\\TRTS\\Preprocessing\\Testing_Lowercasing.csv"):
                    ts_lc = []
                    for x in range(len(self.ipts_data)):
                        temp = []
                        temp.append(self.ipts_cls[x])
                        temp.append(Preprocessing.lowercasing(self, self.ipts_data[x]))
                        ts_lc.append(temp)
                    heading = ["Label", "Sentences"]
                    # Open the file in write mode ('w')
                    with open("..\\Output\\TRTS\\Preprocessing\\Testing_Lowercasing.csv", "w", newline="", encoding="utf-8") as file:
                        writer = csv.writer(file)
                        writer.writerow(heading)
                        writer.writerows(ts_lc)
###################################################################################################################################
                # if not os.path.exists("..\\Output\\TRTS\\Preprocessing\\Training_Tokenization.csv"):
                #     tr_tk = []
                #     for x in range(len(self.iptr_data)):
                #         temp = []
                #         temp.append(self.iptr_cls[x])
                #         temp.append(Preprocessing.tokenize(self, self.iptr_data[x]))
                #         tr_tk.append(temp)
                #     heading = ["Label", "Sentences"]
                #     # Open the file in write mode ('w')
                #     with open("..\\Output\\TRTS\\Preprocessing\\Training_Tokenization.csv", "w", newline="", encoding="utf-8") as file:
                #         writer = csv.writer(file)
                #         writer.writerow(heading)
                #         writer.writerows(tr_tk)

                if not os.path.exists("..\\Output\\TRTS\\Preprocessing\\Testing_Tokenization.csv"):
                    ts_tk = []
                    for x in range(len(self.ipts_data)):
                        temp = []
                        temp.append(self.ipts_cls[x])
                        temp.append(Preprocessing.tokenize(self, self.ipts_data[x]))
                        ts_tk.append(temp)
                    heading = ["Label", "Sentences"]
                    # Open the file in write mode ('w')
                    with open("..\\Output\\TRTS\\Preprocessing\\Testing_Tokenization.csv", "w", newline="", encoding="utf-8") as file:
                        writer = csv.writer(file)
                        writer.writerow(heading)
                        writer.writerows(ts_tk)
###################################################################################################################################
                # if not os.path.exists("..\\Output\\TRTS\\Preprocessing\\Training_Stop_Word_Removal.csv"):
                #     tr_swr = []
                #     for x in range(len(self.iptr_data)):
                #         temp = []
                #         temp.append(self.iptr_cls[x])
                #         temp.append(Preprocessing.stop_word_removal(self, self.iptr_data[x]))
                #         tr_swr.append(temp)
                #     heading = ["Label", "Sentences"]
                #     # Open the file in write mode ('w')
                #     with open("..\\Output\\TRTS\\Preprocessing\\Training_Stop_Word_Removal.csv", "w", newline="", encoding="utf-8") as file:
                #         writer = csv.writer(file)
                #         writer.writerow(heading)
                #         writer.writerows(tr_swr)

                if not os.path.exists("..\\Output\\TRTS\\Preprocessing\\Testing_Stop_Word_Removal.csv"):
                    ts_swr = []
                    for x in range(len(self.ipts_data)):
                        temp = []
                        temp.append(self.ipts_cls[x])
                        temp.append(Preprocessing.stop_word_removal(self, self.ipts_data[x]))
                        ts_swr.append(temp)
                    heading = ["Label", "Sentences"]
                    # Open the file in write mode ('w')
                    with open("..\\Output\\TRTS\\Preprocessing\\Testing_Stop_Word_Removal.csv", "w", newline="",
                              encoding="utf-8") as file:
                        writer = csv.writer(file)
                        writer.writerow(heading)
                        writer.writerows(ts_swr)

                if not os.path.exists("..\\Output\\TRTS\\Preprocessing\\Testing_Contraction_Expansion.csv"):
                    ts_ce = []
                    for x in range(len(self.ipts_data)):
                        temp = []
                        temp.append(self.ipts_cls[x])
                        temp.append(Preprocessing.contraction_expansion(self, self.ipts_data[x]))
                        ts_ce.append(temp)
                    heading = ["Label", "Sentences"]
                    # Open the file in write mode ('w')
                    with open("..\\Output\\TRTS\\Preprocessing\\Testing_Contraction_Expansion.csv", "w", newline="",
                              encoding="utf-8") as file:
                        writer = csv.writer(file)
                        writer.writerow(heading)
                        writer.writerows(ts_ce)

                if not os.path.exists("..\\Output\\TRTS\\Preprocessing\\Testing_Part_of_Speech.csv"):
                    ts_pos = []
                    for x in range(len(self.ipts_data)):
                        temp = []
                        temp.append(self.ipts_cls[x])
                        temp.append(Preprocessing.pos(self, self.ipts_data[x]))
                        ts_pos.append(temp)
                    heading = ["Label", "Sentences"]
                    # Open the file in write mode ('w')
                    with open("..\\Output\\TRTS\\Preprocessing\\Testing_Part_of_Speech.csv", "w", newline="",
                              encoding="utf-8") as file:
                        writer = csv.writer(file)
                        writer.writerow(heading)
                        writer.writerows(ts_pos)
            else:
                print("Preprocessing: Lowercasing")
                print("--------------------------")
                testing_lc = []
                for x in range(len(self.ts_data)):
                    temp = []
                    temp.append(Preprocessing.lowercasing(self, self.ts_data[x]))
                    testing_lc.append(temp)
                heading = ["Sentences"]
                # Open the file in write mode ('w')
                with open("..\\Output\\Testing\\Preprocessing\\Lowercasing.csv", "w", newline="", encoding="utf-8") as file:
                    writer = csv.writer(file)
                    writer.writerow(heading)
                    writer.writerows(testing_lc)

                print("\nPreprocessing: Punctuation Removal")
                print("------------------------------------")
                testing_pr = []
                for x in range(len(self.ts_data)):
                    temp = []
                    temp.append(Preprocessing.punctuation_removal(self, self.ts_data[x]))
                    testing_pr.append(temp)
                heading = ["Sentences"]
                # Open the file in write mode ('w')
                with open("..\\Output\\Testing\\Preprocessing\\Punctuation_Removal.csv", "w", newline="",
                          encoding="utf-8") as file:
                    writer = csv.writer(file)
                    writer.writerow(heading)
                    writer.writerows(testing_pr)

                print("\nPreprocessing: Contraction Expansion")
                print("--------------------------------------")
                testing_ce = []
                for x in range(len(self.ts_data)):
                    temp = []
                    temp.append(Preprocessing.contraction_expansion(self, self.ts_data[x]))
                    testing_ce.append(temp)
                heading = ["Sentences"]
                # Open the file in write mode ('w')
                with open("..\\Output\\Testing\\Preprocessing\\Contraction_Expansion.csv", "w", newline="",
                          encoding="utf-8") as file:
                    writer = csv.writer(file)
                    writer.writerow(heading)
                    writer.writerows(testing_ce)

                print("\nPreprocessing: Tokenization")
                print("-----------------------------")
                testing_tkn = []
                for x in range(len(self.ts_data)):
                    temp = []
                    temp.append(Preprocessing.tokenize(self, self.ts_data[x]))
                    testing_tkn.append(temp)
                heading = ["Sentences"]
                # Open the file in write mode ('w')
                with open("..\\Output\\Testing\\Preprocessing\\Tokenization.csv", "w", newline="",
                          encoding="utf-8") as file:
                    writer = csv.writer(file)
                    writer.writerow(heading)
                    writer.writerows(testing_tkn)

                print("\nPreprocessing: Stop Word Removal")
                print("----------------------------------")
                testing_swr = []
                for x in range(len(self.ts_data)):
                    temp = []
                    temp.append(Preprocessing.stop_word_removal(self, self.ts_data[x]))
                    testing_swr.append(temp)
                heading = ["Sentences"]
                # Open the file in write mode ('w')
                with open("..\\Output\\Testing\\Preprocessing\\Stop_Word_Removal.csv", "w", newline="", encoding="utf-8") as file:
                    writer = csv.writer(file)
                    writer.writerow(heading)
                    writer.writerows(testing_swr)

                print("\nPreprocessing: Part of Speech")
                print("----------------------------------")
                testing_pos = []
                for x in range(len(self.ts_data)):
                    temp = []
                    temp.append(Preprocessing.pos(self, self.ts_data[x]))
                    testing_pos.append(temp)
                heading = ["Sentences"]
                # Open the file in write mode ('w')
                with open("..\\Output\\Testing\\Preprocessing\\Part_of_Speech.csv", "w", newline="",
                          encoding="utf-8") as file:
                    writer = csv.writer(file)
                    writer.writerow(heading)
                    writer.writerows(testing_pos)
                ###################################################################################################################################
            print("\nPre-processing was done Successfully...")
            self.data_textarea_process.insert(INSERT, "\n\nPre-processing was done Successfully...")
            messagebox.showinfo("showinfo", "Pre-processing was done Successfully...")

            self.btn_preprocessing.configure(state="disabled")
            self.data_textarea_process.configure(state="disabled")
        else:
            messagebox.showinfo("showinfo", "Please read the Heart Disease Cleveland Dataset first...")

    def sgc(self):
        self.boolPreprocessing = True
        if self.boolPreprocessing:
            self.boolGraphConstruction = True
            self.data_textarea_process.configure(state="normal")
            print("\nSemantic Graph Construction")
            print("=================================")
            self.data_textarea_process.insert(INSERT, "\n\nSemantic Graph Construction")
            self.data_textarea_process.insert(INSERT, "\n=================================")
            self.boolDatasetPreprocessing = True
            if self.boolDatasetPreprocessing:
                self.boolDatasetGraphConstruction = True
                if not os.path.exists("..\\Output\\TRTS\\Testing\\Semantic Graph\\"):
                    os.makedirs("..\\Output\\TRTS\\Testing\\Semantic Graph\\")
                    with open('..\\Output\\TRTS\\Testing\\Preprocessing\\Testing_Stop_Word_Removal.csv', mode='r',
                              encoding='utf-8') as file:
                        # Create a reader object
                        csv_reader = csv.reader(file)
                        header = next(csv_reader)

                        count = 0
                        # Loop through each row in the CSV
                        for row in csv_reader:
                            dpath = "..\\Output\\TRTS\\Testing\\Semantic Graph\\" + str(count)+"_"+str(row[0]) + ".png"
                            Semantic_Graph_Construction.sgc_pmi(self, row[1], dpath)
            else:
                with open('..\\Output\\Testing\\Preprocessing\\Stop_Word_Removal.csv', mode='r', encoding='utf-8') as file:
                    # Create a reader object
                    csv_reader = csv.reader(file)
                    header = next(csv_reader)

                    count = 0
                    # Loop through each row in the CSV
                    for row in csv_reader:
                        dpath = "..\\Output\\Testing\\Semantic Graph\\"+str(count)+".png"
                        Semantic_Graph_Construction.sgc_pmi(self, row[0], dpath)

            print("\nSemantic Graph Construction was done Successfully...")
            self.data_textarea_process.insert(INSERT, "\n\nSemantic Graph Construction was done Successfully...")
            messagebox.showinfo("showinfo", "Semantic Graph Construction was done Successfully...")

            self.btn_sgc.configure(state="disabled")
            self.data_textarea_process.configure(state="disabled")
        else:
            messagebox.showinfo("showinfo", "Please done the Preprocessing first...")

    def word_embedding(self):
        self.boolPreprocessing = True
        if self.boolPreprocessing:
            self.boolWordEmbedding = True
            self.data_textarea_process.configure(state="normal")
            print("\nWord Embedding using RoBERTa")
            print("=================================")
            self.data_textarea_process.insert(INSERT, "\n\nWord Embedding using RoBERTa")
            self.data_textarea_process.insert(INSERT, "\n=================================")
            # self.boolDatasetPreprocessing = True
            if self.boolDatasetPreprocessing:
                self.boolDatasetWordEmbedding = True
                if not os.path.exists("..\\Output\\TRTS\\Testing\\Word Embedding\\"):
                    os.makedirs("..\\Output\\TRTS\\Testing\\Word Embedding\\")
                    with open('..\\Output\\TRTS\\Testing\\Preprocessing\\Testing_Stop_Word_Removal.csv', mode='r',
                              encoding='utf-8') as file:
                        # Create a reader object
                        csv_reader = csv.reader(file)
                        header = next(csv_reader)

                        count = 0
                        # Loop through each row in the CSV
                        # for row in csv_reader:
                        #     Semantic_Graph_Construction.sgc_pmi(self, row[1], dpath)
            else:
                with open('..\\Output\\Testing\\Preprocessing\\Stop_Word_Removal.csv', mode='r',
                          encoding='utf-8') as file:
                    # Create a reader object
                    csv_reader = csv.reader(file)
                    header = next(csv_reader)

                    count = 0
                    tot_vector = []
                    for row in csv_reader:
                        temp = []
                        temp.append(Word_Embedding.we(self, row[0]))
                        tot_vector.append(temp)

                    with open("..\\Output\\Testing\\Word Embedding\\Word_Embedding.csv", "w", newline="",
                              encoding="utf-8") as file:
                        writer = csv.writer(file)
                        writer.writerows(tot_vector)
            print("\nWord Embedding was done Successfully...")
            self.data_textarea_process.insert(INSERT, "\n\nWord Embedding was done Successfully...")
            messagebox.showinfo("showinfo", "Word Embedding was done Successfully...")

            self.btn_word_embedding.configure(state="disabled")
            self.data_textarea_process.configure(state="disabled")
        else:
            messagebox.showinfo("showinfo", "Please done the Preprocessing first...")

    def dataset_preprocessing_normalization(self):
        if self.boolDatasetOLR:
            self.boolDatasetNormalization = True
            self.data_textarea_process.configure(state="normal")
            print("\nPre-processing: Normalization")
            print("===============================")
            self.data_textarea_process.insert(INSERT, "\n\nPre-processing: Normalization")
            self.data_textarea_process.insert(INSERT, "\n===============================")

            if not os.path.exists("..\\Output\\Training\\Preprocessing\\Normalized Data.csv"):
                Normalization.nom(self, "..\\Output\\Training\\Preprocessing\\Outlier Removed Data.csv", "..\\Output\\Training\\Preprocessing\\Normalized Data.csv")

            print("\nNormalization was done Successfully...")
            self.data_textarea_process.insert(INSERT, "\n\nNormalization was done Successfully...")
            messagebox.showinfo("showinfo", "Normalization was done Successfully...")

            self.btn_dataset_preprocessing_normalization.configure(state="disabled")
            self.data_textarea_process.configure(state="disabled")
        else:
            messagebox.showinfo("showinfo", "Please done the Outlier Removal for the Dataset first...")

    def dataset_preprocessing_len(self):
        if self.boolDatasetOLR:
            self.boolDatasetNormalization = True
            self.data_textarea_process.configure(state="normal")
            print("\nPre-processing: Label Encoder")
            print("===============================")
            self.data_textarea_process.insert(INSERT, "\n\nPre-processing: Label Encoder")
            self.data_textarea_process.insert(INSERT, "\n===============================")

            if not os.path.exists("..\\Output\\Training\\Preprocessing\\Label Encoded Data.csv"):
                Label_Encoder.len(self, "..\\Output\\Training\\Preprocessing\\Normalized Data.csv", "..\\Output\\Training\\Preprocessing\\Label Encoded Data.csv")

            print("\nNormalization was done Successfully...")
            self.data_textarea_process.insert(INSERT, "\n\nNormalization was done Successfully...")
            messagebox.showinfo("showinfo", "Normalization was done Successfully...")

            self.btn_dataset_preprocessing_len.configure(state="disabled")
            self.data_textarea_process.configure(state="disabled")
        else:
            messagebox.showinfo("showinfo", "Please done the Outlier Removal for the Dataset first...")

    def dataset_feature_extraction(self):
        if self.boolDatasetNormalization:
            self.boolDatasetFeatureExtraction = True
            self.data_textarea_process.configure(state="normal")
            print("\nFeature Extraction")
            print("====================")
            self.data_textarea_process.insert(INSERT, "\n\nFeature Extraction")
            self.data_textarea_process.insert(INSERT, "\n====================")

            if not os.path.exists("..\\Output\\Training\\Feature Extraction\\Feature Extracted Data.csv"):
                Feature_Extraction.fe(self, "..\\Output\\Training\\Preprocessing\\Label Encoded Data.csv",
                                      "..\\Output\\Training\\Feature Extraction\\Feature Extracted Data.csv", "Training")


            if not os.path.exists("..\\Output\\Training\\Feature Extraction\\Feature Extracted Data MDBN.csv"):
                Feature_Extraction_MDBN.fe(self, "..\\Output\\Training\\Preprocessing\\Label Encoded Data.csv",
                                      "..\\Output\\Training\\Feature Extraction\\Feature Extracted Data MDBN.csv")

            print("\nTotal number of Features: "+str(len(self.header)))
            self.data_textarea_process.insert(INSERT, "\n\nTotal number of Features: "+str(len(self.header)))

            print("\nFeatures are...")
            print("-----------------")
            for x in range(len(self.header)):
                print(self.header[x])

            print("\nFeature Extraction was done Successfully...")
            self.data_textarea_process.insert(INSERT, "\n\nFeature Extraction was done Successfully...")
            messagebox.showinfo("showinfo", "Feature Extraction was done Successfully...")

            self.btn_dataset_feature_extraction.configure(state="disabled")
            self.data_textarea_process.configure(state="disabled")
        else:
            messagebox.showinfo("showinfo", "Please done Label Encoder for the Dataset first...")

    def dataset_feature_fusion(self):
        if self.boolDatasetFeatureExtraction:
            self.boolDatasetFeatureFusion = True
            self.data_textarea_process.configure(state="normal")
            print("\nFeature Fusion using Multi-Level Cardiovascular Feature Fusion (MCFF)")
            print("=======================================================================")
            self.data_textarea_process.insert(INSERT, "\n\nFeature Fusion using Multi-Level Cardiovascular Feature Fusion (MCFF)")
            self.data_textarea_process.insert(INSERT, "\n=================================================")
            Feature_Fusion_MFCC.ff(self, "..\\Output\\Training\\Feature Extraction\\Feature Extracted Data.csv",
                                   "..\\Output\\Training\\Feature Extraction\\Feature Extracted Data MDBN.csv",
                                   "..\\Output\\Training\\Feature Fusion\\Fused Features.csv")
            print("\nFeature Fusion was done Successfully...")
            self.data_textarea_process.insert(INSERT, "\n\nFeature Fusion was done Successfully...")
            messagebox.showinfo("showinfo", "Feature Fusion was done Successfully...")

            self.btn_dataset_feature_fusion.configure(state="disabled")
            self.data_textarea_process.configure(state="disabled")
        else:
            messagebox.showinfo("showinfo", "Please done Feature Extraction for the Dataset first...")

    def dataset_dimensionality_reduction(self):
        if self.boolDatasetFeatureFusion:
            self.boolDatasetDimensionalityReduction = True
            self.data_textarea_process.configure(state="normal")
            print("\nDimensionality Reduction using Principal Component Analysis (PCA)")
            print("===================================================================")
            self.data_textarea_process.insert(INSERT, "\n\nDimensionality Reduction using Principal Component Analysis (PCA)")
            self.data_textarea_process.insert(INSERT, "\n=========================================")

            if not os.path.exists("..\\Output\\Training\\Dimensionality Reduction\\Dimensionality Removed Data.csv"):
                Dimensionality_Reduction_PCA.dr(self, "..\\Output\\Training\\Preprocessing\\Label Encoded Data.csv", "..\\Output\\Training\\Dimensionality Reduction\\Dimensionality Removed Data.csv")

            print("\nDimensionality Reduction was done Successfully...")
            self.data_textarea_process.insert(INSERT, "\n\nDimensionality Reduction was done Successfully...")
            messagebox.showinfo("showinfo", "Dimensionality Reduction was done Successfully...")

            self.btn_dataset_dimensionality_reduction.configure(state="disabled")
            self.data_textarea_process.configure(state="disabled")
        else:
            messagebox.showinfo("showinfo", "Please done Feature Fusion for the Dataset first...")

    def dataset_feature_selection(self):
        if self.boolDatasetFeatureFusion:
            self.boolDatasetFeatureSelection = True
            self.data_textarea_process.configure(state="normal")
            print("\nFeature Selection")
            print("===================")
            self.data_textarea_process.insert(INSERT, "\n\nFeature Selection")
            self.data_textarea_process.insert(INSERT, "\n===================")

            print("\nProposed Neuro Quantum Swarm Resonance Optimization Algorithm (NQSROA)")
            print("------------------------------------------------------------------------")
            self.data_textarea_process.insert(INSERT, "\n\nProposed Neuro Quantum Swarm Resonance Optimization Algorithm (NQSROA)")
            self.data_textarea_process.insert(INSERT, "\n------------------------------------------------------------------------")
            if not os.path.exists("..\\Output\\Training\\Feature Selection\\Proposed NQSROA Selected Feature Data.csv"):
                from EHDP.Feature_Selection import Proposed_NQSROA

            print("\nExisting Harris Hawks Optimization Algorithm (HHOA)")
            print("-----------------------------------------------------")
            self.data_textarea_process.insert(INSERT, "\n\nExisting Harris Hawks Optimization Algorithm (HHOA)")
            self.data_textarea_process.insert(INSERT, "\n-----------------------------------------------------")
            if not os.path.exists("..\\Output\\Training\\Feature Selection\\Existing HHOA Selected Feature Data.csv"):
                from EHDP.Feature_Selection import Existing_HHOA

            print("\nExisting Whale Optimization Algorithm (WOA)")
            print("----------------------------------------------")
            self.data_textarea_process.insert(INSERT, "\n\nExisting Whale Optimization Algorithm (WOA)")
            self.data_textarea_process.insert(INSERT, "\n----------------------------------------------")
            if not os.path.exists("..\\Output\\Training\\Feature Selection\\Existing WOA Selected Feature Data.csv"):
                from EHDP.Feature_Selection import Existing_WOA

            print("\nExisting Grey Wolf Optimization Algorithm (GWOA)")
            print("--------------------------------------------------")
            self.data_textarea_process.insert(INSERT, "\n\nExisting Grey Wolf Optimization Algorithm (GWOA)")
            self.data_textarea_process.insert(INSERT, "\n--------------------------------------------------")
            if not os.path.exists("..\\Output\\Training\\Feature Selection\\Existing GWOA Selected Feature Data.csv"):
                from EHDP.Feature_Selection import Existing_GWOA

            print("\nExisting Genetic Algorithm (GA)")
            print("---------------------------------")
            self.data_textarea_process.insert(INSERT, "\n\nExisting Genetic Algorithm (GA)")
            self.data_textarea_process.insert(INSERT, "\n---------------------------------")
            if not os.path.exists("..\\Output\\Training\\Feature Selection\\Existing GA Selected Feature Data.csv"):
                from EHDP.Feature_Selection import Existing_GA

            print("\nExisting Particle Swarm Optimization Algorithm (PSOA)")
            print("-------------------------------------------------------")
            self.data_textarea_process.insert(INSERT, "\n\nExisting Particle Swarm Optimization Algorithm (PSOA)")
            self.data_textarea_process.insert(INSERT, "\n-------------------------------------------------------")
            if not os.path.exists("..\\Output\\Training\\Feature Selection\\Existing PSOA Selected Feature Data.csv"):
                from EHDP.Feature_Selection import Existing_PSOA

            print("\nFeature Selection was done Successfully...")
            self.data_textarea_process.insert(INSERT, "\n\nFeature Selection was done Successfully...")
            messagebox.showinfo("showinfo", "Feature Selection was done Successfully...")

            self.btn_dataset_feature_selection.configure(state="disabled")
            self.data_textarea_process.configure(state="disabled")
        else:
            messagebox.showinfo("showinfo", "Please done Feature Fusion for the Dataset first...")

    def dataset_splitting(self):
        if self.boolDatasetFeatureExtraction:
            self.boolDatasetSplitting = True
            self.data_textarea_process.configure(state="normal")
            print("\nDataset Splitting")
            print("====================")
            self.data_textarea_process.insert(INSERT, "\n\nDataset Splitting")
            self.data_textarea_process.insert(INSERT, "\n====================")

            tr_size = int((len(self.ipdata) * int(self.training_size)) / 100)
            ts_size = int((len(self.ipdata) * int(self.testing_size)) / 100)

            print("\nTotal number of Training Data ("+str(self.training_size)+"%): " + str(tr_size))
            print("Total number of Testing Data ("+str(self.testing_size)+"%): " + str(ts_size))
            self.data_textarea_process.insert(INSERT, "\n\nTotal number of Training Data ("+str(self.training_size)+"%): " + str(tr_size))
            self.data_textarea_process.insert(INSERT, "\nTotal number of Testing Data ("+str(self.testing_size)+"%): " + str(ts_size))

            print("\nDataset Splitting was done Successfully...")
            self.data_textarea_process.insert(INSERT, "\n\nDataset Splitting was done Successfully...")
            messagebox.showinfo("showinfo", "Dataset Splitting was done Successfully...")

            self.btn_dataset_splitting.configure(state="disabled")
            self.data_textarea_process.configure(state="disabled")
        else:
            messagebox.showinfo("showinfo", "Please done the SDN Feature Extraction first...")

    def flood_detection_training(self):
        if self.boolDatasetSplitting:
            self.boolTraining = True
            self.data_textarea_process.configure(state="normal")
            self.data_textarea_result.configure(state="normal")
            self.data_textarea_process.insert(INSERT, "\n\nHeart Disease Prediction Training")
            self.data_textarea_process.insert(INSERT, "\n===================================")
            self.data_textarea_result.insert(INSERT, "\n\nHeart Disease Prediction Training")
            self.data_textarea_result.insert(INSERT, "\n===================================")
            print("\nHeart Disease Prediction Training")
            print("===================================")

            print("Proposed Hybrid Deep Belief Network - stacked Restricted Boltzmann Machines (DBN-sRBM)")
            print("-----------------------------------------")
            self.data_textarea_process.insert(INSERT, "\n\nProposed Hybrid Deep Belief Network - stacked Restricted Boltzmann Machines (DBN-sRBM)")
            self.data_textarea_process.insert(INSERT, "\n-------------------------------------------")
            self.data_textarea_result.insert(INSERT, "\n\nProposed Hybrid DBN-sRBM")
            self.data_textarea_result.insert(INSERT, "\n--------------------------")
            if not os.path.exists("..\\Models\\Proposed\\"):
                os.makedirs("..\\Models\\Proposed\\")
                Proposed.training(self)

            print("Existing Gated Recurrent Unit (GRU)")
            print("-----------------------------------")
            self.data_textarea_process.insert(INSERT, "\n\nExisting Gated Recurrent Unit (GRU)")
            self.data_textarea_process.insert(INSERT, "\n-------------------------------------")
            self.data_textarea_result.insert(INSERT, "\n\nExisting GRU")
            self.data_textarea_result.insert(INSERT, "\n-------------------")
            if not os.path.exists("..\\Models\\Existing GRU\\"):
                os.makedirs("..\\Models\\Existing GRU\\")
                Existing_GRU.training(self)

            print("Existing Convolutional Neural Network (CNN)")
            print("-------------------------------------------")
            self.data_textarea_process.insert(INSERT,"\n\nExisting Convolutional Neural Network (CNN)")
            self.data_textarea_process.insert(INSERT, "\n--------------------------------------------")
            self.data_textarea_result.insert(INSERT, "\n\nExisting CNN")
            self.data_textarea_result.insert(INSERT, "\n--------------")
            if not os.path.exists("..\\Models\\Existing CNN\\"):
                os.makedirs("..\\Models\\Existing CNN\\")
                Existing_CNN.training(self)

            print("Existing Long Short-Term Memory (LSTM)")
            print("--------------------------------------")
            self.data_textarea_process.insert(INSERT,"\n\nExisting Long Short-Term Memory (LSTM)")
            self.data_textarea_process.insert(INSERT, "\n---------------------------------------")
            self.data_textarea_result.insert(INSERT, "\n\nExisting LSTM")
            self.data_textarea_result.insert(INSERT, "\n---------------")
            if not os.path.exists("..\\Models\\Existing LSTM\\"):
                os.makedirs("..\\Models\\Existing LSTM\\")
                Existing_LSTM.training(self)

            print("Existing Recurrent Neural Network (RNN)")
            print("--------------------------------------")
            self.data_textarea_process.insert(INSERT, "\n\nExisting Recurrent Neural Network (RNN)")
            self.data_textarea_process.insert(INSERT, "\n-----------------------------------------")
            self.data_textarea_result.insert(INSERT, "\n\nExisting RNN")
            self.data_textarea_result.insert(INSERT, "\n--------------")
            if not os.path.exists("..\\Models\\Existing RNN\\"):
                os.makedirs("..\\Models\\Existing RNN\\")
                Existing_RNN.training(self)

            print("Existing Deep Neural Network (DNN)")
            print("----------------------------------")
            self.data_textarea_process.insert(INSERT, "\n\nExisting Deep Neural Network (DNN)")
            self.data_textarea_process.insert(INSERT, "\n------------------------------------")
            self.data_textarea_result.insert(INSERT, "\n\nExisting DNN")
            self.data_textarea_result.insert(INSERT, "\n--------------")
            if not os.path.exists("..\\Models\\Existing DNN\\"):
                os.makedirs("..\\Models\\Existing DNN\\")
                Existing_DNN.training(self)

            print("\nHeart Disease Prediction Training was done successfully...")
            self.data_textarea_process.insert(INSERT, "\n\nHeart Disease Prediction Training was done successfully...")
            messagebox.showinfo("Info Message", "Heart Disease Prediction Training was done successfully...")

            self.data_textarea_process.configure(state="disabled")
            self.data_textarea_result.configure(state="disabled")
            self.btn_flood_detection_training.configure(state="disabled")
        else:
            messagebox.showinfo("showinfo", "Please done the Dataset Splitting first...")

    def flood_detection_testing(self):
        if os.path.exists("..\\Models\\"):
            self.boolTesting = True
            self.data_textarea_process.configure(state="normal")
            self.data_textarea_result.configure(state="normal")

            cm = []
            temp = []
            temp.append("TP")
            temp.append("FN")
            cm.append(temp)

            temp = []
            temp.append("FP")
            temp.append("TN")
            cm.append(temp)
            metrics = ["Accuracy", "Precision", "Recall", "F-Score", "Sensitivity", "Specificity", "TPR", "TNR", "PPV", "NPV", "FPR", "FNR", "MCC", "Cohen's Kappa"]

            self.data_textarea_process.insert(INSERT, "\n\nHeart Disease Prediction Testing")
            self.data_textarea_process.insert(INSERT, "\n===================================")
            self.data_textarea_result.insert(INSERT, "\n\nHeart Disease Prediction Testing")
            self.data_textarea_result.insert(INSERT, "\n===================================")
            print("\nHeart Disease Prediction Testing")
            print("===================================")

            print("Proposed Motif-Enhanced Dense Graph Convolutional Networks (MD-GCN) Algorithm")
            print("-----------------------------------------------------------------------------")
            self.data_textarea_process.insert(INSERT, "\n\nProposed Proposed Motif-Enhanced Dense Graph Convolutional Networks (MD-GCN) Algorithm")
            self.data_textarea_process.insert(INSERT, "\n---------------------------------------------------")
            self.data_textarea_result.insert(INSERT, "\n\nProposed MD-GCN Algorithm")
            self.data_textarea_result.insert(INSERT, "\n---------------------------")
            values = Proposed_MDGCN.testing(self)

            for x in range(len(metrics)):
                print(str(metrics[x])+": "+str(values[x]))
                self.data_textarea_result.insert(INSERT, "\n"+metrics[x]+": "+str(values[x]))

            print("Existing Bidirectional Long Short-Term Memory (Attention-BiLSTM)")
            print("----------------------------------------------------------------")
            self.data_textarea_process.insert(INSERT, "\n\nExisting Bidirectional Long Short-Term Memory (Attention-BiLSTM)")
            self.data_textarea_process.insert(INSERT, "\n-----------------------------------------------")
            self.data_textarea_result.insert(INSERT, "\n\nExisting Attention-BiLSTM")
            self.data_textarea_result.insert(INSERT, "\n----------------------------")
            values = Existing_Attention_BiLSTM.testing(self)

            for x in range(len(metrics)):
                print(str(metrics[x])+": "+str(values[x]))
                self.data_textarea_result.insert(INSERT, "\n"+metrics[x]+": "+str(values[x]))

            print("Existing Bidirectional Long Short-Term Memory (BiLSTM)")
            print("------------------------------------------------------")
            self.data_textarea_process.insert(INSERT,"\n\nExisting Bidirectional Long Short-Term Memory (BiLSTM)")
            self.data_textarea_process.insert(INSERT, "\n-------------------------------------------------------")
            self.data_textarea_result.insert(INSERT, "\n\nExisting BiLSTM")
            self.data_textarea_result.insert(INSERT, "\n-----------------")
            values = Existing_BiLSTM.testing(self)

            for x in range(len(metrics)):
                print(str(metrics[x])+": "+str(values[x]))
                self.data_textarea_result.insert(INSERT, "\n"+metrics[x]+": "+str(values[x]))

            print("Existing Convolutional Neural Network (CNN)")
            print("-------------------------------------------")
            self.data_textarea_process.insert(INSERT, "\n\nExisting Convolutional Neural Network (CNN)")
            self.data_textarea_process.insert(INSERT, "\n---------------------------------------------")
            self.data_textarea_result.insert(INSERT, "\n\nExisting CNN")
            self.data_textarea_result.insert(INSERT, "\n---------------")
            values = Existing_CNN.testing(self)

            for x in range(len(metrics)):
                print(str(metrics[x])+": "+str(values[x]))
                self.data_textarea_result.insert(INSERT, "\n"+metrics[x]+": "+str(values[x]))

            print("\nExisting Support Vector Machine (SVM)")
            print("--------------------------------------")
            self.data_textarea_process.insert(INSERT, "\n\nExisting Support Vector Machine (SVM)")
            self.data_textarea_process.insert(INSERT, "\n------------------------------------------------")
            self.data_textarea_result.insert(INSERT, "\n\nExisting SVM")
            self.data_textarea_result.insert(INSERT, "\n---------------")
            values = Existing_SVM.testing(self)

            for x in range(len(metrics)):
                print(str(metrics[x])+": "+str(values[x]))
                self.data_textarea_result.insert(INSERT, "\n"+metrics[x]+": "+str(values[x]))

            print("\nExisting Naïve Bayes (NB)")
            print("---------------------------")
            self.data_textarea_process.insert(INSERT, "\n\nExisting Naïve Bayes (NB)")
            self.data_textarea_process.insert(INSERT, "\n---------------------------")
            self.data_textarea_result.insert(INSERT, "\n\nExisting NB")
            self.data_textarea_result.insert(INSERT, "\n--------------")
            values = Existing_NB.testing(self)

            for x in range(len(metrics)):
                print(str(metrics[x])+": "+str(values[x]))
                self.data_textarea_result.insert(INSERT, "\n"+metrics[x]+": "+str(values[x]))

            Graph.classification_xlsx(self)
            Graph.APRFSS(self)
            Graph.TPR_TNR_PPV_NPV(self)
            Graph.FNR_FPR(self)
            Graph.MCC_KC(self)
            print("\nHeart Disease Prediction Testing was done successfully...")
            self.data_textarea_process.insert(INSERT, "\n\nHeart Disease Prediction Testing was done successfully...")
            messagebox.showinfo("Info Message", "Heart Disease Prediction Testing was done successfully...")

            self.data_textarea_process.configure(state="disabled")
            self.data_textarea_result.configure(state="disabled")
            self.btn_flood_detection_testing.configure(state="disabled")
        else:
            messagebox.showinfo("showinfo", "Please done Heart Disease Prediction Training first...")

    def testing_data(self):
        if os.path.exists("..\\Models\\"):
            self.boolTesingDataRead = True
            self.data_textarea_process.configure(state="normal")
            self.txt_testing_data.configure(state="normal")
            self.txt_testing_data.delete(0, len(self.txt_testing_data.get()))

            self.testing_data = askopenfile(mode='r', filetypes=[('All Files', '*')])

            with open(self.testing_data.name, newline="", encoding="utf-8") as file:
                reader = csv.reader(file)
                self.header = next(reader)  # first row (heading)
                self.ipdata = list(reader)  # remaining rows (data)

            self.data_textarea_process.configure(state="normal")
            self.data_textarea_process.delete("1.0", "end")
            self.data_textarea_process.configure(state="disabled")
            self.data_textarea_result.configure(state="normal")
            self.data_textarea_result.delete("1.0", "end")
            self.data_textarea_result.configure(state="disabled")

            print("\nTesting Data")
            print("==============")
            self.data_textarea_process.insert(INSERT, "\n\nTesting Data")
            self.data_textarea_process.insert(INSERT, "\n==============")

            a = str(self.testing_data.name).split("/")

            self.txt_testing_data.insert(INSERT, "" + str(a[len(a) - 1]))

            print("\nTotal number of Testing Data: " + str(len(self.ipdata)))
            self.data_textarea_process.insert(INSERT, "\n\nTotal number of Testing Data: " + str(len(self.ipdata)))

            print("\nTesting data was selected successfully...")
            self.data_textarea_process.insert(INSERT, "\n\nTesting data was selected successfully...")
            messagebox.showinfo("Info Message", "Testing data was selected successfully...")

            self.txt_testing_data.configure(state="disabled")
            self.data_textarea_process.configure(state="disabled")
            self.btn_testing_data.configure(state="disabled")

            self.btn_mvi.configure(state="normal")
            self.btn_olr.configure(state="normal")
            self.btn_normalization.configure(state="normal")
            self.btn_feature_extraction.configure(state="normal")
            self.btn_feature_fusion.configure(state="normal")
            self.btn_feature_selection.configure(state="normal")
            self.btn_dimensionality_reduction.configure(state="normal")
            self.btn_flood_detection.configure(state="normal")
            self.btn_heart_disease_stage.configure(state="normal")
        else:
            messagebox.showinfo("showinfo", "Please done Heart Disease Prediction Training first...")

    def mvi(self):
        if self.boolTesingDataRead:
            self.boolMVI = True
            self.data_textarea_process.configure(state="normal")
            print("\nPre-processing: Missing Value Imputation")
            print("==========================================")
            self.data_textarea_process.insert(INSERT, "\n\nPre-processing: Missing Value Imputation")
            self.data_textarea_process.insert(INSERT, "\n==========================================")

            Missing_Value_Imputation.mvi(self, self.testing_data.name, "..\\Output\\Testing\\Missing Value Imputated Data.csv")

            print("\nMissing Value Imputation was done Successfully...")
            self.data_textarea_process.insert(INSERT, "\n\nMissing Value Imputation was done Successfully...")
            messagebox.showinfo("showinfo", "Missing Value Imputation was done Successfully...")

            self.btn_mvi.configure(state="disabled")
            self.data_textarea_process.configure(state="disabled")
        else:
            messagebox.showinfo("showinfo", "Please select the Testing Data first...")

    def olr(self):
        if self.boolMVI:
            self.boolOLR = True
            self.data_textarea_process.configure(state="normal")
            print("\nPre-processing: Outlier Removal")
            print("=================================")
            self.data_textarea_process.insert(INSERT, "\n\nPre-processing: Outlier Removal")
            self.data_textarea_process.insert(INSERT, "\n=================================")

            Outlier_Removal.olr(self, "..\\Output\\Testing\\Missing Value Imputated Data.csv", "..\\Output\\Testing\\Outlier Removed Data.csv")

            print("\nOutlier Removal was done Successfully...")
            self.data_textarea_process.insert(INSERT, "\n\nOutlier Removal was done Successfully...")
            messagebox.showinfo("showinfo", "Outlier Removal was done Successfully...")

            self.btn_olr.configure(state="disabled")
            self.data_textarea_process.configure(state="disabled")
        else:
            messagebox.showinfo("showinfo", "Please done Missing Value Imputation for Testing Data first...")

    def normalization(self):
        if self.boolOLR:
            self.boolNormalization = True
            self.data_textarea_process.configure(state="normal")
            print("\nPre-processing: Normalization")
            print("===============================")
            self.data_textarea_process.insert(INSERT, "\n\nPre-processing: Normalization")
            self.data_textarea_process.insert(INSERT, "\n===============================")

            spath = "..\\Output\\Testing\\Outlier Removed Data.csv"
            dpath = "..\\Output\\Testing\\Normalized Data.csv"
            # Load CSV file
            df = pd.read_csv(spath)

            # Normalize feature columns
            scaler = MinMaxScaler()
            X_normalized = pd.DataFrame(
                scaler.fit_transform(df),
                columns=df.columns
            )

            # Save to new CSV file
            X_normalized.to_csv(dpath, index=False)

            print("\nNormalization was done Successfully...")
            self.data_textarea_process.insert(INSERT, "\n\nNormalization was done Successfully...")
            messagebox.showinfo("showinfo", "Normalization was done Successfully...")

            self.btn_normalization.configure(state="disabled")
            self.data_textarea_process.configure(state="disabled")
        else:
            messagebox.showinfo("showinfo", "Please done Outlier Removal for Testing Data first...")

    def feature_extraction(self):
        if self.boolNormalization:
            self.boolFeatureExtraction = True
            self.data_textarea_process.configure(state="normal")
            print("\nFeature Extraction")
            print("====================")
            self.data_textarea_process.insert(INSERT, "\n\nFeature Extraction")
            self.data_textarea_process.insert(INSERT, "\n====================")

            Feature_Extraction.fe(self, "..\\Output\\Testing\\Normalized Data.csv", "..\\Output\\Testing\\Feature Extracted Data.csv", "Testing")
            Feature_Extraction_MDBN.fe(self, "..\\Output\\Testing\\Normalized Data.csv",
                                  "..\\Output\\Testing\\Feature Extracted Data MDBN.csv")

            print("\nTotal number of Features: "+str(len(self.header)))
            self.data_textarea_process.insert(INSERT, "\n\nTotal number of Features: "+str(len(self.header)))

            print("\nFeatures are...")
            print("-----------------")
            for x in range(len(self.header)):
                print(self.header[x])

            print("\nFeature Extraction was done Successfully...")
            self.data_textarea_process.insert(INSERT, "\n\nFeature Extraction was done Successfully...")
            messagebox.showinfo("showinfo", "Feature Extraction was done Successfully...")

            self.btn_feature_extraction.configure(state="disabled")
            self.data_textarea_process.configure(state="disabled")
        else:
            messagebox.showinfo("showinfo", "Please done Normalization for Testing Data first...")

    def feature_fusion(self):
        if self.boolNormalization:
            self.boolFeatureFusion = True
            self.data_textarea_process.configure(state="normal")
            print("\nFeature Fusion using Multi-Level Cardiovascular Feature Fusion (MCFF)")
            print("=======================================================================")
            self.data_textarea_process.insert(INSERT,
                                              "\n\nFeature Fusion using Multi-Level Cardiovascular Feature Fusion (MCFF)")
            self.data_textarea_process.insert(INSERT, "\n=================================================")
            Feature_Fusion_MFCC.ff(self, "..\\Output\\Testing\\Feature Extracted Data.csv",
                                   "..\\Output\\Testing\\Feature Extracted Data MDBN.csv",
                                   "..\\Output\\Testing\\Fused Features.csv")

            print("\nFeature Fusion was done Successfully...")
            self.data_textarea_process.insert(INSERT, "\n\nFeature Fusion was done Successfully...")
            messagebox.showinfo("showinfo", "Feature Fusion was done Successfully...")

            self.btn_feature_fusion.configure(state="disabled")
            self.data_textarea_process.configure(state="disabled")
        else:
            messagebox.showinfo("showinfo", "Please done Feature Extraction for Testing Data first...")

    def feature_selection(self):
        if self.boolFeatureFusion:
            self.boolFeatureSelection = True
            self.data_textarea_process.configure(state="normal")
            print("\nFeature Selection")
            print("====================")
            self.data_textarea_process.insert(INSERT, "\n\nFeature Selection")
            self.data_textarea_process.insert(INSERT, "\n====================")

            print("\nProposed Neuro Quantum Swarm Resonance Optimization Algorithm (NQSROA)")
            print("------------------------------------------------------------------------")
            self.data_textarea_process.insert(INSERT, "\n\nProposed Neuro Quantum Swarm Resonance Optimization Algorithm (NQSROA)")
            self.data_textarea_process.insert(INSERT, "\n------------------------------------------------------------------------")

            print("\nFeature Extraction was done Successfully...")
            self.data_textarea_process.insert(INSERT, "\n\nFeature Extraction was done Successfully...")
            messagebox.showinfo("showinfo", "Feature Extraction was done Successfully...")

            self.btn_feature_selection.configure(state="disabled")
            self.data_textarea_process.configure(state="disabled")
        else:
            messagebox.showinfo("showinfo", "Please done Feature Extraction for for Testing Data first...")

    def dimensionality_reduction(self):
        if self.boolNormalization:
            self.boolDimensionalityReduction = True
            self.data_textarea_process.configure(state="normal")
            print("\nDimensionality Reduction using Principal Component Analysis (PCA)")
            print("===================================================================")
            self.data_textarea_process.insert(INSERT, "\n\nDimensionality Reduction using Principal Component Analysis (PCA)")
            self.data_textarea_process.insert(INSERT, "\n=========================================")

            spath = "..\\Output\\Testing\\Normalized Data.csv"
            dpath = "..\\Output\\Testing\\Dimensionality Removed Data.csv"
            # Load CSV file
            df = pd.read_csv(spath)

            # Standardize features before PCA
            scaler = StandardScaler()
            X_scaled = scaler.fit_transform(df)

            # Apply PCA
            # Set number of principal components
            n_components = 13

            pca = PCA(n_components=n_components)
            X_pca = pca.fit_transform(X_scaled)

            # Create DataFrame for PCA result
            pca_columns = [f"PC{i + 1}" for i in range(n_components)]
            df_pca = pd.DataFrame(X_pca, columns=pca_columns)

            # Save PCA output to CSV
            df_pca.to_csv(dpath, index=False)

            print("\nDimensionality Reduction was done Successfully...")
            self.data_textarea_process.insert(INSERT, "\n\nDimensionality Reduction was done Successfully...")
            messagebox.showinfo("showinfo", "Dimensionality Reduction was done Successfully...")

            self.btn_dimensionality_reduction.configure(state="disabled")
            self.data_textarea_process.configure(state="disabled")
        else:
            messagebox.showinfo("showinfo", "Please done Normalization for Testing Data first...")

    def flood_detection(self):
        if self.boolFeatureSelection and self.boolDimensionalityReduction:
            self.boolPrediction = True
            self.data_textarea_process.configure(state="normal")
            print("\nHeart Disease Prediction using Hybrid Deep Belief Network - stacked Restricted Boltzmann Machines (DBN-sRBM)")
            print("==============================================================================================================")
            self.data_textarea_process.insert(INSERT, "\n\nHeart Disease Prediction using Hybrid Deep Belief Network - stacked Restricted Boltzmann Machines (DBN-sRBM)")
            self.data_textarea_process.insert(INSERT, "\n===========================================================")

            hdata_val = []
            hcol_val = []

            htesting_data = []

            with open("..\\Models\\meta_data.csv", newline="", encoding="utf-8") as file:
                reader = csv.reader(file)
                self.header = next(reader)  # first row (heading)

                for row in reader:
                    hdata_val.append(row[0])
                    hcol_val.append(row[1])

            with open(self.testing_data.name, newline="", encoding="utf-8") as file:
                reader = csv.reader(file)
                self.header = next(reader)  # first row (heading)
                for row in reader:
                    strval = "".join(row)
                    strhval = digest_meta(strval)
                    if hdata_val.__contains__(strhval):
                        print(str(hcol_val[hdata_val.index(strhval)]) + " : " + str(row))

            print("\nHeart Disease Prediction was done Successfully...")
            self.data_textarea_process.insert(INSERT, "\n\nHeart Disease Prediction was done Successfully...")
            messagebox.showinfo("showinfo", "Heart Disease Prediction was done Successfully...")

            self.btn_flood_detection.configure(state="disabled")
            self.data_textarea_process.configure(state="disabled")
        else:
            messagebox.showinfo("showinfo", "Please done the Feature Selection and Dimensionality Reduction for Testing Data first...")

    def heart_disease_stage(self):
        if self.boolPrediction:
            self.data_textarea_process.configure(state="normal")
            print("\nHeart Disease Stage Classification using Cardiovascular Resonance Stability Index (Φ_CRS)")
            print("===========================================================================================")
            self.data_textarea_process.insert(INSERT,"\n\nHeart Disease Stage Classification using Cardiovascular Resonance Stability Index (Φ_CRS)")
            self.data_textarea_process.insert(INSERT, "\n===========================================================")

            Feature_Stability_Analysis.stage(self, "..\\Output\\Testing\\Normalized Data.csv", "..\\Output\\Testing\\Stage.csv")

            print("\nHeart Disease Stage Classification was done Successfully...")
            self.data_textarea_process.insert(INSERT, "\n\nHeart Disease Stage Classification was done Successfully...")
            messagebox.showinfo("showinfo", "Heart Disease Stage Classification was done Successfully...")

            self.btn_heart_disease_stage.configure(state="disabled")
            self.data_textarea_process.configure(state="disabled")
            self.btn_testing_data.configure(state="normal")
            self.txt_testing_data.configure(state="normal")
            self.txt_testing_data.delete(0, len(self.txt_testing_data.get()))
            self.txt_testing_data.configure(state="disabled")
        else:
            messagebox.showinfo("showinfo",
                                "Please done the Feature Selection and Dimensionality Reduction for Testing Data first...")

    def clear(self):
        self.btn_heart_disease_dataset.configure(state="normal")
        self.btn_dataset_preprocessing_mvi.configure(state="normal")
        self.btn_dataset_preprocessing_olr.configure(state="normal")
        self.btn_dataset_preprocessing_normalization.configure(state="normal")
        self.btn_dataset_preprocessing_len.configure(state="normal")
        self.btn_dataset_feature_extraction.configure(state="normal")
        self.btn_dataset_feature_fusion.configure(state="normal")
        self.btn_dataset_feature_selection.configure(state="normal")
        self.btn_dataset_dimensionality_reduction.configure(state="normal")
        self.btn_dataset_splitting.configure(state="normal")
        self.btn_flood_detection_training.configure(state="normal")
        self.btn_flood_detection_testing.configure(state="normal")

        self.btn_testing_data.configure(state="normal")
        self.btn_mvi.configure(state="normal")
        self.btn_olr.configure(state="normal")
        self.btn_normalization.configure(state="normal")
        self.btn_feature_extraction.configure(state="normal")
        self.btn_feature_fusion.configure(state="normal")
        self.btn_feature_selection.configure(state="normal")
        self.btn_dimensionality_reduction.configure(state="normal")
        self.btn_flood_detection.configure(state="normal")
        self.btn_heart_disease_stage.configure(state="normal")

        self.txt_testing_data.configure(state="normal")
        self.txt_testing_data.delete(0, len(self.txt_testing_data.get()))
        self.txt_testing_data.configure(state="disabled")
        self.data_textarea_process.configure(state="normal")
        self.data_textarea_process.delete("1.0", "end")
        self.data_textarea_process.configure(state="disabled")
        self.data_textarea_result.configure(state="normal")
        self.data_textarea_result.delete("1.0", "end")
        self.data_textarea_result.configure(state="disabled")

    def tables_graphs(self):
        if self.boolTesting:
            messagebox.showinfo("Info Message", "Tables and Graphs are generated successfully...")
        else:
            messagebox.showinfo("Info Message", "Please done the Heart Disease Prediction Testing first ...")

    def exit(self):
        self.root.destroy()

def digest_meta(value):
    return hashlib.sha512(value.encode("utf-8")).hexdigest()

def getListOfFiles(dirName):
    # create a list of file and sub directories
    # names in the given directory
    listOfFile = os.listdir(dirName)
    allFiles = list()
    # Iterate over all the entries
    for entry in listOfFile:
        # Create full path
        fullPath = os.path.join(dirName, entry)
        # If entry is a directory then get the list of files in this directory
        if os.path.isdir(fullPath):
            allFiles = allFiles + getListOfFiles(fullPath)
        else:
            # if fullPath.endswith(".JPEG"):
            allFiles.append(fullPath)

    return allFiles

root = Tk()
root.title(
    "A HYBRID DEEP LEARNING FRAMEWORK FOR EFFICIENT HEART DISEASE PREDICTION USING MDBN, NQSRO, AND QRCHN")
root.geometry("1000x650")
root.resizable(0, 0)
root.configure(bg="azure3")
od = Main_GUI(root)
root.mainloop()