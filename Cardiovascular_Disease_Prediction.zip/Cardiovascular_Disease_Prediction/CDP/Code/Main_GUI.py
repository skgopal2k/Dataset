import os
# import random
import tkinter
from tkinter import *
from tkinter.filedialog import askopenfile
import cv2
import csv
import numpy as np
from tkinter import messagebox
from tkinter import Tk
import hashlib
# from IoT_AD.Preprocessing.Noise_Removal import Noise_Removal
# from IoT_AD.Code.Feature_Extraction import Feature_Extraction
#
# from IoT_AD import config as cfg


class Main_GUI:
    boolReadDataset = False
    boolDatasetNoiseRemoval = False
    boolDatasetFeatureExtraction = False
    boolDatasetSplitting = False
    boolTraining = False
    boolTesting = False

    boolTesingDataRead = False
    boolNoiseRemoval = False
    boolFeatureExtraction = False
    boolDetection = False

    ipdata = []
    header = []

    training = 80
    testing = 20

    def __init__(self, root):
        self.file_path = StringVar()

        self.LARGE_FONT = ("Algerian", 16)
        self.text_font = ("Constantia", 15)
        self.text_font1 = ("Constantia", 10)

        self.frame_font = ("", 9)
        self.frame_process_res_font = ("", 12)
        self.root = root
        self.feature_value = StringVar()

        label_heading = tkinter.Label(root, text="Cardiovascular Disease Prediction using HM-AFTR and ACLRN", fg="deep pink", bg="azure3", font=self.LARGE_FONT)
        label_heading.place(x=150, y=0)

        self.label_frame_bot_iot_dataset = LabelFrame(root, text="Heart Disease Dataset", bg="azure3", fg="#00a800", font=self.frame_font)
        self.label_frame_bot_iot_dataset.place(x=10, y=30, width=150, height=80)
        self.entry_bot_iot_dataset = Entry(root, font=self.frame_font)
        self.entry_bot_iot_dataset.place(x=20, y=50, width=130, height=25)
        self.entry_bot_iot_dataset.insert(INSERT, "..\\\\Dataset\\\\heart.csv")
        self.entry_bot_iot_dataset.configure(state="disabled")
        self.btn_bot_iot_dataset = Button(root, text="READ", bg="deep sky blue", fg="#fff", font=self.text_font1, width=15, command=self.bot_iot_dataset)
        self.btn_bot_iot_dataset.place(x=20, y=80)

        self.label_frame_dataset_preprocessing = LabelFrame(root, text="Pre-Processing", bg="azure3", fg="#00a800", font=self.frame_font)
        self.label_frame_dataset_preprocessing.place(x=170, y=30, width=110, height=80)
        self.btn_dataset_preprocessing_ddr = Button(root, text="DDR", bg="deep sky blue", fg="#fff",
                                                              font=self.text_font1, width=4,
                                                              command=self.dataset_preprocessing_noise_removal)
        self.btn_dataset_preprocessing_ddr.place(x=180, y=50)
        self.btn_dataset_preprocessing_mvi = Button(root, text="MVI", bg="deep sky blue", fg="#fff",
                                                              font=self.text_font1, width=4,
                                                              command=self.dataset_preprocessing_noise_removal)
        self.btn_dataset_preprocessing_mvi.place(x=230, y=50)
        self.btn_dataset_preprocessing_num = Button(root, text="NUM", bg="deep sky blue", fg="#fff",
                                                              font=self.text_font1, width=4,
                                                              command=self.dataset_preprocessing_noise_removal)
        self.btn_dataset_preprocessing_num.place(x=180, y=80)
        self.btn_dataset_preprocessing_nom = Button(root, text="NOM", bg="deep sky blue", fg="#fff",
                                                              font=self.text_font1, width=4,
                                                              command=self.dataset_preprocessing_noise_removal)
        self.btn_dataset_preprocessing_nom.place(x=230, y=80)

        self.label_frame_dataset_feature_extraction = LabelFrame(root, text="Feature Extraction", bg="azure3",
                                                                 fg="#00a800", font=self.frame_font)
        self.label_frame_dataset_feature_extraction.place(x=290, y=30, width=110, height=80)
        self.btn_dataset_feature_extraction = Button(root, text="Proceed", bg="deep sky blue", fg="#fff",
                                                     font=self.text_font1, width=10, height=3,
                                                     command=self.dataset_feature_extraction)
        self.btn_dataset_feature_extraction.place(x=300, y=50)

        self.label_frame_dataset_feature_selection = LabelFrame(root, text="Feature Selection", bg="azure3",
                                                                 fg="#00a800", font=self.frame_font)
        self.label_frame_dataset_feature_selection.place(x=410, y=30, width=110, height=80)
        self.btn_dataset_feature_selection = Button(root, text="Proceed", bg="deep sky blue", fg="#fff",
                                                     font=self.text_font1, width=10, height=3,
                                                     command=self.dataset_feature_extraction)
        self.btn_dataset_feature_selection.place(x=420, y=50)

        self.label_frame_dataset_splitting = LabelFrame(root, text="Dataset Splitting", bg="azure3", fg="#00a800",
                                                        font=self.frame_font)
        self.label_frame_dataset_splitting.place(x=530, y=30, width=110, height=80)
        self.btn_dataset_splitting = Button(root, text="Proceed", bg="deep sky blue", fg="#fff", font=self.text_font1,
                                            width=10, height=3, command=self.dataset_splitting)
        self.btn_dataset_splitting.place(x=540, y=50)

        self.label_frame_cardiovascular_disease_prediction = LabelFrame(root, text="Disease Prediction", bg="azure3",
                                                            fg="#00a800", font=self.frame_font)
        self.label_frame_cardiovascular_disease_prediction.place(x=650, y=30, width=120, height=80)
        self.btn_cardiovascular_disease_prediction_training = Button(root, text="Training", bg="deep sky blue", fg="#fff",
                                                         font=self.text_font1, width=11,
                                                         command=self.attack_classification_training)
        self.btn_cardiovascular_disease_prediction_training.place(x=660, y=50)
        self.btn_cardiovascular_disease_prediction_testing = Button(root, text="Testing", bg="deep sky blue", fg="#fff",
                                                        font=self.text_font1, width=11,
                                                        command=self.attack_classification_testing)
        self.btn_cardiovascular_disease_prediction_testing.place(x=660, y=80)

        self.label_tables_graphs = LabelFrame(root, text="Tables & Graphs", bg="azure3", fg="#FF6A6A",
                                              font=self.frame_font)
        self.label_tables_graphs.place(x=780, y=30, width=110, height=50)
        self.btn_tables_graphs = Button(root, text="Generate", bg="deep sky blue", fg="#fff", width=12,
                                        command=self.tables_graphs)
        self.btn_tables_graphs.place(x=790, y=50)

        self.btn_clear = Button(root, text="Clear", bg="deep sky blue", fg="#fff", width=3, height=1,
                                command=self.clear)
        self.btn_clear.place(x=900, y=50)
        self.btn_exit = Button(root, text="Exit", bg="deep sky blue", fg="#fff", width=3, height=1, command=self.exit)
        self.btn_exit.place(x=940, y=50)

        ######################################################################################
        # Horizontal (x) Scroll bar
        self.xscrollbar = Scrollbar(root, orient=HORIZONTAL)
        self.xscrollbar.pack(side=BOTTOM, fill=X)
        # Vertical (y) Scroll Bar
        self.yscrollbar = Scrollbar(root)
        self.yscrollbar.pack(side=RIGHT, fill=Y)

        self.label_output_frame = LabelFrame(root, text="Process Window", bg="azure3", fg="#0000FF",
                                             font=self.frame_process_res_font)
        self.label_output_frame.place(x=170, y=110, width=470, height=520)
        # Text Widget
        self.data_textarea_process = Text(root, wrap=WORD, xscrollcommand=self.xscrollbar.set,
                                          yscrollcommand=self.yscrollbar.set)
        self.data_textarea_process.pack()
        # Configure the scrollbars
        self.xscrollbar.config(command=self.data_textarea_process.xview)
        self.yscrollbar.config(command=self.data_textarea_process.yview)
        self.data_textarea_process.place(x=180, y=130, width=450, height=490)
        self.data_textarea_process.configure(state="disabled")

        self.label_output_frame = LabelFrame(root, text="Result Window", bg="azure3", fg="#0000FF",
                                             font=self.frame_process_res_font)
        self.label_output_frame.place(x=650, y=110, width=330, height=520)
        # Text Widget
        self.data_textarea_result = Text(root, wrap=WORD, xscrollcommand=self.xscrollbar.set,
                                         yscrollcommand=self.yscrollbar.set)
        self.data_textarea_result.pack()
        # Configure the scrollbars
        self.xscrollbar.config(command=self.data_textarea_result.xview)
        self.yscrollbar.config(command=self.data_textarea_result.yview)
        self.data_textarea_result.place(x=660, y=130, width=310, height=490)
        self.data_textarea_result.configure(state="disabled")

        #################################################################################
        self.label_testing_data = LabelFrame(root, text="Select Testing File", bg="azure3", fg="#9C661F",
                                             font=self.frame_font)
        self.label_testing_data.place(x=10, y=110, width=150, height=80)
        self.txt_testing_data = Entry(root)
        self.txt_testing_data.configure(state="disabled")
        self.txt_testing_data.place(x=20, y=130, width=130, height=25)
        self.btn_testing_data = Button(root, text="Browse", bg="deep sky blue", fg="#fff", width=15,
                                       font=self.text_font1, command=self.testing_data)
        self.btn_testing_data.place(x=20, y=160)

        self.label_preprocessing = LabelFrame(root, text="Preprocessing", bg="azure3", fg="#9C661F",
                                              font=self.frame_font)
        self.label_preprocessing.place(x=10, y=190, width=150, height=50)
        self.btn_noise_removal = Button(root, text="Proceed", bg="deep sky blue", fg="#fff", width=15,
                                        font=self.text_font1, command=self.noise_removal)
        self.btn_noise_removal.place(x=20, y=220)
        #
        # self.label_feature_extraction = LabelFrame(root, text="Feature Extraction", bg="azure3", fg="#9C661F",
        #                                            font=self.frame_font)
        # self.label_feature_extraction.place(x=10, y=210, width=190, height=50)
        # self.btn_feature_extraction = Button(root, text="Resize", bg="deep sky blue", fg="#fff", width=20,
        #                                      font=self.text_font1, command=self.feature_extraction)
        # self.btn_feature_extraction.place(x=20, y=230)
        #
        # self.label_attack_detection = LabelFrame(root, text="IoT Attack Detection", bg="azure3", fg="#9C661F",
        #                                          font=self.frame_font)
        # self.label_attack_detection.place(x=10, y=320, width=190, height=50)
        # self.btn_attack_detection = Button(root, text="Proceed", bg="deep sky blue", fg="#fff", width=20,
        #                                    font=self.text_font1, command=self.attack_detection)
        # self.btn_attack_detection.place(x=20, y=340)

        ##################################################################################

        if not os.path.exists("..\\Output\\"):
            os.makedirs("..\\Output\\")

        if not os.path.exists("..\\Output\\Training\\"):
            os.makedirs("..\\Output\\Training\\")

        if not os.path.exists("..\\Output\\Testing\\"):
            os.makedirs("..\\Output\\Testing\\")

        if not os.path.exists("..\\CM\\"):
            os.mkdir("..\\CM\\")

    def bot_iot_dataset(self):
        self.boolReadDataset = True
        self.data_textarea_process.configure(state="normal")
        self.image_dataset = getListOfFiles("..\\Dataset\\")

        print("\nBoT-IoT Dataset")
        print("=================")
        self.data_textarea_process.insert(INSERT, "\n\nBoT-IoT Dataset")
        self.data_textarea_process.insert(INSERT, "\n=================")

        with open("..\\Dataset\\BoT_IoT.csv", newline="", encoding="utf-8") as file:
            reader = csv.reader(file)
            self.header = next(reader)  # first row (heading)
            for row in reader:
                data_val = row[:-3]
                col_val = row[-3:]
                strval = "".join(data_val)
                col_val.insert(0, digest_meta(strval))
                self.ipdata.append(col_val)

        with open("..\\Models\\meta_data.csv", "w", newline="", encoding="utf-8") as file:
            writer = csv.writer(file)
            writer.writerows(self.ipdata)

        print("\nTotal number of Data : " + str(len(self.ipdata)))
        self.data_textarea_process.insert(INSERT, "\n\nTotal number of Data : " + str(len(self.ipdata)))

        print("\nBoT-IoT Dataset was read Successfully...")
        self.data_textarea_process.insert(INSERT, "\n\nBoT-IoT Dataset was read Successfully...")
        messagebox.showinfo("showinfo", "BoT-IoT Dataset was read Successfully...")

        self.btn_bot_iot_dataset.configure(state="disabled")
        self.data_textarea_process.configure(state="disabled")

    def dataset_preprocessing_noise_removal(self):
        if self.boolReadDataset:
            self.boolDatasetNoiseRemoval = True
            self.data_textarea_process.configure(state="normal")
            print("\nPre-processing: Noise Removal using Geodesic Filtering (GF)")
            print("=============================================================")
            self.data_textarea_process.insert(INSERT, "\n\nPre-processing: Noise Removal using Geodesic Filtering (GF)")
            self.data_textarea_process.insert(INSERT, "\n==============================================")

            if not os.path.exists("..\\Output\\Training\\Noise Removed Data.csv"):
                Noise_Removal.NR_GF(self, "..\\Dataset\\BoT_IoT.csv", "..\\Output\\Training\\Noise Removed Data.csv")

            print("\nNoise Removal was done Successfully...")
            self.data_textarea_process.insert(INSERT, "\n\nNoise Removal was done Successfully...")
            messagebox.showinfo("showinfo", "Noise Removal was done Successfully...")

            self.btn_dataset_preprocessing_noise_removal.configure(state="disabled")
            self.data_textarea_process.configure(state="disabled")
        else:
            messagebox.showinfo("showinfo", "Please read the BoI-IoT Dataset first...")

    def dataset_feature_extraction(self):
        if self.boolDatasetNoiseRemoval:
            self.boolDatasetFeatureExtraction = True
            self.data_textarea_process.configure(state="normal")
            print("\nFeature Extraction using Adaptive Kernel Force-Invariant Improved (AKFII)")
            print("===========================================================================")
            self.data_textarea_process.insert(INSERT,
                                              "\n\nFeature Extraction using Adaptive Kernel Force-Invariant Improved (AKFII)")
            self.data_textarea_process.insert(INSERT, "\n=====================================================")

            if not os.path.exists("..\\Output\\Training\\Feature Extracted Data.csv"):
                Feature_Extraction.FE_AKFII(self, "..\\Output\\Training\\Noise Removed Data.csv",
                                            "..\\Output\\Training\\Feature Extracted Data.csv")

            print("\nFeature Extraction was done Successfully...")
            self.data_textarea_process.insert(INSERT, "\n\nFeature Extraction was done Successfully...")
            messagebox.showinfo("showinfo", "Feature Extraction was done Successfully...")

            self.btn_dataset_feature_extraction.configure(state="disabled")
            self.data_textarea_process.configure(state="disabled")
        else:
            messagebox.showinfo("showinfo", "Please done the Noise Removal first...")

    def dataset_splitting(self):
        if self.boolDatasetFeatureExtraction:
            self.boolDatasetSplitting = True
            self.data_textarea_process.configure(state="normal")
            print("\nDataset Splitting")
            print("====================")
            self.data_textarea_process.insert(INSERT, "\n\nDataset Splitting")
            self.data_textarea_process.insert(INSERT, "\n====================")

            tr_size = int((len(self.ipdata) * 80) / 100)
            ts_size = int((len(self.ipdata) * 20) / 100)

            print("\nTotal number of Training Data: " + str(tr_size))
            print("Total number of Testing Data: " + str(ts_size))
            self.data_textarea_process.insert(INSERT, "\n\nTotal number of Training Data: " + str(tr_size))
            self.data_textarea_process.insert(INSERT, "\nTotal number of Testing Data: " + str(ts_size))

            print("\nDataset Splitting was done Successfully...")
            self.data_textarea_process.insert(INSERT, "\n\nDataset Splitting was done Successfully...")
            messagebox.showinfo("showinfo", "Dataset Splitting was done Successfully...")

            self.btn_dataset_splitting.configure(state="disabled")
            self.data_textarea_process.configure(state="disabled")
        else:
            messagebox.showinfo("showinfo", "Please done the Feature Extraction first...")

    def attack_classification_training(self):
        if self.boolDatasetSplitting:
            self.boolTraining = True
            self.data_textarea_process.configure(state="normal")
            self.data_textarea_result.configure(state="normal")
            self.data_textarea_process.insert(INSERT, "\n\nAttack Classification Training")
            self.data_textarea_process.insert(INSERT, "\n================================")
            self.data_textarea_result.insert(INSERT, "\n\nAttack Classification Training")
            self.data_textarea_result.insert(INSERT, "\n=================================")
            print("\nAttack Classification Training")
            print("================================")

            print("Proposed Enhanced Evolutionary Gravitational Neocognitron Neural Network (EEGNNN)")
            print("---------------------------------------------------------------------------------")
            self.data_textarea_process.insert(INSERT,
                                              "\n\nProposed Enhanced Evolutionary Gravitational Neocognitron Neural Network (EEGNNN)")
            self.data_textarea_process.insert(INSERT, "\n-----------------------------------------------------")
            self.data_textarea_result.insert(INSERT, "\n\nProposed EEGNNN")
            self.data_textarea_result.insert(INSERT, "\n-----------------")

            print("Existing Convolutional Neural Network - Variational Autoencoders (CNN-VAE)")
            print("---------------------------------------------------------------------------------")
            self.data_textarea_process.insert(INSERT,
                                              "\n\nExisting Convolutional Neural Network - Variational Autoencoders (CNN-VAE)")
            self.data_textarea_process.insert(INSERT, "\n-----------------------------------------------------")
            self.data_textarea_result.insert(INSERT, "\n\nExisting CNN-VAE")
            self.data_textarea_result.insert(INSERT, "\n-----------------")

            print("Existing Convolutional Neural Network - Gated Recurrent Unit (CNN-GRU)")
            print("---------------------------------------")
            self.data_textarea_process.insert(INSERT,
                                              "\n\nExisting Convolutional Neural Network - Gated Recurrent Unit (CNN-GRU)")
            self.data_textarea_process.insert(INSERT, "\n-----------------------------------------")
            self.data_textarea_result.insert(INSERT, "\n\nExisting CNN-GRU")
            self.data_textarea_result.insert(INSERT, "\n-----------------")

            print("Existing Regions with Convolutional Neural Networks - Restricted Boltzmann Machine (RCNN-RBM)")
            print("---------------------------------------------")
            self.data_textarea_process.insert(INSERT,
                                              "\n\nExisting Regions with Convolutional Neural Networks - Restricted Boltzmann Machine (RCNN-RBM)")
            self.data_textarea_process.insert(INSERT, "\n-----------------------------------------------")
            self.data_textarea_result.insert(INSERT, "\n\nExisting RCNN-RBM")
            self.data_textarea_result.insert(INSERT, "\n-----------------")

            print("Existing Bidirectional Gated Recurrent Unit (BiGRU)")
            print("------------------------------------")
            self.data_textarea_process.insert(INSERT, "\n\nExisting Bidirectional Gated Recurrent Unit (BiGRU)")
            self.data_textarea_process.insert(INSERT, "\n--------------------------------------")
            self.data_textarea_result.insert(INSERT, "\n\nExisting BiGRU")
            self.data_textarea_result.insert(INSERT, "\n-----------------")

            print("Existing Elman recurrent neural network (ERNN)")
            print("------------------------------------")
            self.data_textarea_process.insert(INSERT, "\n\nExisting Elman recurrent neural network (ERNN)")
            self.data_textarea_process.insert(INSERT, "\n--------------------------------------")
            self.data_textarea_result.insert(INSERT, "\n\nExisting ERNN")
            self.data_textarea_result.insert(INSERT, "\n-----------------")

            print("Existing Deep Convolutional Neural Networks (DCNN)")
            print("------------------------------------")
            self.data_textarea_process.insert(INSERT, "\n\nExisting Deep Convolutional Neural Networks (DCNN)")
            self.data_textarea_process.insert(INSERT, "\n--------------------------------------")
            self.data_textarea_result.insert(INSERT, "\n\nExisting DCNN")
            self.data_textarea_result.insert(INSERT, "\n-----------------")

            print("\nAttack Classification Training was done successfully...")
            self.data_textarea_process.insert(INSERT, "\n\nAttack Classification Training was done successfully...")
            messagebox.showinfo("Info Message", "Attack Classification Training was done successfully...")

            self.data_textarea_process.configure(state="disabled")
            self.data_textarea_result.configure(state="disabled")
            self.btn_attack_classification_training.configure(state="disabled")
        else:
            messagebox.showinfo("showinfo", "Please done the Dataset Splitting first...")

    def attack_classification_testing(self):
        if os.path.exists("..\\Models\\"):
            self.boolTesting = True
            self.data_textarea_process.configure(state="normal")
            self.data_textarea_result.configure(state="normal")

            cm = []
            temp = []
            temp.append("TP")
            temp.append("FN")
            cm.append(temp)

            temp = []
            temp.append("FP")
            temp.append("TN")
            cm.append(temp)

            self.data_textarea_process.insert(INSERT, "\n\nAttack Classification Testing")
            self.data_textarea_process.insert(INSERT, "\n===============================")
            self.data_textarea_result.insert(INSERT, "\n\nAttack Classification Testing")
            self.data_textarea_result.insert(INSERT, "\n===============================")
            print("\nAttack Classification Testing")
            print("===============================")

            print("Proposed Enhanced Evolutionary Gravitational Neocognitron Neural Network (EEGNNN)")
            print("---------------------------------------------------------------------------------")
            self.data_textarea_process.insert(INSERT,
                                              "\n\nProposed Enhanced Evolutionary Gravitational Neocognitron Neural Network (EEGNNN)")
            self.data_textarea_process.insert(INSERT,
                                              "\n-----------------------------------------------------")
            self.data_textarea_result.insert(INSERT, "\n\nProposed EEGNNN")
            self.data_textarea_result.insert(INSERT, "\n-----------------")

            # Proposed_EEGNNN.testing(self)
            # print("Confusion Matrix : ")
            # for x in range(len(cm)):
            #     print(cm[x])
            # for x in range(len(cm)):
            #     print(str(cfg.PEEGNNN_cm[x]))
            #
            # print("\nPrecision : " + str(cfg.PEEGNNN_pre))
            # print("Recall : " + str(cfg.PEEGNNN_rec))
            # print("FMeasure : " + str(cfg.PEEGNNN_fsc))
            # print("Accuracy : " + str(cfg.PEEGNNN_acc))
            # print("Sensitivity : " + str(cfg.PEEGNNN_sens))
            # print("Specificity : " + str(cfg.PEEGNNN_spec))
            # print("TPR : " + str(cfg.PEEGNNN_tpr))
            # print("TNR : " + str(cfg.PEEGNNN_tnr))
            # print("PPV : " + str(cfg.PEEGNNN_ppv))
            # print("NPV : " + str(cfg.PEEGNNN_npv))
            # print("FNR : " + str(cfg.PEEGNNN_fnr))
            # print("FPR : " + str(cfg.PEEGNNN_fpr))
            #
            # self.data_textarea_result.insert(INSERT, "\nConfusion Matrix : ")
            # for x in range(len(cm)):
            #     self.data_textarea_result.insert(INSERT, "\n" + str(cm[x]))
            # for x in range(len(cm)):
            #     self.data_textarea_result.insert(INSERT, "\n" + str(cfg.PEEGNNN_cm[x]))
            #
            # self.data_textarea_result.insert(INSERT, "\n\nPrecision : " + str(cfg.PEEGNNN_pre))
            # self.data_textarea_result.insert(INSERT, "\nRecall : " + str(cfg.PEEGNNN_rec))
            # self.data_textarea_result.insert(INSERT, "\nFMeasure : " + str(cfg.PEEGNNN_fsc))
            # self.data_textarea_result.insert(INSERT, "\nAccuracy : " + str(cfg.PEEGNNN_acc))
            # self.data_textarea_result.insert(INSERT, "\nSensitivity : " + str(cfg.PEEGNNN_sens))
            # self.data_textarea_result.insert(INSERT, "\nSpecificity : " + str(cfg.PEEGNNN_spec))
            # self.data_textarea_result.insert(INSERT, "\nTPR : " + str(cfg.PEEGNNN_tpr))
            # self.data_textarea_result.insert(INSERT, "\nTNR : " + str(cfg.PEEGNNN_tnr))
            # self.data_textarea_result.insert(INSERT, "\nPPV : " + str(cfg.PEEGNNN_ppv))
            # self.data_textarea_result.insert(INSERT, "\nNPV : " + str(cfg.PEEGNNN_npv))
            # self.data_textarea_result.insert(INSERT, "\nFNR : " + str(cfg.PEEGNNN_fnr))
            # self.data_textarea_result.insert(INSERT, "\nFPR : " + str(cfg.PEEGNNN_fpr))

            print("Existing Convolutional Neural Network - Variational Autoencoders (CNN-VAE)")
            print("---------------------------------------------------------------------------------")
            self.data_textarea_process.insert(INSERT,
                                              "\n\nExisting Convolutional Neural Network - Variational Autoencoders (CNN-VAE)")
            self.data_textarea_process.insert(INSERT, "\n-----------------------------------------------------")
            self.data_textarea_result.insert(INSERT, "\n\nExisting CNN-VAE")
            self.data_textarea_result.insert(INSERT, "\n-----------------")

            print("Existing Convolutional Neural Network - Gated Recurrent Unit (CNN-GRU)")
            print("---------------------------------------")
            self.data_textarea_process.insert(INSERT,
                                              "\n\nExisting Convolutional Neural Network - Gated Recurrent Unit (CNN-GRU)")
            self.data_textarea_process.insert(INSERT, "\n-----------------------------------------")
            self.data_textarea_result.insert(INSERT, "\n\nExisting CNN-GRU")
            self.data_textarea_result.insert(INSERT, "\n-----------------")

            print("Existing Regions with Convolutional Neural Networks - Restricted Boltzmann Machine (RCNN-RBM)")
            print("---------------------------------------------")
            self.data_textarea_process.insert(INSERT,
                                              "\n\nExisting Regions with Convolutional Neural Networks - Restricted Boltzmann Machine (RCNN-RBM)")
            self.data_textarea_process.insert(INSERT, "\n-----------------------------------------------")
            self.data_textarea_result.insert(INSERT, "\n\nExisting RCNN-RBM")
            self.data_textarea_result.insert(INSERT, "\n-----------------")

            print("Existing Bidirectional Gated Recurrent Unit (BiGRU)")
            print("------------------------------------")
            self.data_textarea_process.insert(INSERT, "\n\nExisting Bidirectional Gated Recurrent Unit (BiGRU)")
            self.data_textarea_process.insert(INSERT, "\n--------------------------------------")
            self.data_textarea_result.insert(INSERT, "\n\nExisting BiGRU")
            self.data_textarea_result.insert(INSERT, "\n-----------------")

            print("Existing Elman recurrent neural network (ERNN)")
            print("------------------------------------")
            self.data_textarea_process.insert(INSERT, "\n\nExisting Elman recurrent neural network (ERNN)")
            self.data_textarea_process.insert(INSERT, "\n--------------------------------------")
            self.data_textarea_result.insert(INSERT, "\n\nExisting ERNN")
            self.data_textarea_result.insert(INSERT, "\n-----------------")

            print("Existing Deep Convolutional Neural Networks (DCNN)")
            print("------------------------------------")
            self.data_textarea_process.insert(INSERT, "\n\nExisting Deep Convolutional Neural Networks (DCNN)")
            self.data_textarea_process.insert(INSERT, "\n--------------------------------------")
            self.data_textarea_result.insert(INSERT, "\n\nExisting DCNN")
            self.data_textarea_result.insert(INSERT, "\n-----------------")

            print("\nAttack Classification Testing was done successfully...")
            self.data_textarea_process.insert(INSERT, "\n\nAttack Classification Testing was done successfully...")
            messagebox.showinfo("Info Message", "Attack Classification Testing was done successfully...")

            self.data_textarea_process.configure(state="disabled")
            self.data_textarea_result.configure(state="disabled")
            self.btn_attack_classification_testing.configure(state="disabled")
        else:
            messagebox.showinfo("showinfo", "Please done Attack Classification training first...")

    def testing_data(self):
        if os.path.exists("..\\Models\\"):
            self.boolTesingDataRead = True
            self.data_textarea_process.configure(state="normal")
            self.txt_testing_data.configure(state="normal")
            self.txt_testing_data.delete(0, len(self.txt_testing_data.get()))

            self.testing_data = askopenfile(mode='r', filetypes=[('All Files', '*')])

            with open(self.testing_data.name, newline="", encoding="utf-8") as file:
                reader = csv.reader(file)
                self.header = next(reader)  # first row (heading)
                self.ipdata = list(reader)  # remaining rows (data)

            self.data_textarea_process.configure(state="normal")
            self.data_textarea_process.delete("1.0", "end")
            self.data_textarea_process.configure(state="disabled")
            self.data_textarea_result.configure(state="normal")
            self.data_textarea_result.delete("1.0", "end")
            self.data_textarea_result.configure(state="disabled")

            print("\nTesting Data")
            print("==============")
            self.data_textarea_process.insert(INSERT, "\n\nTesting Data")
            self.data_textarea_process.insert(INSERT, "\n==============")

            a = str(self.testing_data.name).split("/")

            self.txt_testing_data.insert(INSERT, "" + str(a[len(a) - 1]))

            print("\nTotal number of Testing Data: " + str(len(self.ipdata)))
            self.data_textarea_process.insert(INSERT, "\n\nTotal number of Testing Data: " + str(len(self.ipdata)))

            print("\nTesting data was selected successfully...")
            self.data_textarea_process.insert(INSERT, "\n\nTesting data was selected successfully...")
            messagebox.showinfo("Info Message", "Testing data was selected successfully...")

            self.txt_testing_data.configure(state="disabled")
            self.data_textarea_process.configure(state="disabled")
            self.btn_testing_data.configure(state="disabled")

            self.btn_noise_removal.configure(state="normal")
            self.btn_feature_extraction.configure(state="normal")
            self.btn_attack_detection.configure(state="normal")
        else:
            messagebox.showinfo("showinfo", "Please done Attack Classification training first...")

    def noise_removal(self):
        if self.boolTesingDataRead:
            self.boolDatasetNoiseRemoval = True
            self.data_textarea_process.configure(state="normal")
            print("\nPre-processing: Noise Removal using Geodesic Filtering (GF)")
            print("=============================================================")
            self.data_textarea_process.insert(INSERT, "\n\nPre-processing: Noise Removal using Geodesic Filtering (GF)")
            self.data_textarea_process.insert(INSERT, "\n==============================================")

            Noise_Removal.NR_GF(self, self.testing_data.name, "..\\Output\\Testing\\Noise Removed Data.csv")

            print("\nNoise Removal was done Successfully...")
            self.data_textarea_process.insert(INSERT, "\n\nNoise Removal was done Successfully...")
            messagebox.showinfo("showinfo", "Noise Removal was done Successfully...")

            self.btn_noise_removal.configure(state="disabled")
            self.data_textarea_process.configure(state="disabled")
        else:
            messagebox.showinfo("showinfo", "Please select Testing Data first...")

    def feature_extraction(self):
        if self.boolDatasetNoiseRemoval:
            self.boolDatasetFeatureExtraction = True
            self.data_textarea_process.configure(state="normal")
            print("\nFeature Extraction using Adaptive Kernel Force-Invariant Improved (AKFII)")
            print("===========================================================================")
            self.data_textarea_process.insert(INSERT,
                                              "\n\nFeature Extraction using Adaptive Kernel Force-Invariant Improved (AKFII)")
            self.data_textarea_process.insert(INSERT, "\n=====================================================")

            Feature_Extraction.FE_AKFII(self, "..\\Output\\Testing\\Noise Removed Data.csv",
                                        "..\\Output\\Testing\\Feature Extracted Data.csv")

            print("\nFeature Extraction was done Successfully...")
            self.data_textarea_process.insert(INSERT, "\n\nFeature Extraction was done Successfully...")
            messagebox.showinfo("showinfo", "Feature Extraction was done Successfully...")

            self.btn_feature_extraction.configure(state="disabled")
            self.data_textarea_process.configure(state="disabled")
        else:
            messagebox.showinfo("showinfo", "Please done the Noise Removal first...")

    def attack_detection(self):
        if self.boolDatasetFeatureExtraction:
            self.data_textarea_process.configure(state="normal")
            print(
                "\nAttack Detection using Proposed Enhanced Evolutionary Gravitational Neocognitron Neural Network (EEGNNN)")
            print(
                "==========================================================================================================")
            self.data_textarea_process.insert(INSERT,
                                              "\n\nAttack Detection using Proposed Enhanced Evolutionary Gravitational Neocognitron Neural Network (EEGNNN)")
            self.data_textarea_process.insert(INSERT, "\n=====================================================")

            hdata_val = []
            hcol_val = []

            htesting_data = []

            with open("..\\Models\\meta_data.csv", newline="", encoding="utf-8") as file:
                reader = csv.reader(file)
                self.header = next(reader)  # first row (heading)

                for row in reader:
                    hdata_val.append(row[:-3][0])
                    hcol_val.append(row[-3:])

            with open(self.testing_data.name, newline="", encoding="utf-8") as file:
                reader = csv.reader(file)
                self.header = next(reader)  # first row (heading)
                for row in reader:
                    strval = "".join(row)
                    strhval = digest_meta(strval)
                    if hdata_val.__contains__(strhval):
                        print(str(hcol_val[hdata_val.index(strhval)]) + " : " + str(row))

            print("\nAttack Detection was done Successfully...")
            self.data_textarea_process.insert(INSERT, "\n\nAttack Detection was done Successfully...")
            messagebox.showinfo("showinfo", "Attack Detection was done Successfully...")

            self.btn_attack_detection.configure(state="disabled")
            self.data_textarea_process.configure(state="disabled")
            self.btn_testing_data.configure(state="normal")
            self.txt_testing_data.configure(state="normal")
            self.txt_testing_data.delete(0, len(self.txt_testing_data.get()))
            self.txt_testing_data.configure(state="disabled")
        else:
            messagebox.showinfo("showinfo", "Please done the Feature Extraction first...")

    def clear(self):
        self.btn_bot_iot_dataset.configure(state="normal")
        self.btn_dataset_preprocessing_noise_removal.configure(state="normal")
        self.btn_dataset_feature_extraction.configure(state="normal")
        self.btn_dataset_splitting.configure(state="normal")
        self.btn_attack_classification_training.configure(state="normal")
        self.btn_attack_classification_testing.configure(state="normal")
        self.btn_testing_data.configure(state="normal")
        self.btn_noise_removal.configure(state="normal")
        self.btn_feature_extraction.configure(state="normal")
        self.btn_attack_detection.configure(state="normal")

        self.data_textarea_process.configure(state="normal")
        self.data_textarea_process.delete("1.0", "end")
        self.data_textarea_process.configure(state="disabled")
        self.data_textarea_result.configure(state="normal")
        self.data_textarea_result.delete("1.0", "end")
        self.data_textarea_result.configure(state="disabled")

    def tables_graphs(self):
        if self.boolTesting:
            messagebox.showinfo("Info Message", "Generate Tables and Graphs was done successfully...")
        else:
            messagebox.showinfo("Info Message", "Please done the Sarcasm Detection Testing first ...")

    def exit(self):
        self.root.destroy()


def digest_meta(value):
    return hashlib.sha512(value.encode("utf-8")).hexdigest()


def getListOfFiles(dirName):
    # create a list of file and sub directories
    # names in the given directory
    listOfFile = os.listdir(dirName)
    allFiles = list()
    # Iterate over all the entries
    for entry in listOfFile:
        # Create full path
        fullPath = os.path.join(dirName, entry)
        # If entry is a directory then get the list of files in this directory
        if os.path.isdir(fullPath):
            allFiles = allFiles + getListOfFiles(fullPath)
        else:
            # if fullPath.endswith(".JPEG"):
            allFiles.append(fullPath)

    return allFiles


root = Tk()
root.title(
    "Cardiovascular Disease Prediction Using Henon Map-driven Feature Optimization and Adaptive Deep Learning")
root.geometry("1000x650")
root.resizable(0, 0)
root.configure(bg="azure3")
od = Main_GUI(root)
root.mainloop()