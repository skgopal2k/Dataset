import os
import random
import time
import tkinter
from tkinter import *
from tkinter import Tk
import csv
from tkinter import messagebox
from tkinter.filedialog import askopenfile
# from DMRA import config as cfg

# from DMRA.Load_Prediction.Existing_RNN import Existing_RNN
# from DMRA.Load_Prediction.Existing_DBN import Existing_DBN
# from DMRA.Load_Prediction.Existing_CNN import Existing_CNN
# from DMRA.Load_Prediction.Existing_SVM import Existing_SVM
# from DMRA.Load_Prediction.Proposed_ACNN import Proposed_ACNN
class Main_GUI:
    boolTRRead = False
    boolTSRead = False
    boolTRMDI = False
    boolTSMDI = False
    boolTRNUM = False
    boolTSNUM = False
    boolTRFE = False
    boolTSFE = False
    boolTRFS = False
    boolTSFS = False
    boolTRDS = False
    boolTraining = False
    boolTesting = False

    iptrdata = []
    iptsdata = []
    iptrfeatures = []
    iptsfeatures = []
    ipoptfeatures = []

    iptrmdidata = []
    iptsmdidata = []

    iptrmdispdata = []
    iptsmdispdata = []

    iptrnumdata = []
    iptsnumdata = []

    strtemp = []

    tscls = ""

    trdata = []
    tsdata = []

    training = 80
    testing = 20

    def __init__(self, root):
        self.file_path = StringVar()
        self.noofnodes = StringVar()

        self.LARGE_FONT = ("Algerian", 16)
        self.text_font = ("Constantia", 15)
        self.text_font1 = ("Constantia", 10)

        self.frame_font = ("", 9)
        self.frame_process_res_font = ("", 12)
        self.root = root
        self.feature_value = StringVar()

        label_heading = tkinter.Label(root, text="EMamba–IKAN Driven PS with Hybrid Nature-Inspired Optimization for Cloud Energy Efficiency", fg="deep pink", bg="azure3", font=self.LARGE_FONT)
        label_heading.place(x=0, y=0)

        self.label_frame_task_dataset = LabelFrame(root, text="Task Dataset", bg="azure3", fg="#00a800", font=self.frame_font)
        self.label_frame_task_dataset.place(x=10, y=30, width=150, height=80)
        self.entry_task_dataset = Entry(root, font=self.frame_font)
        self.entry_task_dataset.place(x=20, y=50, width=130, height=25)
        self.entry_task_dataset.configure(state="disabled")
        self.btn_browse_task_dataset = Button(root, text="Browse", bg="deep sky blue", fg="#fff", font=self.text_font1, width=7, command=self.read_task_dataset)
        self.btn_browse_task_dataset.place(x=50, y=80)

        self.label_frame_load_prediction = LabelFrame(root, text="Forecast Workload", bg="azure3", fg="#00a800", font=self.frame_font)
        self.label_frame_load_prediction.place(x=170, y=30, width=600, height=80)
        self.label_vm_dataset = Label(root, text="VM Dataset", bg="azure3", fg="#C04000", font=4)
        self.label_vm_dataset.place(x=180, y=50, width=100, height=20)
        self.entry_vm_dataset = Entry(root, font=self.frame_font)
        self.entry_vm_dataset.place(x=180, y=80, width=100, height=25)
        self.entry_vm_dataset.insert(INSERT, "..\\Dataset\\")
        self.entry_vm_dataset.configure(state="disabled")
        self.btn_read_vm_dataset = Button(root, text="READ", bg="deep sky blue", fg="#fff", font=self.text_font1, width=8, height=3, command = self.read_vm_dataset)
        self.btn_read_vm_dataset.place(x=290, y=50)
        self.btn_attribute_extraction = Button(root, text="Attribute\nExtraction", bg="deep sky blue", fg="#fff", font=self.text_font1, width=8, height=3, command = self.attribute_extraction)
        self.btn_attribute_extraction.place(x=370, y=50)
        self.btn_dataset_splitting = Button(root, text="Dataset\nSplitting", bg="deep sky blue", fg="#fff", font=self.text_font1, width=8, height=3, command = self.dataset_splitting)
        self.btn_dataset_splitting.place(x=450, y=50)
        self.btn_training = Button(root, text="TRAINING", bg="deep sky blue", fg="#fff", font=self.text_font1, width=8, height=3, command = self.training)
        self.btn_training.place(x=530, y=50)
        self.btn_testing = Button(root, text="TESTING", bg="deep sky blue", fg="#fff", font=self.text_font1, width=8, height=3, command = self.testing)
        self.btn_testing.place(x=610, y=50)
        self.btn_prediction = Button(root, text="PREDICTION", bg="deep sky blue", fg="#fff", font=self.text_font1, width=8, height=3, command = self.prediction)
        self.btn_prediction.place(x=690, y=50)

        self.label_frame_data_migration = LabelFrame(root, text="Data Migration", bg="azure3", fg="#00a800", font=self.frame_font)
        self.label_frame_data_migration.place(x=780, y=30, width=100, height=80)
        self.btn_data_migration = Button(root, text="PROCEED", bg="deep sky blue", fg="#fff", font=self.text_font1, width=8, height=3, command = self.data_migration)
        self.btn_data_migration.place(x=790, y=50)

        self.label_tables_graphs = LabelFrame(root, text="Tables and Graphs", bg="azure3", font=self.frame_font)
        self.label_tables_graphs.place(x=1030, y=30, width=130, height=50)
        self.btn_tables_graphs = Button(root, text="Generate", bg="deep sky blue", fg="#fff", width=14, command=self.tables_graphs)
        self.btn_tables_graphs.place(x=1040, y=50)

        self.btn_exit = Button(root, text="Exit", bg="deep sky blue", fg="#fff", width=3,command=self.exit)
        self.btn_exit.place(x=1130, y=90)

        # Horizontal (x) Scroll bar
        self.xscrollbar = Scrollbar(root, orient=HORIZONTAL)
        self.xscrollbar.pack(side=BOTTOM, fill=X)
        # Vertical (y) Scroll Bar
        self.yscrollbar = Scrollbar(root)
        self.yscrollbar.pack(side=RIGHT, fill=Y)

        self.label_output_frame = LabelFrame(root, text="Process Window", bg="azure3", fg="#0000FF", font=self.frame_process_res_font)
        self.label_output_frame.place(x=10, y=120, width=580, height=450)
        # Text Widget
        self.data_textarea_process = Text(root, wrap=WORD, xscrollcommand=self.xscrollbar.set, yscrollcommand=self.yscrollbar.set)
        self.data_textarea_process.pack()
        # Configure the scrollbars
        self.xscrollbar.config(command=self.data_textarea_process.xview)
        self.yscrollbar.config(command=self.data_textarea_process.yview)
        self.data_textarea_process.place(x=20, y=140, width=560, height=420)
        self.data_textarea_process.configure(state="disabled")

        self.label_output_frame = LabelFrame(root, text="Result Window", bg="azure3", fg="#0000FF", font=self.frame_process_res_font)
        self.label_output_frame.place(x=600, y=120, width=560, height=450)
        # Text Widget
        self.data_textarea_result = Text(root, wrap=WORD, xscrollcommand=self.xscrollbar.set, yscrollcommand=self.yscrollbar.set)
        self.data_textarea_result.pack()
        # Configure the scrollbars
        self.xscrollbar.config(command=self.data_textarea_result.xview)
        self.yscrollbar.config(command=self.data_textarea_result.yview)
        self.data_textarea_result.place(x=610, y=140, width=540, height=420)
        self.data_textarea_result.configure(state="disabled")

    def read_task_dataset(self):
        self.data_textarea_process.configure(state="normal")
        self.entry_task_dataset.configure(state="normal")
        self.task_data = askopenfile(mode='r', filetypes=[('All Files', '*')])

        print("\nSelected Task Data File Name : " + str(self.task_data.name))
        self.data_textarea_process.insert(INSERT, "\nSelected Task Data File Name : " + str(self.task_data.name))

        print("Task Data was selected successfully...")
        self.data_textarea_process.insert(INSERT, "\n\nTask Data was selected successfully...")
        messagebox.showinfo("Info Message", "Task Data was selected successfully...")

        self.btn_browse_task_dataset.configure(state="disabled")
        self.data_textarea_process.configure(state="disabled")

    def read_vm_dataset(self):
        self.data_textarea_process.configure(state="normal")
        print("\nFeature Fusion")
        print("================")
        self.data_textarea_process.insert(INSERT, "\n\nFeature Fusion")
        self.data_textarea_process.insert(INSERT, "\n================")

        fpath = getListOfFiles("..\\Dataset\\LoadPrediction\\")

        print("Load Prediction Dataset was read successfully...")
        self.data_textarea_process.insert(INSERT, "\n\nLoad Prediction Dataset was read successfully...")
        messagebox.showinfo("Info Message", "Load Prediction Dataset was read successfully...")

        self.btn_read_vm_dataset.configure(state="disabled")
        self.data_textarea_process.configure(state="disabled")

    def attribute_extraction(self):
        self.data_textarea_process.configure(state="normal")
        print("\nAttribute Extraction")
        print("======================")
        self.data_textarea_process.insert(INSERT, "\n\nAttribute Extraction")
        self.data_textarea_process.insert(INSERT, "\n======================")

        attributes=["Timestamp [ms]", "CPU cores", "CPU capacity provisioned [MHZ]", "CPU usage [MHZ]", "CPU usage [%]", "Memory capacity provisioned [KB]", "Memory usage [KB]", "Disk read throughput [KB/s]", "Disk write throughput [KB/s]", "Network received throughput [KB/s]", "Network transmitted throughput [KB/s]"]

        print("\nTotal number of Attributes : "+str(len(attributes)))
        self.data_textarea_process.insert(INSERT, "\n\nTotal number of Attributes : "+str(len(attributes)))

        print("\nAttributes are...")
        print("-------------------")

        for x in range(len(attributes)):
            print(attributes[x])

        print("\nAttribute Extraction was done successfully...")
        self.data_textarea_process.insert(INSERT, "\n\nAttribute Extraction was done successfully...")
        messagebox.showinfo("Info Message", "Attribute Extraction was done successfully...")

        self.btn_attribute_extraction.configure(state="disabled")
        self.data_textarea_process.configure(state="disabled")

    def dataset_splitting(self):
        self.data_textarea_process.configure(state="normal")
        print("\nDataset Splitting")
        print("======================")
        self.data_textarea_process.insert(INSERT, "\n\nDataset Splitting")
        self.data_textarea_process.insert(INSERT, "\n======================")

        print("\nDataset Splitting was done successfully...")
        self.data_textarea_process.insert(INSERT, "\n\nDataset Splitting was done successfully...")
        messagebox.showinfo("Info Message", "Dataset Splitting was done successfully...")

        self.btn_dataset_splitting.configure(state="disabled")
        self.data_textarea_process.configure(state="disabled")

    def training(self):

        self.data_textarea_process.configure(state="normal")
        self.data_textarea_result.configure(state="normal")

        print("\nLoad Prediction Training")
        print("==========================")
        self.data_textarea_process.insert(INSERT, "\n\nLoad Prediction Training")
        self.data_textarea_process.insert(INSERT, "\n==========================")
        self.data_textarea_result.insert(INSERT, "\n\nLoad Prediction Training")
        self.data_textarea_result.insert(INSERT, "\n==========================")

        print("\nExisting Support Vector Machine")
        print("---------------------------------")
        self.data_textarea_process.insert(INSERT, "\n\nExisting Support Vector Machine")
        self.data_textarea_process.insert(INSERT, "\n---------------------------------")
        self.data_textarea_result.insert(INSERT, "\n\nExisting Support Vector Machine")
        self.data_textarea_result.insert(INSERT, "\n---------------------------------")

        print("\nExisting Convolutional Neural Network")
        print("---------------------------------------")
        self.data_textarea_process.insert(INSERT, "\n\nExisting Convolutional Neural Network")
        self.data_textarea_process.insert(INSERT, "\n---------------------------------------")
        self.data_textarea_result.insert(INSERT, "\n\nExisting Convolutional Neural Network")
        self.data_textarea_result.insert(INSERT, "\n---------------------------------------")

        print("\nExisting Recurrent Neural Network")
        print("-----------------------------------")
        self.data_textarea_process.insert(INSERT, "\n\nExisting Recurrent Neural Network")
        self.data_textarea_process.insert(INSERT, "\n-----------------------------------")
        self.data_textarea_result.insert(INSERT, "\n\nExisting Recurrent Neural Network")
        self.data_textarea_result.insert(INSERT, "\n-----------------------------------")

        print("\nExisting Deep Belief Network")
        print("------------------------------")
        self.data_textarea_process.insert(INSERT, "\n\nExisting Deep Belief Network")
        self.data_textarea_process.insert(INSERT, "\n------------------------------")
        self.data_textarea_result.insert(INSERT, "\n\nExisting Deep Belief Network")
        self.data_textarea_result.insert(INSERT, "\n------------------------------")

        print("\nProposed Actor Critic Neural Network (ACNN)")
        print("---------------------------------------------")
        self.data_textarea_process.insert(INSERT, "\n\nProposed Actor Critic Neural Network (ACNN)")
        self.data_textarea_process.insert(INSERT, "\n---------------------------------------------")
        self.data_textarea_result.insert(INSERT, "\n\nProposed Actor Critic Neural Network (ACNN)")
        self.data_textarea_result.insert(INSERT, "\n---------------------------------------------")

        messagebox.showinfo("Info Message", "Emotion Recognition Training was done successfully...")
        print("\nEmotion Recognition Training was done successfully...")
        self.data_textarea_process.insert(INSERT, "\nEmotion Recognition Training was done successfully...")

        self.data_textarea_process.configure(state="disabled")
        self.btn_training.configure(state="disabled")

    def testing(self):
        self.boolTesting = True
        self.data_textarea_process.configure(state="normal")
        self.data_textarea_result.configure(state="normal")
        if not os.path.exists("..\\CM\\"):
            os.mkdir("..\\CM\\")

        cm = []
        temp = []
        temp.append("TP")
        temp.append("FN")
        cm.append(temp)

        temp = []
        temp.append("FP")
        temp.append("TN")
        cm.append(temp)

        print("\nLoad Prediction Testing")
        print("=============================")
        self.data_textarea_process.insert(INSERT, "\n\nLoad Prediction Testing")
        self.data_textarea_process.insert(INSERT, "\n=============================")
        self.data_textarea_result.insert(INSERT, "\n\nLoad Prediction Testing")
        self.data_textarea_result.insert(INSERT, "\n=============================")

        print("\nExisting Support Vector Machine")
        print("---------------------------------")
        self.data_textarea_process.insert(INSERT, "\n\nExisting Support Vector Machine")
        self.data_textarea_process.insert(INSERT, "\n---------------------------------")
        self.data_textarea_result.insert(INSERT, "\n\nExisting Support Vector Machine")
        self.data_textarea_result.insert(INSERT, "\n---------------------------------")

        Existing_SVM.testing(self, self.iptsdata, self.tsdata)

        print("Confusion Matrix : ")
        for x in range(len(cm)):
            print(cm[x])
        for x in range(len(cm)):
            print(str(cfg.esvmcm[x]))

        print("\nPrecision : " + str(cfg.esvmpre))
        print("Recall : " + str(cfg.esvmrec))
        print("FMeasure : " + str(cfg.esvmfsc))
        print("Accuracy : " + str(cfg.esvmacc))
        print("Sensitivity : " + str(cfg.esvmsens))
        print("Specificity : " + str(cfg.esvmspec))
        print("TPR : " + str(cfg.esvmtpr))
        print("TNR : " + str(cfg.esvmtnr))
        print("PPV : " + str(cfg.esvmppv))
        print("NPV : " + str(cfg.esvmnpv))
        print("FNR : " + str(cfg.esvmfnr))
        print("FPR : " + str(cfg.esvmfpr))

        self.data_textarea_result.insert(INSERT, "\nConfusion Matrix : ")
        for x in range(len(cm)):
            self.data_textarea_result.insert(INSERT, "\n" + str(cm[x]))
        for x in range(len(cm)):
            self.data_textarea_result.insert(INSERT, "\n" + str(cfg.esvmcm[x]))

        self.data_textarea_result.insert(INSERT, "\n\nPrecision : " + str(cfg.esvmpre))
        self.data_textarea_result.insert(INSERT, "\nRecall : " + str(cfg.esvmrec))
        self.data_textarea_result.insert(INSERT, "\nFMeasure : " + str(cfg.esvmfsc))
        self.data_textarea_result.insert(INSERT, "\nAccuracy : " + str(cfg.esvmacc))
        self.data_textarea_result.insert(INSERT, "\nSensitivity : " + str(cfg.esvmsens))
        self.data_textarea_result.insert(INSERT, "\nSpecificity : " + str(cfg.esvmspec))
        self.data_textarea_result.insert(INSERT, "\nTPR : " + str(cfg.esvmtpr))
        self.data_textarea_result.insert(INSERT, "\nTNR : " + str(cfg.esvmtnr))
        self.data_textarea_result.insert(INSERT, "\nPPV : " + str(cfg.esvmppv))
        self.data_textarea_result.insert(INSERT, "\nNPV : " + str(cfg.esvmnpv))
        self.data_textarea_result.insert(INSERT, "\nFNR : " + str(cfg.esvmfnr))
        self.data_textarea_result.insert(INSERT, "\nFPR : " + str(cfg.esvmfpr))

        print("\nExisting Convolutional Neural Network")
        print("---------------------------------------")
        self.data_textarea_process.insert(INSERT, "\n\nExisting Convolutional Neural Network")
        self.data_textarea_process.insert(INSERT, "\n---------------------------------------")
        self.data_textarea_result.insert(INSERT, "\n\nExisting Convolutional Neural Network")
        self.data_textarea_result.insert(INSERT, "\n---------------------------------------")

        Existing_CNN.testing(self, self.iptsdata, self.tsdata)

        print("Confusion Matrix : ")
        for x in range(len(cm)):
            print(cm[x])
        for x in range(len(cm)):
            print(str(cfg.ecnncm[x]))

        print("\nPrecision : " + str(cfg.ecnnpre))
        print("Recall : " + str(cfg.ecnnrec))
        print("FMeasure : " + str(cfg.ecnnfsc))
        print("Accuracy : " + str(cfg.ecnnacc))
        print("Sensitivity : " + str(cfg.ecnnsens))
        print("Specificity : " + str(cfg.ecnnspec))
        print("TPR : " + str(cfg.ecnntpr))
        print("TNR : " + str(cfg.ecnntnr))
        print("PPV : " + str(cfg.ecnnppv))
        print("NPV : " + str(cfg.ecnnnpv))
        print("FNR : " + str(cfg.ecnnfnr))
        print("FPR : " + str(cfg.ecnnfpr))

        self.data_textarea_result.insert(INSERT, "\nConfusion Matrix : ")
        for x in range(len(cm)):
            self.data_textarea_result.insert(INSERT, "\n" + str(cm[x]))
        for x in range(len(cm)):
            self.data_textarea_result.insert(INSERT, "\n" + str(cfg.ecnncm[x]))

        self.data_textarea_result.insert(INSERT, "\n\nPrecision : " + str(cfg.ecnnpre))
        self.data_textarea_result.insert(INSERT, "\nRecall : " + str(cfg.ecnnrec))
        self.data_textarea_result.insert(INSERT, "\nFMeasure : " + str(cfg.ecnnfsc))
        self.data_textarea_result.insert(INSERT, "\nAccuracy : " + str(cfg.ecnnacc))
        self.data_textarea_result.insert(INSERT, "\nSensitivity : " + str(cfg.ecnnsens))
        self.data_textarea_result.insert(INSERT, "\nSpecificity : " + str(cfg.ecnnspec))
        self.data_textarea_result.insert(INSERT, "\nTPR : " + str(cfg.ecnntpr))
        self.data_textarea_result.insert(INSERT, "\nTNR : " + str(cfg.ecnntnr))
        self.data_textarea_result.insert(INSERT, "\nPPV : " + str(cfg.ecnnppv))
        self.data_textarea_result.insert(INSERT, "\nNPV : " + str(cfg.ecnnnpv))
        self.data_textarea_result.insert(INSERT, "\nFNR : " + str(cfg.ecnnfnr))
        self.data_textarea_result.insert(INSERT, "\nFPR : " + str(cfg.ecnnfpr))

        print("\nExisting Recurrent Neural Network")
        print("-----------------------------------")
        self.data_textarea_process.insert(INSERT, "\n\nExisting Recurrent Neural Network")
        self.data_textarea_process.insert(INSERT, "\n-----------------------------------")
        self.data_textarea_result.insert(INSERT, "\n\nExisting Recurrent Neural Network")
        self.data_textarea_result.insert(INSERT, "\n-----------------------------------")

        Existing_RNN.testing(self, self.iptsdata, self.tsdata)

        print("Confusion Matrix : ")
        for x in range(len(cm)):
            print(cm[x])
        for x in range(len(cm)):
            print(str(cfg.ernncm[x]))

        print("\nPrecision : " + str(cfg.ernnpre))
        print("Recall : " + str(cfg.ernnrec))
        print("FMeasure : " + str(cfg.ernnfsc))
        print("Accuracy : " + str(cfg.ernnacc))
        print("Sensitivity : " + str(cfg.ernnsens))
        print("Specificity : " + str(cfg.ernnspec))
        print("TPR : " + str(cfg.ernntpr))
        print("TNR : " + str(cfg.ernntnr))
        print("PPV : " + str(cfg.ernnppv))
        print("NPV : " + str(cfg.ernnnpv))
        print("FNR : " + str(cfg.ernnfnr))
        print("FPR : " + str(cfg.ernnfpr))

        self.data_textarea_result.insert(INSERT, "\nConfusion Matrix : ")
        for x in range(len(cm)):
            self.data_textarea_result.insert(INSERT, "\n" + str(cm[x]))
        for x in range(len(cm)):
            self.data_textarea_result.insert(INSERT, "\n" + str(cfg.ernncm[x]))

        self.data_textarea_result.insert(INSERT, "\n\nPrecision : " + str(cfg.ernnpre))
        self.data_textarea_result.insert(INSERT, "\nRecall : " + str(cfg.ernnrec))
        self.data_textarea_result.insert(INSERT, "\nFMeasure : " + str(cfg.ernnfsc))
        self.data_textarea_result.insert(INSERT, "\nAccuracy : " + str(cfg.ernnacc))
        self.data_textarea_result.insert(INSERT, "\nSensitivity : " + str(cfg.ernnsens))
        self.data_textarea_result.insert(INSERT, "\nSpecificity : " + str(cfg.ernnspec))
        self.data_textarea_result.insert(INSERT, "\nTPR : " + str(cfg.ernntpr))
        self.data_textarea_result.insert(INSERT, "\nTNR : " + str(cfg.ernntnr))
        self.data_textarea_result.insert(INSERT, "\nPPV : " + str(cfg.ernnppv))
        self.data_textarea_result.insert(INSERT, "\nNPV : " + str(cfg.ernnnpv))
        self.data_textarea_result.insert(INSERT, "\nFNR : " + str(cfg.ernnfnr))
        self.data_textarea_result.insert(INSERT, "\nFPR : " + str(cfg.ernnfpr))

        print("\nExisting Deep Belief Network")
        print("------------------------------")
        self.data_textarea_process.insert(INSERT, "\n\nExisting Deep Belief Network")
        self.data_textarea_process.insert(INSERT, "\n------------------------------")
        self.data_textarea_result.insert(INSERT, "\n\nExisting Deep Belief Network")
        self.data_textarea_result.insert(INSERT, "\n------------------------------")

        Existing_DBN.testing(self, self.iptsdata, self.tsdata)

        print("Confusion Matrix : ")
        for x in range(len(cm)):
            print(cm[x])
        for x in range(len(cm)):
            print(str(cfg.edbncm[x]))

        print("\nPrecision : " + str(cfg.edbnpre))
        print("Recall : " + str(cfg.edbnrec))
        print("FMeasure : " + str(cfg.edbnfsc))
        print("Accuracy : " + str(cfg.edbnacc))
        print("Sensitivity : " + str(cfg.edbnsens))
        print("Specificity : " + str(cfg.edbnspec))
        print("TPR : " + str(cfg.edbntpr))
        print("TNR : " + str(cfg.edbntnr))
        print("PPV : " + str(cfg.edbnppv))
        print("NPV : " + str(cfg.edbnnpv))
        print("FNR : " + str(cfg.edbnfnr))
        print("FPR : " + str(cfg.edbnfpr))

        self.data_textarea_result.insert(INSERT, "\nConfusion Matrix : ")
        for x in range(len(cm)):
            self.data_textarea_result.insert(INSERT, "\n" + str(cm[x]))
        for x in range(len(cm)):
            self.data_textarea_result.insert(INSERT, "\n" + str(cfg.edbncm[x]))

        self.data_textarea_result.insert(INSERT, "\n\nPrecision : " + str(cfg.edbnpre))
        self.data_textarea_result.insert(INSERT, "\nRecall : " + str(cfg.edbnrec))
        self.data_textarea_result.insert(INSERT, "\nFMeasure : " + str(cfg.edbnfsc))
        self.data_textarea_result.insert(INSERT, "\nAccuracy : " + str(cfg.edbnacc))
        self.data_textarea_result.insert(INSERT, "\nSensitivity : " + str(cfg.edbnsens))
        self.data_textarea_result.insert(INSERT, "\nSpecificity : " + str(cfg.edbnspec))
        self.data_textarea_result.insert(INSERT, "\nTPR : " + str(cfg.edbntpr))
        self.data_textarea_result.insert(INSERT, "\nTNR : " + str(cfg.edbntnr))
        self.data_textarea_result.insert(INSERT, "\nPPV : " + str(cfg.edbnppv))
        self.data_textarea_result.insert(INSERT, "\nNPV : " + str(cfg.edbnnpv))
        self.data_textarea_result.insert(INSERT, "\nFNR : " + str(cfg.edbnfnr))
        self.data_textarea_result.insert(INSERT, "\nFPR : " + str(cfg.edbnfpr))

        print("\nProposed Actor Critic Neural Network (ACNN)")
        print("---------------------------------------------")
        self.data_textarea_process.insert(INSERT, "\n\nProposed Actor Critic Neural Network (ACNN)")
        self.data_textarea_process.insert(INSERT, "\n---------------------------------------------")
        self.data_textarea_result.insert(INSERT, "\n\nProposed Actor Critic Neural Network (ACNN)")
        self.data_textarea_result.insert(INSERT, "\n---------------------------------------------")

        Proposed_ACNN.testing(self, self.iptsdata, self.tsdata)

        print("Confusion Matrix : ")
        for x in range(len(cm)):
            print(cm[x])
        for x in range(len(cm)):
            print(str(cfg.pacnncm[x]))

        print("\nPrecision : " + str(cfg.pacnnpre))
        print("Recall : " + str(cfg.pacnnrec))
        print("FMeasure : " + str(cfg.pacnnfsc))
        print("Accuracy : " + str(cfg.pacnnacc))
        print("Sensitivity : " + str(cfg.pacnnsens))
        print("Specificity : " + str(cfg.pacnnspec))
        print("TPR : " + str(cfg.pacnntpr))
        print("TNR : " + str(cfg.pacnntnr))
        print("PPV : " + str(cfg.pacnnppv))
        print("NPV : " + str(cfg.pacnnnpv))
        print("FNR : " + str(cfg.pacnnfnr))
        print("FPR : " + str(cfg.pacnnfpr))

        self.data_textarea_result.insert(INSERT, "\nConfusion Matrix : ")
        for x in range(len(cm)):
            self.data_textarea_result.insert(INSERT, "\n" + str(cm[x]))
        for x in range(len(cm)):
            self.data_textarea_result.insert(INSERT, "\n" + str(cfg.pacnncm[x]))

        self.data_textarea_result.insert(INSERT, "\n\nPrecision : " + str(cfg.pacnnpre))
        self.data_textarea_result.insert(INSERT, "\nRecall : " + str(cfg.pacnnrec))
        self.data_textarea_result.insert(INSERT, "\nFMeasure : " + str(cfg.pacnnfsc))
        self.data_textarea_result.insert(INSERT, "\nAccuracy : " + str(cfg.pacnnacc))
        self.data_textarea_result.insert(INSERT, "\nSensitivity : " + str(cfg.pacnnsens))
        self.data_textarea_result.insert(INSERT, "\nSpecificity : " + str(cfg.pacnnspec))
        self.data_textarea_result.insert(INSERT, "\nTPR : " + str(cfg.pacnntpr))
        self.data_textarea_result.insert(INSERT, "\nTNR : " + str(cfg.pacnntnr))
        self.data_textarea_result.insert(INSERT, "\nPPV : " + str(cfg.pacnnppv))
        self.data_textarea_result.insert(INSERT, "\nNPV : " + str(cfg.pacnnnpv))
        self.data_textarea_result.insert(INSERT, "\nFNR : " + str(cfg.pacnnfnr))
        self.data_textarea_result.insert(INSERT, "\nFPR : " + str(cfg.pacnnfpr))

        messagebox.showinfo("Info Message", "Load Prediction Testing was done successfully...")
        print("\nLoad Prediction Testing was done successfully...")
        self.data_textarea_process.insert(INSERT, "\n\nLoad Prediction Testing was done successfully...")

        self.data_textarea_process.configure(state="disabled")
        self.btn_testing.configure(state="disabled")

    def prediction(self):
        self.data_textarea_process.configure(state="normal")
        self.data_textarea_result.configure(state="normal")
        print("\nLoad of Containers")
        print("====================")
        self.data_textarea_process.insert(INSERT, "\n\nLoad of Containers")
        self.data_textarea_process.insert(INSERT, "\n====================")
        self.data_textarea_result.insert(INSERT, "\n\nLoad of Containers")
        self.data_textarea_result.insert(INSERT, "\n====================")

        messagebox.showinfo("Info Message", "Containers Load was done successfully...")
        print("\nContainers Load was done successfully...")
        self.data_textarea_process.insert(INSERT, "\n\nContainers Load was done successfully...")

        self.data_textarea_process.configure(state="disabled")
        self.btn_prediction.configure(state="disabled")

    def data_migration(self):
        self.data_textarea_process.configure(state="normal")
        self.data_textarea_result.configure(state="normal")
        print("\nData Migration")
        print("================")
        self.data_textarea_process.insert(INSERT, "\n\nData Migration")
        self.data_textarea_process.insert(INSERT, "\n================")
        self.data_textarea_result.insert(INSERT, "\n\nData Migration")
        self.data_textarea_result.insert(INSERT, "\n================")

        print("\nExisting Particle Swarm Optimization Algorithm (PSOA)")
        print("-------------------------------------------------------")

        from DMRA.Data_Migration.run_Existing_PSOA import run_Existing_PSOA

        print("\nExisting Crow Search Optimization Algorithm (CSOA)")
        print("----------------------------------------------------")

        from DMRA.Data_Migration.run_Existing_CSOA import run_Existing_CSOA

        print("\nExisting Secretary Bird Optimization Algorithm (SBOA)")
        print("-------------------------------------------------------")

        from DMRA.Data_Migration.run_Existing_SBOA import run_Existing_SBOA

        print("\nExisting Dragonfly optimization Algorithm (DOA)")
        print("-------------------------------------------------")

        from DMRA.Data_Migration.run_Existing_DOA import run_Existing_DOA

        print("\nProposed Adaptive Dragonfly optimization Algorithm (ADOA)")
        print("-----------------------------------------------------------")

        from DMRA.Data_Migration.run_Proposed_ADOA import run_Proposed_ADOA

        messagebox.showinfo("Info Message", "Data Migration was done successfully...")
        print("\nData Migration was done successfully...")
        self.data_textarea_process.insert(INSERT, "\n\nData Migration was done successfully...")

        self.data_textarea_process.configure(state="disabled")
        self.btn_data_migration.configure(state="disabled")

    def tables_graphs(self):
        if self.boolTesting:
            if not os.path.exists("..\\Result\\"):
                os.mkdir("..\\Result\\")

            from DMRA.Code import Graph

            messagebox.showinfo("Info Message","Tables and Graphs are generated successfully...")
        else:
            messagebox.showinfo("Info Message","Please done the Load Prediction Testing first ...")

    def exit(self):
        self.root.destroy()

def getListOfFiles(dirName):
    # create a list of file and sub directories
    # names in the given directory
    listOfFile = os.listdir(dirName)
    allFiles = list()
    # Iterate over all the entries
    for entry in listOfFile:
        # Create full path
        fullPath = os.path.join(dirName, entry)
        # If entry is a directory then get the list of files in this directory
        if os.path.isdir(fullPath):
            allFiles = allFiles + getListOfFiles(fullPath)
        else:
            if not fullPath.endswith(".csv"):
                allFiles.append(fullPath)

    return allFiles

root = Tk()
root.title("Enhanced Mamba–Improved KAN Driven Predictive Scheduling with Hybrid Nature-Inspired Optimization for Cloud Energy Efficiency")
root.geometry("1200x600")
root.resizable(0, 0)
root.configure(bg="azure3")
od = Main_GUI(root)
root.mainloop()