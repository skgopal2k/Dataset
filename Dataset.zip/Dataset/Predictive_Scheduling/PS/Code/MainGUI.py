import os
import random
import time
import tkinter
from tkinter import *
from tkinter import Tk
import csv
from tkinter import messagebox
from tkinter.filedialog import askopenfile
from PS import config as cfg

from PS.Workload_Forecast.Existing_LSTM import Existing_LSTM
from PS.Workload_Forecast.Existing_GRU import Existing_GRU
from PS.Workload_Forecast.Existing_Transformer import Existing_Transformer
from PS.Workload_Forecast.Proposed import Proposed

from PS.Code.PGraph import PGraph

class Main_GUI:
    boolTRRead = False
    boolTSRead = False
    boolTRMDI = False
    boolTSMDI = False
    boolTRNUM = False
    boolTSNUM = False
    boolTRFE = False
    boolTSFE = False
    boolTRFS = False
    boolTSFS = False
    boolTRDS = False
    boolTraining = False
    boolTesting = False

    iptrdata = []
    iptsdata = []
    iptrfeatures = []
    iptsfeatures = []
    ipoptfeatures = []

    iptrmdidata = []
    iptsmdidata = []

    iptrmdispdata = []
    iptsmdispdata = []

    iptrnumdata = []
    iptsnumdata = []

    strtemp = []

    tscls = ""

    trdata = []
    tsdata = []

    training = 80
    testing = 20

    def __init__(self, root):
        self.file_path = StringVar()
        self.noofnodes = StringVar()

        self.LARGE_FONT = ("Algerian", 16)
        self.text_font = ("Constantia", 15)
        self.text_font1 = ("Constantia", 10)

        self.frame_font = ("", 9)
        self.frame_process_res_font = ("", 12)
        self.root = root
        self.feature_value = StringVar()

        label_heading = tkinter.Label(root, text="EMamba–IKAN Driven PS with Hybrid Nature-Inspired Optimization for Cloud Energy Efficiency", fg="deep pink", bg="azure3", font=self.LARGE_FONT)
        label_heading.place(x=100, y=0)

        self.label_frame_task_dataset = LabelFrame(root, text="Task Dataset", bg="azure3", fg="#00a800", font=self.frame_font)
        self.label_frame_task_dataset.place(x=10, y=30, width=150, height=80)
        self.entry_task_dataset = Entry(root, font=self.frame_font)
        self.entry_task_dataset.place(x=20, y=50, width=130, height=25)
        self.entry_task_dataset.configure(state="disabled")
        self.btn_browse_task_dataset = Button(root, text="Browse", bg="deep sky blue", fg="#fff", font=self.text_font1, width=7, command=self.read_task_dataset)
        self.btn_browse_task_dataset.place(x=50, y=80)

        self.label_frame_load_prediction = LabelFrame(root, text="Forecast Workload", bg="azure3", fg="#00a800", font=self.frame_font)
        self.label_frame_load_prediction.place(x=170, y=30, width=600, height=80)
        self.label_vm_dataset = Label(root, text="VM Dataset", bg="azure3", fg="#C04000", font=4)
        self.label_vm_dataset.place(x=180, y=50, width=100, height=20)
        self.entry_vm_dataset = Entry(root, font=self.frame_font)
        self.entry_vm_dataset.place(x=180, y=80, width=100, height=25)
        self.entry_vm_dataset.insert(INSERT, "..\\Dataset\\")
        self.entry_vm_dataset.configure(state="disabled")
        self.btn_read_vm_dataset = Button(root, text="READ", bg="deep sky blue", fg="#fff", font=self.text_font1, width=8, height=3, command = self.read_vm_dataset)
        self.btn_read_vm_dataset.place(x=290, y=50)
        self.btn_attribute_extraction = Button(root, text="Attribute\nExtraction", bg="deep sky blue", fg="#fff", font=self.text_font1, width=8, height=3, command = self.attribute_extraction)
        self.btn_attribute_extraction.place(x=370, y=50)
        self.btn_training = Button(root, text="TRAINING", bg="deep sky blue", fg="#fff", font=self.text_font1, width=8, height=3, command = self.training)
        self.btn_training.place(x=530, y=50)
        self.btn_prediction = Button(root, text="PREDICTION", bg="deep sky blue", fg="#fff", font=self.text_font1, width=8, height=3, command = self.prediction)
        self.btn_prediction.place(x=690, y=50)

        self.label_frame_task_scheduling = LabelFrame(root, text="Task Scheduling", bg="azure3", fg="#00a800", font=self.frame_font)
        self.label_frame_task_scheduling.place(x=780, y=30, width=100, height=80)
        self.btn_task_scheduling = Button(root, text="PROCEED", bg="deep sky blue", fg="#fff", font=self.text_font1, width=8, height=3, command = self.task_scheduling)
        self.btn_task_scheduling.place(x=790, y=50)

        self.label_tables_graphs = LabelFrame(root, text="Tables and Graphs", bg="azure3", font=self.frame_font)
        self.label_tables_graphs.place(x=1030, y=30, width=130, height=50)
        self.btn_tables_graphs = Button(root, text="Generate", bg="deep sky blue", fg="#fff", width=14, command=self.tables_graphs)
        self.btn_tables_graphs.place(x=1040, y=50)

        self.btn_exit = Button(root, text="Exit", bg="deep sky blue", fg="#fff", width=3,command=self.exit)
        self.btn_exit.place(x=1130, y=90)

        # Horizontal (x) Scroll bar
        self.xscrollbar = Scrollbar(root, orient=HORIZONTAL)
        self.xscrollbar.pack(side=BOTTOM, fill=X)
        # Vertical (y) Scroll Bar
        self.yscrollbar = Scrollbar(root)
        self.yscrollbar.pack(side=RIGHT, fill=Y)

        self.label_output_frame = LabelFrame(root, text="Process Window", bg="azure3", fg="#0000FF", font=self.frame_process_res_font)
        self.label_output_frame.place(x=10, y=120, width=580, height=450)
        # Text Widget
        self.data_textarea_process = Text(root, wrap=WORD, xscrollcommand=self.xscrollbar.set, yscrollcommand=self.yscrollbar.set)
        self.data_textarea_process.pack()
        # Configure the scrollbars
        self.xscrollbar.config(command=self.data_textarea_process.xview)
        self.yscrollbar.config(command=self.data_textarea_process.yview)
        self.data_textarea_process.place(x=20, y=140, width=560, height=420)
        self.data_textarea_process.configure(state="disabled")

        self.label_output_frame = LabelFrame(root, text="Result Window", bg="azure3", fg="#0000FF", font=self.frame_process_res_font)
        self.label_output_frame.place(x=600, y=120, width=560, height=450)
        # Text Widget
        self.data_textarea_result = Text(root, wrap=WORD, xscrollcommand=self.xscrollbar.set, yscrollcommand=self.yscrollbar.set)
        self.data_textarea_result.pack()
        # Configure the scrollbars
        self.xscrollbar.config(command=self.data_textarea_result.xview)
        self.yscrollbar.config(command=self.data_textarea_result.yview)
        self.data_textarea_result.place(x=610, y=140, width=540, height=420)
        self.data_textarea_result.configure(state="disabled")

    def read_task_dataset(self):
        self.data_textarea_process.configure(state="normal")
        self.entry_task_dataset.configure(state="normal")
        self.task_data = askopenfile(mode='r', filetypes=[('All Files', '*')])

        print("\nSelected Task Data File Name : " + str(self.task_data.name))
        self.data_textarea_process.insert(INSERT, "\nSelected Task Data File Name : " + str(self.task_data.name))

        print("Task Data was selected successfully...")
        self.data_textarea_process.insert(INSERT, "\n\nTask Data was selected successfully...")
        messagebox.showinfo("Info Message", "Task Data was selected successfully...")

        self.btn_browse_task_dataset.configure(state="disabled")
        self.data_textarea_process.configure(state="disabled")

    def read_vm_dataset(self):
        self.data_textarea_process.configure(state="normal")
        print("\nWorkload Forecast Dataset")
        print("===========================")
        self.data_textarea_process.insert(INSERT, "\n\nWorkload Forecast Dataset")
        self.data_textarea_process.insert(INSERT, "\n===========================")

        fpath = getListOfFiles("..\\Dataset\\Workload Dataset\\")

        print("Workload Forecast Dataset was read successfully...")
        self.data_textarea_process.insert(INSERT, "\n\nWorkload Forecast Dataset was read successfully...")
        messagebox.showinfo("Info Message", "Workload Forecast Dataset was read successfully...")

        self.btn_read_vm_dataset.configure(state="disabled")
        self.data_textarea_process.configure(state="disabled")

    def attribute_extraction(self):
        self.data_textarea_process.configure(state="normal")
        print("\nAttribute Extraction")
        print("======================")
        self.data_textarea_process.insert(INSERT, "\n\nAttribute Extraction")
        self.data_textarea_process.insert(INSERT, "\n======================")

        attributes=["Timestamp [ms]", "CPU cores", "CPU capacity provisioned [MHZ]", "CPU usage [MHZ]", "CPU usage [%]", "Memory capacity provisioned [KB]", "Memory usage [KB]", "Disk read throughput [KB/s]", "Disk write throughput [KB/s]", "Network received throughput [KB/s]", "Network transmitted throughput [KB/s]"]

        print("\nTotal number of Attributes : "+str(len(attributes)))
        self.data_textarea_process.insert(INSERT, "\n\nTotal number of Attributes : "+str(len(attributes)))

        print("\nAttributes are...")
        print("-------------------")

        for x in range(len(attributes)):
            print(attributes[x])

        print("\nAttribute Extraction was done successfully...")
        self.data_textarea_process.insert(INSERT, "\n\nAttribute Extraction was done successfully...")
        messagebox.showinfo("Info Message", "Attribute Extraction was done successfully...")

        self.btn_attribute_extraction.configure(state="disabled")
        self.data_textarea_process.configure(state="disabled")

    def training(self):

        self.data_textarea_process.configure(state="normal")
        self.data_textarea_result.configure(state="normal")

        print("\nWorkload Forecast Training")
        print("==========================")
        self.data_textarea_process.insert(INSERT, "\n\nWorkload Forecast Training")
        self.data_textarea_process.insert(INSERT, "\n==========================")
        self.data_textarea_result.insert(INSERT, "\n\nWorkload Forecast Training")
        self.data_textarea_result.insert(INSERT, "\n==========================")

        print("\nExisting Long Short-Term Memory (LSTM)")
        print("----------------------------------------")
        self.data_textarea_process.insert(INSERT, "\n\nExisting Long Short-Term Memory (LSTM)")
        self.data_textarea_process.insert(INSERT, "\n----------------------------------------")
        self.data_textarea_result.insert(INSERT, "\n\nExisting Long Short-Term Memory (LSTM)")
        self.data_textarea_result.insert(INSERT, "\n------------------------------------------")
        if not os.path.exists("..\\Models\\ELSTM.h5"):
            Existing_LSTM.training(self)
        print("Mean Absolute Error (MAE): " + str(cfg.elstm_mae))
        print("Root Mean Square Error (RMSE): " + str(cfg.elstm_rmse))
        print("Mean Absolute Percentage Error (MAPE): " + str(cfg.elstm_mape))
        print("R2 score: " + str(cfg.elstm_r2))

        self.data_textarea_result.insert(INSERT, "\nMean Absolute Error (MAE): " + str(cfg.elstm_mae))
        self.data_textarea_result.insert(INSERT, "\nRoot Mean Square Error (RMSE): " + str(cfg.elstm_rmse))
        self.data_textarea_result.insert(INSERT, "\nMean Absolute Percentage Error (MAPE): " + str(cfg.elstm_mape))
        self.data_textarea_result.insert(INSERT, "\nR2 score: " + str(cfg.elstm_r2))

        print("\nExisting Gated Recurrent Unit (GRU)")
        print("---------------------------------------")
        self.data_textarea_process.insert(INSERT, "\n\nExisting Gated Recurrent Unit (GRU)")
        self.data_textarea_process.insert(INSERT, "\n---------------------------------------")
        self.data_textarea_result.insert(INSERT, "\n\nExisting Gated Recurrent Unit (GRU)")
        self.data_textarea_result.insert(INSERT, "\n---------------------------------------")
        if not os.path.exists("..\\Models\\EGRU.h5"):
            Existing_GRU.training(self)

        print("Mean Absolute Error (MAE): "+str(cfg.egru_mae))
        print("Root Mean Square Error (RMSE): "+str(cfg.egru_rmse))
        print("Mean Absolute Percentage Error (MAPE): "+str(cfg.egru_mape))
        print("R2 score: "+str(cfg.egru_r2))

        self.data_textarea_result.insert(INSERT, "\nMean Absolute Error (MAE): "+str(cfg.egru_mae))
        self.data_textarea_result.insert(INSERT, "\nRoot Mean Square Error (RMSE): "+str(cfg.egru_rmse))
        self.data_textarea_result.insert(INSERT, "\nMean Absolute Percentage Error (MAPE): "+str(cfg.egru_mape))
        self.data_textarea_result.insert(INSERT, "\nR2 score: "+str(cfg.egru_r2))

        print("\nExisting Transformer")
        print("----------------------")
        self.data_textarea_process.insert(INSERT, "\n\nExisting Transformer")
        self.data_textarea_process.insert(INSERT, "\n----------------------")
        self.data_textarea_result.insert(INSERT, "\n\nExisting Transformer")
        self.data_textarea_result.insert(INSERT, "\n----------------------")
        if not os.path.exists("..\\Models\\ETransformer.h5"):
            Existing_Transformer.training(self)

        print("Mean Absolute Error (MAE): "+str(cfg.etransformer_mae))
        print("Root Mean Square Error (RMSE): "+str(cfg.etransformer_rmse))
        print("Mean Absolute Percentage Error (MAPE): "+str(cfg.etransformer_mape))
        print("R2 score: "+str(cfg.etransformer_r2))

        self.data_textarea_result.insert(INSERT, "\nMean Absolute Error (MAE): "+str(cfg.etransformer_mae))
        self.data_textarea_result.insert(INSERT, "\nRoot Mean Square Error (RMSE): "+str(cfg.etransformer_rmse))
        self.data_textarea_result.insert(INSERT, "\nMean Absolute Percentage Error (MAPE): "+str(cfg.etransformer_mape))
        self.data_textarea_result.insert(INSERT, "\nR2 score: "+str(cfg.etransformer_r2))

        print("\nProposed Enhanced Mamba–Improved Kolmogorov-Arnold networks (E-Mamba-IKAN)")
        print("----------------------------------------------------------------------------")
        self.data_textarea_process.insert(INSERT, "\n\nProposed Enhanced Mamba–Improved Kolmogorov-Arnold networks (E-Mamba-IKAN)")
        self.data_textarea_process.insert(INSERT, "\n---------------------------------------------")
        self.data_textarea_result.insert(INSERT, "\n\nProposed Enhanced Mamba–Improved Kolmogorov-Arnold networks (E-Mamba-IKAN)")
        self.data_textarea_result.insert(INSERT, "\n---------------------------------------------")
        if not os.path.exists("..\\Models\\Proposed.h5"):
            Proposed.training(self)
        print("Mean Absolute Error (MAE): " + str(cfg.proposed_mae))
        print("Root Mean Square Error (RMSE): " + str(cfg.proposed_rmse))
        print("Mean Absolute Percentage Error (MAPE): " + str(cfg.proposed_mape))
        print("R2 score: " + str(cfg.proposed_r2))

        self.data_textarea_result.insert(INSERT, "\nMean Absolute Error (MAE): " + str(cfg.proposed_mae))
        self.data_textarea_result.insert(INSERT, "\nRoot Mean Square Error (RMSE): " + str(cfg.proposed_rmse))
        self.data_textarea_result.insert(INSERT, "\nMean Absolute Percentage Error (MAPE): " + str(cfg.proposed_mape))
        self.data_textarea_result.insert(INSERT, "\nR2 score: " + str(cfg.proposed_r2))

        PGraph.MAE_RMSE_MAPE(self)
        PGraph.Prediction_Accuracy(self)
        messagebox.showinfo("Info Message", "Workload Forecast Training was done successfully...")
        print("\nWorkload Forecast Training was done successfully...")
        self.data_textarea_process.insert(INSERT, "\nWorkload Forecast Training was done successfully...")

        self.data_textarea_process.configure(state="disabled")
        self.btn_training.configure(state="disabled")

    def prediction(self):
        self.data_textarea_process.configure(state="normal")
        self.data_textarea_result.configure(state="normal")
        print("\nLoad of Containers")
        print("====================")
        self.data_textarea_process.insert(INSERT, "\n\nLoad of Containers")
        self.data_textarea_process.insert(INSERT, "\n====================")
        self.data_textarea_result.insert(INSERT, "\n\nLoad of Containers")
        self.data_textarea_result.insert(INSERT, "\n====================")

        messagebox.showinfo("Info Message", "Containers Load was done successfully...")
        print("\nContainers Load was done successfully...")
        self.data_textarea_process.insert(INSERT, "\n\nContainers Load was done successfully...")

        self.data_textarea_process.configure(state="disabled")
        self.btn_prediction.configure(state="disabled")

    def task_scheduling(self):
        self.data_textarea_process.configure(state="normal")
        self.data_textarea_result.configure(state="normal")
        print("\nTask Scheduling")
        print("================")
        self.data_textarea_process.insert(INSERT, "\n\nTask Scheduling")
        self.data_textarea_process.insert(INSERT, "\n================")
        self.data_textarea_result.insert(INSERT, "\n\nTask Scheduling")
        self.data_textarea_result.insert(INSERT, "\n================")

        print("\nExisting Genetic Algorithm (GA)")
        print("---------------------------------")
        self.data_textarea_process.insert(INSERT, "\n\nExisting Genetic Algorithm (GA)")
        self.data_textarea_process.insert(INSERT, "\n---------------------------------")
        self.data_textarea_result.insert(INSERT, "\n\nExisting Genetic Algorithm (GA)")
        self.data_textarea_result.insert(INSERT, "\n---------------------------------")
        from PS.Task_Scheduling.Existing_GA import (
            TaskSchedulingProblem,
            GeneticAlgorithm
        )

        # Example Tasks
        tasks = [
            1200, 800, 1500, 1000,
            2000, 500, 700, 900
        ]

        # VM Processing Speeds
        vms = [
            500,
            700,
            1000,
            1200
        ]

        # Create scheduling problem
        problem = TaskSchedulingProblem(tasks, vms)

        # Create Genetic Algorithm optimizer
        ga = GeneticAlgorithm(
            problem=problem,
            population_size=50,
            generations=100,
            crossover_rate=0.8,
            mutation_rate=0.1,
            elitism=True
        )

        # Run optimization
        best_schedule, best_makespan, history = ga.optimize()

        print("\nBest Task Allocation:")

        for task_id, vm_id in enumerate(best_schedule):
            self.data_textarea_result.insert(INSERT, "\n"+f"Task {task_id} --> VM {vm_id}")
            print(f"Task {task_id} --> VM {vm_id}")

        print(f"\nBest Makespan: {best_makespan:.4f}")
        self.data_textarea_result.insert(INSERT, f"\n\nBest Makespan: {best_makespan:.4f}")

        print("\nExisting Particle Swarm Optimization Algorithm (PSOA)")
        print("-------------------------------------------------------")
        self.data_textarea_process.insert(INSERT, "\n\nExisting Particle Swarm Optimization Algorithm (PSOA)")
        self.data_textarea_process.insert(INSERT, "\n-------------------------------------------------------")
        self.data_textarea_result.insert(INSERT, "\n\nExisting Particle Swarm Optimization Algorithm (PSOA)")
        self.data_textarea_result.insert(INSERT, "\n-------------------------------------------------------")
        from PS.Task_Scheduling.Existing_PSOA import (
            TaskSchedulingProblem,
            ParticleSwarmOptimization
        )

        # Example Tasks
        tasks = [
            1200, 800, 1500, 1000,
            2000, 500, 700, 900
        ]

        # VM Processing Speeds
        vms = [
            500,
            700,
            1000,
            1200
        ]

        # Create scheduling problem
        problem = TaskSchedulingProblem(tasks, vms)

        # Create PSO optimizer
        pso = ParticleSwarmOptimization(
            problem=problem,
            swarm_size=40,
            max_iterations=100,
            inertia_weight=0.7,
            cognitive_coefficient=1.5,
            social_coefficient=1.5
        )

        # Run optimization
        best_particle, best_makespan, history = pso.optimize()

        # Decode best schedule
        best_schedule = problem.decode_particle(best_particle)

        print("\nBest Task Allocation:")

        for task_id, vm_id in enumerate(best_schedule):
            self.data_textarea_result.insert(INSERT, "\n" + f"Task {task_id} --> VM {vm_id}")
            print(f"Task {task_id} --> VM {vm_id}")

        print(f"\nBest Makespan: {best_makespan:.4f}")
        self.data_textarea_result.insert(INSERT, f"\n\nBest Makespan: {best_makespan:.4f}")

        print("\nExisting Grey Wolf Optimization Algorithm (GWOA)")
        print("--------------------------------------------------")
        self.data_textarea_process.insert(INSERT, "\n\nExisting Grey Wolf Optimization Algorithm (GWOA)")
        self.data_textarea_process.insert(INSERT, "\n--------------------------------------------------")
        self.data_textarea_result.insert(INSERT, "\n\nExisting Grey Wolf Optimization Algorithm (GWOA)")
        self.data_textarea_result.insert(INSERT, "\n--------------------------------------------------")
        from PS.Task_Scheduling.Existing_GWOA import (
            TaskSchedulingProblem,
            GreyWolfOptimizer
        )

        # Example Tasks
        tasks = [
            1200, 800, 1500, 1000,
            2000, 500, 700, 900
        ]

        # VM Processing Speeds
        vms = [
            500,
            700,
            1000,
            1200
        ]

        # Create problem
        problem = TaskSchedulingProblem(tasks, vms)

        # Create optimizer
        gwo = GreyWolfOptimizer(
            problem=problem,
            population_size=30,
            max_iterations=50
        )

        # Run optimization
        best_wolf, best_makespan, history = gwo.optimize()

        # Decode best schedule
        best_schedule = problem.decode_wolf(best_wolf)

        print("\nBest Task Allocation:")

        for task_id, vm_id in enumerate(best_schedule):
            self.data_textarea_result.insert(INSERT, "\n" + f"Task {task_id} --> VM {vm_id}")
            print(f"Task {task_id} --> VM {vm_id}")

        print(f"\nBest Makespan: {best_makespan:.4f}")
        self.data_textarea_result.insert(INSERT, f"\n\nBest Makespan: {best_makespan:.4f}")

        print("\nProposed Enhanced Raindrop Optimization and Pufferfish Optimization Algorithm (ERD-PFOA)")
        print("------------------------------------------------------------------------------------------")
        self.data_textarea_process.insert(INSERT, "\n\nProposed Enhanced Raindrop Optimization and Pufferfish Optimization Algorithm (ERD-PFOA)")
        self.data_textarea_process.insert(INSERT, "\n--------------------------------------------------")
        self.data_textarea_result.insert(INSERT, "\n\nProposed ERD-PFOA")
        self.data_textarea_result.insert(INSERT, "\n--------------------")
        from PS.Task_Scheduling.Proposed import (
            TaskSchedulingProblem,
            ERD_PFOA
        )

        # Example Tasks (Million Instructions)
        tasks = [
            1200, 800, 1500, 1000,
            2000, 500, 700, 900,
            1400, 600
        ]

        # VM Processing Speeds (MIPS)
        vms = [
            500,
            700,
            1000,
            1200
        ]

        # Create scheduling problem
        problem = TaskSchedulingProblem(tasks, vms)

        # Create ERD-PFOA optimizer
        optimizer = ERD_PFOA(
            problem=problem,
            population_size=40,
            max_iterations=100,
            inflation_probability=0.6,
            random_seed=1
        )

        # Run optimization
        best_solution, best_fitness, history = optimizer.optimize()

        # Decode best task allocation
        best_schedule = problem.decode_solution(best_solution)

        # Evaluate objectives
        makespan, load_balance, cost = (
            problem.evaluate(best_solution)
        )

        print("\nBest Task Allocation:")

        for task_id, vm_id in enumerate(best_schedule):
            self.data_textarea_result.insert(INSERT, "\n" + f"Task {task_id} --> VM {vm_id}")
            print(f"Task {task_id} --> VM {vm_id}")

        print(f"\nBest Makespan: {best_makespan:.4f}")
        self.data_textarea_result.insert(INSERT, f"\n\nBest Makespan: {best_makespan:.4f}")

        print("\nObjectives:")
        self.data_textarea_result.insert(INSERT, "\n\nObjectives:")

        print(f"Makespan     : {makespan:.4f}")
        print(f"Load Balance : {load_balance:.4f}")
        print(f"Cost         : {cost:.4f}")
        self.data_textarea_result.insert(INSERT, "\n"+f"Makespan     : {makespan:.4f}")
        self.data_textarea_result.insert(INSERT, "\n"+f"Load Balance : {load_balance:.4f}")
        self.data_textarea_result.insert(INSERT, "\n"+f"Cost         : {cost:.4f}")

        print(f"\nBest Fitness : {best_fitness:.4f}")
        self.data_textarea_result.insert(INSERT, "\n"+f"\nBest Fitness : {best_fitness:.4f}")

        messagebox.showinfo("Info Message", "Task Scheduling was done successfully...")
        print("\nTask Scheduling was done successfully...")
        self.data_textarea_process.insert(INSERT, "\n\nTask Scheduling was done successfully...")

        self.data_textarea_process.configure(state="disabled")
        self.btn_task_scheduling.configure(state="disabled")

    def tables_graphs(self):
        if self.boolTesting:
            if not os.path.exists("..\\Result\\"):
                os.mkdir("..\\Result\\")

            # from DMRA.Code import Graph

            messagebox.showinfo("Info Message","Tables and Graphs are generated successfully...")
        else:
            messagebox.showinfo("Info Message","Please done the Load Prediction Testing first ...")

    def exit(self):
        self.root.destroy()

def getListOfFiles(dirName):
    # create a list of file and sub directories
    # names in the given directory
    listOfFile = os.listdir(dirName)
    allFiles = list()
    # Iterate over all the entries
    for entry in listOfFile:
        # Create full path
        fullPath = os.path.join(dirName, entry)
        # If entry is a directory then get the list of files in this directory
        if os.path.isdir(fullPath):
            allFiles = allFiles + getListOfFiles(fullPath)
        else:
            if not fullPath.endswith(".csv"):
                allFiles.append(fullPath)

    return allFiles

root = Tk()
root.title("Enhanced Mamba–Improved KAN Driven Predictive Scheduling with Hybrid Nature-Inspired Optimization for Cloud Energy Efficiency")
root.geometry("1200x600")
root.resizable(0, 0)
root.configure(bg="azure3")
od = Main_GUI(root)
root.mainloop()