import pandas as pd

class Preprocessing:
    def ddr(self, spath, dpath):
        # Read the CSV file
        df = pd.read_csv(spath)

        # Remove duplicate rows
        df_cleaned = df.drop_duplicates()

        # Save the cleaned data
        df_cleaned.to_csv(dpath, index=False)

    def mvi(self, spath, dpath):
        # Read CSV file
        df = pd.read_csv(spath)

        # Fill missing numeric values with the mean
        numeric_columns = df.select_dtypes(include=["number"]).columns

        for col in numeric_columns:
            df[col] = df[col].fillna(df[col].mean())

        # Save the cleaned file
        df.to_csv(dpath, index=False)